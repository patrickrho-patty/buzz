/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.18-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: passbolt
-- ------------------------------------------------------
-- Server version	10.11.18-MariaDB-ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account_recovery_organization_policies`
--

DROP TABLE IF EXISTS `account_recovery_organization_policies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_recovery_organization_policies` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `public_key_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  `policy` varchar(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `deleted` datetime DEFAULT NULL,
  `created_by` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `modified_by` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `public_key_id` (`public_key_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_recovery_organization_policies`
--

LOCK TABLES `account_recovery_organization_policies` WRITE;
/*!40000 ALTER TABLE `account_recovery_organization_policies` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_recovery_organization_policies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_recovery_organization_public_keys`
--

DROP TABLE IF EXISTS `account_recovery_organization_public_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_recovery_organization_public_keys` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `armored_key` mediumtext NOT NULL,
  `fingerprint` char(40) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `deleted` datetime DEFAULT NULL,
  `created_by` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `modified_by` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `fingerprint` (`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_recovery_organization_public_keys`
--

LOCK TABLES `account_recovery_organization_public_keys` WRITE;
/*!40000 ALTER TABLE `account_recovery_organization_public_keys` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_recovery_organization_public_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_recovery_private_key_passwords`
--

DROP TABLE IF EXISTS `account_recovery_private_key_passwords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_recovery_private_key_passwords` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `recipient_fingerprint` char(40) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `recipient_foreign_model` varchar(128) NOT NULL,
  `private_key_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `data` mediumtext NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `created_by` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `modified_by` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `recipient_fingerprint` (`recipient_fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_recovery_private_key_passwords`
--

LOCK TABLES `account_recovery_private_key_passwords` WRITE;
/*!40000 ALTER TABLE `account_recovery_private_key_passwords` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_recovery_private_key_passwords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_recovery_private_keys`
--

DROP TABLE IF EXISTS `account_recovery_private_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_recovery_private_keys` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `user_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `data` mediumtext NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `created_by` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `modified_by` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_recovery_private_keys`
--

LOCK TABLES `account_recovery_private_keys` WRITE;
/*!40000 ALTER TABLE `account_recovery_private_keys` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_recovery_private_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_recovery_requests`
--

DROP TABLE IF EXISTS `account_recovery_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_recovery_requests` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `user_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `armored_key` mediumtext DEFAULT NULL,
  `fingerprint` varchar(40) CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  `authentication_token_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `status` varchar(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `created_by` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `modified_by` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_recovery_requests`
--

LOCK TABLES `account_recovery_requests` WRITE;
/*!40000 ALTER TABLE `account_recovery_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_recovery_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_recovery_responses`
--

DROP TABLE IF EXISTS `account_recovery_responses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_recovery_responses` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `account_recovery_request_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `responder_foreign_key` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `responder_foreign_model` varchar(128) NOT NULL,
  `data` mediumtext DEFAULT NULL,
  `status` varchar(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `created_by` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `modified_by` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_recovery_responses`
--

LOCK TABLES `account_recovery_responses` WRITE;
/*!40000 ALTER TABLE `account_recovery_responses` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_recovery_responses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_recovery_user_settings`
--

DROP TABLE IF EXISTS `account_recovery_user_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_recovery_user_settings` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `user_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `status` varchar(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `created_by` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `modified_by` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_recovery_user_settings`
--

LOCK TABLES `account_recovery_user_settings` WRITE;
/*!40000 ALTER TABLE `account_recovery_user_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_recovery_user_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_settings`
--

DROP TABLE IF EXISTS `account_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_settings` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `user_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `property_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `property` varchar(256) NOT NULL,
  `value` text DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`,`property_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_settings`
--

LOCK TABLES `account_settings` WRITE;
/*!40000 ALTER TABLE `account_settings` DISABLE KEYS */;
INSERT INTO `account_settings` VALUES
('0dc2f7cc-72cf-4a76-86b4-2a9c221032f1','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','5a047a1d-8c40-587b-8f4a-31ec9fb4a3d1','locale','en-UK','2026-07-09 08:46:05','2026-07-09 08:46:05'),
('3ee2285b-08b0-4614-810e-fbe0f68a145c','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','bfbdfc34-38e1-5027-9230-950d9338d064','theme','solarized_dark','2026-07-09 08:48:33','2026-07-09 08:48:35');
/*!40000 ALTER TABLE `account_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `action_logs`
--

DROP TABLE IF EXISTS `action_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `action_logs` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `user_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  `action_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `context` varchar(255) NOT NULL,
  `status` int(1) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `status` (`status`),
  KEY `action_id_2` (`action_id`,`status`),
  KEY `user_id_2` (`user_id`,`action_id`,`status`,`created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `action_logs`
--

LOCK TABLES `action_logs` WRITE;
/*!40000 ALTER TABLE `action_logs` DISABLE KEYS */;
INSERT INTO `action_logs` VALUES
('013821ad-667d-4482-9aaa-e1bb4a02b574','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','b20e3cc2-e4ea-5b42-804b-7edc9878ef3d','GET /metadata/keys/settings.json',1,'2026-07-21 01:41:39'),
('019b25da-ee73-4e5f-b71e-2840f99807c8','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','12c1b158-0100-53d8-a979-83d3cc4a86bc','GET /metadata/types/settings.json',1,'2026-07-21 01:39:34'),
('02e51b1e-9d9f-45aa-919f-989a9c6a5503','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','e2aa01a9-84ec-55f8-aaed-24ee23259339','GET /resource-types.json',1,'2026-07-21 01:40:48'),
('0408b1ee-09e6-4ffa-96d5-abe18374e85c','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','1035f824-fe76-5a69-b02c-9aa60a31858c','GET /app/passwords',1,'2026-07-09 09:05:22'),
('041843c3-ad7c-4985-aa5b-c896613c97d4','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-26 13:13:05'),
('044fa2b1-2d2e-4197-9bfe-37f270659b72','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','3718aecb-1f9d-5d6f-83bb-fcd3562d014d','GET /secret-revisions/settings.json',1,'2026-07-26 13:44:01'),
('04989f3c-08ec-4904-88fd-2ddc4cbcad6f',NULL,'50ca4a19-b782-5842-bd2b-f59e9ff4eef9','GET /setup/start/2c22e1ca-66dc-4107-b375-f2d0d13dab9b/adb3e344-7b5e-11f1-8fe4-0e10625e4baf.json',1,'2026-07-09 08:45:07'),
('04aef7ba-d266-4654-940f-aea7935e0b94','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','3cffe6ef-ea4c-5bc3-869b-945f26e2601a','GET /groups.json',1,'2026-07-09 08:51:32'),
('04cb2848-586e-4dff-b383-a7da27c3cb19','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','c506210f-7866-5691-8fc1-58772e8f49f1','GET /resources.json',1,'2026-07-21 01:39:32'),
('0530122b-2fe7-4358-9c98-bba3eb32429a','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','c506210f-7866-5691-8fc1-58772e8f49f1','GET /resources.json',1,'2026-07-09 08:51:32'),
('054c41e5-cda7-4bb3-9e98-40b78be89a7a',NULL,'a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/login.json',1,'2026-07-21 16:50:46'),
('061e8139-6674-458c-9b8f-f0ca1cf91881','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','e2aa01a9-84ec-55f8-aaed-24ee23259339','GET /resource-types.json',1,'2026-07-21 01:39:57'),
('0692931b-3e34-4e18-b6cd-dfbfecf6be77',NULL,'a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/login.json',1,'2026-07-21 01:40:47'),
('07b0dfa0-3faa-4a47-8ac1-49d24bdc2f59','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','b20e3cc2-e4ea-5b42-804b-7edc9878ef3d','GET /metadata/keys/settings.json',1,'2026-07-26 12:58:08'),
('084dfb41-b3ba-4c89-9ad8-1a6ec13727bc',NULL,'bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-21 16:29:32'),
('084e05aa-15f5-487b-87e1-b0dcd33f7e45','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','e2aa01a9-84ec-55f8-aaed-24ee23259339','GET /resource-types.json',1,'2026-07-21 16:29:38'),
('08cfda89-46fa-4b73-a8a4-35f813cc0705','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','b20e3cc2-e4ea-5b42-804b-7edc9878ef3d','GET /metadata/keys/settings.json',1,'2026-07-09 08:46:07'),
('09566c50-b365-492e-9af5-f3f5c3696cd6','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','12c1b158-0100-53d8-a979-83d3cc4a86bc','GET /metadata/types/settings.json',1,'2026-07-21 01:39:32'),
('097a16ad-2bce-4a9a-8edb-721349ed0ce4','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-09 09:35:14'),
('0a56d3d7-fe9f-4644-bfd6-5f53bf760003','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','e73a6dad-9742-5f38-8929-180d09e1397a','GET /metadata/settings/getting-started.json',1,'2026-07-09 08:47:22'),
('0a5b77df-7f03-407f-a142-b40f39c5b9ab','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','83bb8bd8-2006-5546-a3bb-9319ae6e8f9d','GET /resources/b3f7b360-be12-4011-af21-756bae51f93b.json',1,'2026-07-21 16:27:09'),
('0b1b50b0-2c3f-4907-ae45-9ef6b7bf2276','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 01:34:14'),
('0b5b3407-16f0-4566-bb5c-a9d36e2ea92e','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-09 08:47:51'),
('0d305138-8c99-428f-bf21-3532609fc3cb','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','bbcc91fb-c9fe-5a24-aaf6-0d36b61f9559','POST /account/settings/themes.json',1,'2026-07-09 08:48:35'),
('0d72eeed-9078-46e5-9946-ab456374fbb6','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/login.json',1,'2026-07-09 08:46:05'),
('0dd082b6-d33b-4d3e-b194-e12c2e38dcd5','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','e2aa01a9-84ec-55f8-aaed-24ee23259339','GET /resource-types.json',1,'2026-07-21 01:40:30'),
('0dd9285b-3712-48eb-a487-fcc91e2ca611',NULL,'50ca4a19-b782-5842-bd2b-f59e9ff4eef9','GET /setup/start/2c22e1ca-66dc-4107-b375-f2d0d13dab9b/adb3e344-7b5e-11f1-8fe4-0e10625e4baf',1,'2026-07-09 08:45:05'),
('0e4a19e5-3a8a-435c-bfff-0d7b2e61aa72','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','9b473b19-0e3e-5efb-be19-8a1719843762','GET /account/settings.json',1,'2026-07-21 16:29:38'),
('0e678262-7aeb-4973-a687-a270da7ee8e7',NULL,'bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-09 08:45:06'),
('0e9d7cb1-44e3-47ce-a208-7e27f5bc5ce3',NULL,'bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-26 16:25:39'),
('0f085599-42ce-4bd1-8fed-0c98957544d6','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','19f9a792-3495-597b-bc94-dff1bc3e3967','POST /auth/logout.json',1,'2026-07-21 16:32:24'),
('0f889ce8-afc9-43dc-99d7-e46ec5998db7','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','12c1b158-0100-53d8-a979-83d3cc4a86bc','GET /metadata/types/settings.json',1,'2026-07-21 01:19:17'),
('10bf9064-d95a-48eb-bc7f-7064f9223bb8','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','19f9a792-3495-597b-bc94-dff1bc3e3967','POST /auth/logout.json',1,'2026-07-21 01:39:33'),
('10fd557d-15c1-4e48-ab69-616704ecc717','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','ad71952e-7842-599e-a19e-3a82e6974b23','GET /secrets/resource/7672b60a-f739-48fe-9265-1ac6f710557f.json',1,'2026-07-21 01:21:33'),
('114babb4-3702-40b3-bf0a-0dddc874895e','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/login.json',1,'2026-07-21 01:47:25'),
('12d49974-3e0c-44e3-bc02-7cdf05dc60f5','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','12c1b158-0100-53d8-a979-83d3cc4a86bc','GET /metadata/types/settings.json',1,'2026-07-21 01:42:10'),
('12d8e775-4219-4f29-9bd0-e67ed35cbe0b','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','c506210f-7866-5691-8fc1-58772e8f49f1','GET /resources.json',1,'2026-07-09 08:49:57'),
('12d912fa-babc-4b45-a5f8-8314beb0c12f',NULL,'a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/login.json',1,'2026-07-09 08:46:05'),
('131fafd9-e5b3-4e7c-9852-6e4dffffba5a',NULL,'bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-26 16:25:37'),
('147859fe-c422-4518-bf74-4fb05821417f','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 16:27:08'),
('147a41f2-ea1e-41a1-a456-4ea842df7544','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','3718aecb-1f9d-5d6f-83bb-fcd3562d014d','GET /secret-revisions/settings.json',1,'2026-07-21 01:38:05'),
('149ee8b7-0f31-496a-ab18-6abe03d69017','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 01:39:34'),
('14c024ca-bb4c-48a9-9903-2583d404eba5','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','19f9a792-3495-597b-bc94-dff1bc3e3967','POST /auth/logout.json',1,'2026-07-21 01:41:05'),
('15d382d7-f87d-4bca-ba58-43f980934306',NULL,'a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/verify.json',1,'2026-07-26 16:25:37'),
('16354141-e24d-4e3e-b7bb-b12200cef1d7','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','c506210f-7866-5691-8fc1-58772e8f49f1','GET /resources.json',1,'2026-07-21 01:47:25'),
('17062e10-ce8f-4da7-9125-66e60945f0d2',NULL,'50ca4a19-b782-5842-bd2b-f59e9ff4eef9','GET /setup/start/2c22e1ca-66dc-4107-b375-f2d0d13dab9b/7e8bc0b3-14af-493e-8052-2ed4a2f46790',1,'2026-07-08 23:16:10'),
('17214677-2132-4a45-b9bb-2dc32badd019','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','c506210f-7866-5691-8fc1-58772e8f49f1','GET /resources.json',1,'2026-07-21 01:38:02'),
('174700e6-e41f-4b84-966d-27c3a479f943','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','3cffe6ef-ea4c-5bc3-869b-945f26e2601a','GET /groups.json',1,'2026-07-21 01:38:02'),
('17936d91-4b1d-4760-9e0a-188f0a7bb81d','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 22:44:47'),
('17d8f240-baaa-4e26-82f6-57742c790b49','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','e38db0b5-838d-5f43-8609-92a25843e9d3','GET /metadata/keys.json',1,'2026-07-21 16:31:36'),
('1802b229-7029-40c3-a85c-2cd9bac38beb','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','d77de180-4626-54dd-80fb-a095ecc22aac','GET /resource-types/a28a04cd-6f53-518a-967c-9963bf9cec51.json',1,'2026-07-21 01:41:40'),
('1826a980-94de-4c3e-8a0e-e946233663f1','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','3cffe6ef-ea4c-5bc3-869b-945f26e2601a','GET /groups.json',1,'2026-07-21 01:19:17'),
('182cb1af-6c67-47bd-9df8-8814fa5975dd',NULL,'a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/login.json',1,'2026-07-21 01:41:04'),
('18e610d9-f25f-4f6f-8be3-8e08b9c817d7','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/2c22e1ca-66dc-4107-b375-f2d0d13dab9b.json',1,'2026-07-21 16:29:38'),
('1957efc9-c710-4759-8039-8934e403c9eb','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/2c22e1ca-66dc-4107-b375-f2d0d13dab9b.json',1,'2026-07-21 01:19:16'),
('197d92b9-cbaa-4fd4-b360-38f8562f9447','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','9b473b19-0e3e-5efb-be19-8a1719843762','GET /account/settings.json',1,'2026-07-09 08:47:35'),
('1a842ea3-6544-4330-a41c-fff5a1aef2be','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','ad8bbc35-6435-538e-b1a7-80b87bcedb6a','POST /resources.json',1,'2026-07-09 08:50:59'),
('1acf9578-c104-408d-a67c-c27d063610dd','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-21 01:40:32'),
('1b9ddcfd-3f6d-4d84-93ae-344b800e2ce8','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','3cffe6ef-ea4c-5bc3-869b-945f26e2601a','GET /groups.json',1,'2026-07-09 08:48:59'),
('1bb1328f-55b0-4d1f-8721-700023c8027d','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','c506210f-7866-5691-8fc1-58772e8f49f1','GET /resources.json',1,'2026-07-09 08:49:55'),
('1c05c626-6f30-4246-9b4e-85137d39edbf','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-26 14:58:10'),
('1c55048b-f3d7-41d7-9744-05164070f387','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','dad1db3f-4fbc-5b3a-9db2-b7413885c30c','GET /app/administration',1,'2026-07-09 08:47:50'),
('1ca2cab7-39f2-4fa3-8d01-3143b431106c','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','d77de180-4626-54dd-80fb-a095ecc22aac','GET /resource-types/a28a04cd-6f53-518a-967c-9963bf9cec51.json',1,'2026-07-21 01:41:05'),
('1d084940-14d0-4946-900b-68a71d6805e1','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-09 09:05:23'),
('1d09bade-04da-4d37-b1f4-1c8744558566','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-21 01:41:22'),
('1e2e46ab-5668-48db-a807-8c73ac1cb05b','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-09 10:20:14'),
('1e4dd79d-fe99-4122-ba1a-bf8dc71aa0ff','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','b20e3cc2-e4ea-5b42-804b-7edc9878ef3d','GET /metadata/keys/settings.json',1,'2026-07-26 16:26:01'),
('1ebef6c7-ca24-45dd-9a0d-f0e2be68d59a','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-09 09:20:14'),
('1f2dc198-3072-4c61-a8f8-e4e070943472','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','dad1db3f-4fbc-5b3a-9db2-b7413885c30c','GET /app/administration/internationalization',1,'2026-07-09 08:47:21'),
('1f58692e-e488-41a6-ae90-cdf96110e1b3','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 21:14:45'),
('1f607beb-b669-4c79-9a53-1ae729b42584','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/2c22e1ca-66dc-4107-b375-f2d0d13dab9b.json',1,'2026-07-26 16:26:00'),
('1fe1d012-7e2e-4725-99cf-8d285b5aa1cf',NULL,'bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-22 11:05:59'),
('2031eb0a-4941-4455-b1bf-39a6a0142992','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-26 12:58:07'),
('20635625-68ad-4467-b3aa-ec22ebaf200f',NULL,'17b8a54b-8069-586a-8ca2-7e7569b28e08','HEAD /setup/install/2c22e1ca-66dc-4107-b375-f2d0d13dab9b/7e8bc0b3-14af-493e-8052-2ed4a2f46790',0,'2026-07-08 23:16:09'),
('20791871-83c3-4604-b347-2430b72b3651','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 18:44:43'),
('20e98bc7-b770-467d-8f0f-cb81489fbf58','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-09 10:50:14'),
('213cc167-aece-48e5-be28-c5b1b88eaf73',NULL,'17b8a54b-8069-586a-8ca2-7e7569b28e08','HEAD /',0,'2026-07-08 23:13:13'),
('215bd8a7-7d17-4d4f-9db2-1d9f2f3dcb5e',NULL,'17b8a54b-8069-586a-8ca2-7e7569b28e08','HEAD /setup/2c22e1ca-66dc-4107-b375-f2d0d13dab9b/7e8bc0b3-14af-493e-8052-2ed4a2f46790',0,'2026-07-08 23:16:09'),
('22a4849c-b6ea-4d4e-9ab1-237dacf4a9ad',NULL,'17b8a54b-8069-586a-8ca2-7e7569b28e08','HEAD /',0,'2026-07-08 23:14:09'),
('23431dcf-777c-49b4-a995-fdba24e44a6f','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','e2aa01a9-84ec-55f8-aaed-24ee23259339','GET /resource-types.json',1,'2026-07-09 08:46:07'),
('23e4f36b-0913-47bd-9fdb-59ff5b8b62b3','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','72a35b3d-5baf-57cd-b6ba-a946bd879ad4','GET /password-policies/settings.json',1,'2026-07-09 09:05:16'),
('2463214d-2de2-4997-8948-dcfe71127487','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','c506210f-7866-5691-8fc1-58772e8f49f1','GET /resources.json',1,'2026-07-21 01:39:35'),
('251fa82f-1021-41ff-b557-0168605bfb88','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','1035f824-fe76-5a69-b02c-9aa60a31858c','GET /app/passwords',1,'2026-07-21 16:29:37'),
('26337bb3-ef0a-4a4a-a1a0-9c6f794ce564','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','ad71952e-7842-599e-a19e-3a82e6974b23','GET /secrets/resource/b3f7b360-be12-4011-af21-756bae51f93b.json',1,'2026-07-21 01:47:28'),
('26471af0-d04b-4d66-8b03-ff1e0e214949','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','83bb8bd8-2006-5546-a3bb-9319ae6e8f9d','GET /resources/b3f7b360-be12-4011-af21-756bae51f93b.json',1,'2026-07-21 01:41:39'),
('2648624a-530b-47cb-9a49-cae11250b801','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-09 08:47:22'),
('26a0a72c-522b-45b3-b392-7ed3b2c44b13','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-21 01:47:27'),
('26ba22e5-bbe8-4b7c-b807-64c36dced94e','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 17:59:42'),
('26d80113-c9dc-42ef-88a8-7c13224264b0','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','9b473b19-0e3e-5efb-be19-8a1719843762','GET /account/settings.json',1,'2026-07-09 08:47:51'),
('26ef2cf7-35a4-485e-83a1-fac50b89a9ce',NULL,'bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-18 04:19:57'),
('2766c421-0122-48b1-bfa4-763615e9d1a4','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','19f9a792-3495-597b-bc94-dff1bc3e3967','POST /auth/logout.json',1,'2026-07-21 01:41:23'),
('29789a47-25e4-468e-a5e3-a78d568b76d2','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','6729d30a-1efa-53a4-8c03-e7542b2fedbe','GET /password-expiry/settings.json',1,'2026-07-26 12:58:08'),
('29c0ce45-e7b8-4589-bda8-ecf28d0d6306',NULL,'bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-26 16:25:41'),
('2a8953f9-dbe2-4836-99ba-61c280be41f5','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','2c50bb0d-c13b-517c-9930-ad29fcbc7d81','POST /locale/settings.json',1,'2026-07-09 08:47:30'),
('2b2efef9-b4bb-4757-8dcb-3326156376fb','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','ad71952e-7842-599e-a19e-3a82e6974b23','GET /secrets/resource/b3f7b360-be12-4011-af21-756bae51f93b.json',1,'2026-07-21 16:32:24'),
('2be8a773-7b88-490d-b6eb-28418d02797e','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 01:49:14'),
('2befab9e-4201-4578-b943-d8fd209bf28d','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','1cd53591-cb6b-5b03-b0be-05a54644263d','GET /folders.json',1,'2026-07-09 08:48:59'),
('2c32be89-a1e3-46b5-a1e4-e3d5bcc37d53',NULL,'17b8a54b-8069-586a-8ca2-7e7569b28e08','HEAD /',0,'2026-07-08 23:10:45'),
('2d2b184b-56fc-4e81-bc4e-e78e7bbf4746','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-21 16:32:23'),
('2d3c6783-0266-445b-b70e-f30c3c89d637',NULL,'a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/login.json',1,'2026-07-21 01:39:32'),
('2d44a2bd-2e02-4af9-bdac-e857203c75b2','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','19f9a792-3495-597b-bc94-dff1bc3e3967','POST /auth/logout.json',1,'2026-07-21 16:27:10'),
('2d44a4a6-aefb-4ed0-bc67-fc077d5a44ab','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','a04f2607-8cb6-56c6-a9cb-6b9c7603bacd','GET /rbacs/me.json',1,'2026-07-26 12:58:08'),
('2d5877ed-03e8-4b37-ad2d-622d415d7463',NULL,'a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/login.json',1,'2026-07-21 01:19:14'),
('2e3c1f2a-36cb-4582-8a10-0eef4802d369','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','ab13b3e0-eae8-5099-909f-8582a3c2ddae','GET /folders/50d49e9b-5e79-497d-876d-3eaddb5644fe.json',1,'2026-07-09 08:49:54'),
('2e9c0aee-6d94-4188-94f8-c8a7d596d52a','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','a04f2607-8cb6-56c6-a9cb-6b9c7603bacd','GET /rbacs/me.json',1,'2026-07-09 08:47:35'),
('2ef48a1f-5554-4513-a21a-cfd9d6a19143','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','b20e3cc2-e4ea-5b42-804b-7edc9878ef3d','GET /metadata/keys/settings.json',1,'2026-07-21 01:47:25'),
('2f9cdb72-965f-4ecd-ba6d-5ada49c5c33b','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','83bb8bd8-2006-5546-a3bb-9319ae6e8f9d','GET /resources/b3f7b360-be12-4011-af21-756bae51f93b.json',1,'2026-07-21 01:41:23'),
('30b27d98-4bee-4c19-bfb6-1edc13e0511a','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','ab13b3e0-eae8-5099-909f-8582a3c2ddae','GET /folders/f2060f14-7c39-4958-a909-93d6171a1624.json',1,'2026-07-26 13:44:00'),
('316391b5-7357-48d3-8e58-4e5e6b9b5108','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','12c1b158-0100-53d8-a979-83d3cc4a86bc','GET /metadata/types/settings.json',1,'2026-07-21 16:27:09'),
('324cb9b4-639a-42ee-8ee3-2ceaec7d5146','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 02:04:14'),
('326f61e4-efdb-420e-ad9b-64e3d8b15ee0','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','12c1b158-0100-53d8-a979-83d3cc4a86bc','GET /metadata/types/settings.json',1,'2026-07-21 01:41:22'),
('33cab636-8366-424c-8f66-d46170de4c3a','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 01:56:31'),
('3430ff7d-3d59-4fa7-86b1-ee784bceefa5','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/login.json',1,'2026-07-21 16:32:23'),
('3452fc73-725d-4983-9af9-8001b0a5f1fa','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','c506210f-7866-5691-8fc1-58772e8f49f1','GET /resources.json',1,'2026-07-21 01:40:48'),
('3492a965-a4a9-4e39-a682-1b5c7e6df8ef','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 01:40:30'),
('35d4a565-da1b-486f-a109-8e0d6083a6ae','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','d77de180-4626-54dd-80fb-a095ecc22aac','GET /resource-types/a28a04cd-6f53-518a-967c-9963bf9cec51.json',1,'2026-07-21 16:32:24'),
('36c0531a-99ad-4871-a756-100ce618999b',NULL,'87d717de-7f19-5f3b-88cd-97bcaf26e8fa','GET /setup/user-key-policies/settings.json',1,'2026-07-09 08:45:44'),
('36efdfef-b37e-4537-a796-71c92c450c87','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 02:19:14'),
('36fce3ff-084e-4429-ab26-1f2cfb1b9f7b','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-21 01:39:34'),
('37202e7c-3a02-484a-a333-fdda2c731923','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 20:29:45'),
('37294d94-d192-48f4-ae2c-763654beeb03','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','1cd53591-cb6b-5b03-b0be-05a54644263d','GET /folders.json',1,'2026-07-21 01:39:35'),
('37d2a5e2-f31b-4a76-b36c-cc6c3cdf935b','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/login.json',1,'2026-07-21 16:50:46'),
('3814905d-e1f5-47d4-b20b-e5feddb2179f','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','ad71952e-7842-599e-a19e-3a82e6974b23','GET /secrets/resource/7672b60a-f739-48fe-9265-1ac6f710557f.json',1,'2026-07-21 16:50:47'),
('384590ce-0449-4a13-a531-2e3994b9836b','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','12c1b158-0100-53d8-a979-83d3cc4a86bc','GET /metadata/types/settings.json',1,'2026-07-09 08:46:07'),
('38862ec9-14db-416a-8fb5-47a7524d8539','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','12c1b158-0100-53d8-a979-83d3cc4a86bc','GET /metadata/types/settings.json',1,'2026-07-21 16:50:47'),
('39d7805e-6ab4-4687-a3bd-1bcaff83e7f5','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','12c1b158-0100-53d8-a979-83d3cc4a86bc','GET /metadata/types/settings.json',1,'2026-07-21 01:47:27'),
('3a9701ee-c5d1-4b7c-833b-d09be94ebc28','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','b20e3cc2-e4ea-5b42-804b-7edc9878ef3d','GET /metadata/keys/settings.json',1,'2026-07-21 01:19:17'),
('3b6e1daa-c473-4045-9938-cbaf1de61f75','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','ab13b3e0-eae8-5099-909f-8582a3c2ddae','GET /folders/f2060f14-7c39-4958-a909-93d6171a1624.json',1,'2026-07-26 12:58:33'),
('3be281f7-23e0-46f0-ac67-8f7f2e53dc95','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','3718aecb-1f9d-5d6f-83bb-fcd3562d014d','GET /secret-revisions/settings.json',1,'2026-07-21 16:29:40'),
('3c41b50c-b9a5-4897-b5c4-7d0997967568','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 20:44:45'),
('3ca3a4c1-44d1-4406-b3d1-3e167fd7632b',NULL,'748dcd10-7d15-5498-9aa6-d26de348ff02','GET /auth/verify.json',1,'2026-07-09 08:45:07'),
('3ca3e723-20ec-4c3f-a0b3-320640ebd2cb','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/login.json',1,'2026-07-21 16:27:08'),
('3eb453bd-1651-4f82-9570-cf0d924484f2','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 22:29:47'),
('3ebafed1-2ed9-4cf4-ad13-b482281860e0','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','c506210f-7866-5691-8fc1-58772e8f49f1','GET /resources.json',1,'2026-07-21 01:43:49'),
('3fd830db-364b-41c6-a840-b07bfdfe6b98','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','72a35b3d-5baf-57cd-b6ba-a946bd879ad4','GET /password-policies/settings.json',1,'2026-07-21 01:19:16'),
('40196d24-484a-4107-aa4f-ed88be5348d7','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','83bb8bd8-2006-5546-a3bb-9319ae6e8f9d','GET /resources/7672b60a-f739-48fe-9265-1ac6f710557f.json',1,'2026-07-21 16:50:47'),
('4025a0c8-e2d7-462a-b4d3-a966fb40f704','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','1cd53591-cb6b-5b03-b0be-05a54644263d','GET /folders.json',1,'2026-07-21 01:19:17'),
('40ae4242-1b1e-463f-a96f-bb40caf6f655','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','3718aecb-1f9d-5d6f-83bb-fcd3562d014d','GET /secret-revisions/settings.json',1,'2026-07-21 01:19:20'),
('41116506-4292-43ec-9f9c-21f503379030','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-26 16:26:00'),
('41b677d6-4f1b-4a62-9343-8a526cb5e96e','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','1cd53591-cb6b-5b03-b0be-05a54644263d','GET /folders.json',1,'2026-07-09 08:46:08'),
('41baacb2-dbd7-4141-9d23-ef8b79717927','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','12c1b158-0100-53d8-a979-83d3cc4a86bc','GET /metadata/types/settings.json',1,'2026-07-21 01:40:48'),
('41fe399e-a503-4bfe-a14e-750a66028869','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','c506210f-7866-5691-8fc1-58772e8f49f1','GET /resources.json',1,'2026-07-21 01:19:17'),
('43c13758-5c1e-4a72-92c3-a9fcc6d51471','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 01:47:25'),
('450c92e5-7481-4fa7-849d-4be624620107','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/login.json',1,'2026-07-21 01:40:32'),
('4532bd6d-157f-4f30-98a2-ddd47e507c14','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','3cffe6ef-ea4c-5bc3-869b-945f26e2601a','GET /groups.json',1,'2026-07-09 08:49:17'),
('4569a2d3-a65a-4da5-815f-9498ce8aadf8','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','d7bc9044-a64e-5421-a4d7-7a94eaa39d37','GET /users.json',1,'2026-07-21 16:31:37'),
('464a4d74-7df4-4317-9ac2-a1c3c22c340d',NULL,'17b8a54b-8069-586a-8ca2-7e7569b28e08','HEAD /',0,'2026-07-08 17:17:40'),
('47160b02-5abb-40d4-996c-b2b0c70682b8',NULL,'50ca4a19-b782-5842-bd2b-f59e9ff4eef9','GET /setup/start/2c22e1ca-66dc-4107-b375-f2d0d13dab9b/7e8bc0b3-14af-493e-8052-2ed4a2f46790',1,'2026-07-08 23:56:27'),
('485458c1-2fa5-41ee-8fd5-1c43ed0d08e7','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','1cd53591-cb6b-5b03-b0be-05a54644263d','GET /folders.json',1,'2026-07-26 12:58:09'),
('49cc86f2-4472-4da0-9aea-3ea9bd3ca717','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','d7bc9044-a64e-5421-a4d7-7a94eaa39d37','GET /users.json',1,'2026-07-09 08:49:04'),
('4a1108cc-33ad-4fd7-b80f-35b18354e373',NULL,'a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/login.json',1,'2026-07-21 16:53:48'),
('4a55f430-0e10-4e57-9078-0dc2ebe4a0d3','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-09 11:50:15'),
('4b769273-4e8a-4123-889c-d5d78f0a11a9',NULL,'50ca4a19-b782-5842-bd2b-f59e9ff4eef9','GET /setup/start/2c22e1ca-66dc-4107-b375-f2d0d13dab9b/7e8bc0b3-14af-493e-8052-2ed4a2f46790',1,'2026-07-08 23:57:44'),
('4b80fc40-728f-4659-9af6-fea6bcb523db','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','c506210f-7866-5691-8fc1-58772e8f49f1','GET /resources.json',1,'2026-07-21 16:29:39'),
('4bec4f38-4343-4d56-ab4a-02dce34a659c','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-21 01:47:25'),
('4d28c650-e7d6-468b-a2fd-8d4db2a9b0f0','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/login.json',1,'2026-07-21 01:41:39'),
('4e6bc118-148f-4817-9c92-5b72a98d4c61',NULL,'17b8a54b-8069-586a-8ca2-7e7569b28e08','HEAD /',0,'2026-07-08 23:55:29'),
('4e832ff9-d56b-4f6d-a6dd-573589a0dc09','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/login.json',1,'2026-07-21 16:29:36'),
('4ecce0f4-19a5-43f6-8223-8cb251147ab3','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','e2aa01a9-84ec-55f8-aaed-24ee23259339','GET /resource-types.json',1,'2026-07-26 12:58:08'),
('4f16281d-0f80-41d3-a176-e554450492b8','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 17:14:38'),
('4f2426ca-7a32-4bc2-b618-e1f30e700f07','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','1035f824-fe76-5a69-b02c-9aa60a31858c','GET /',1,'2026-07-26 12:58:05'),
('4fb81e44-bbb5-4364-84db-ce61c7c9d1f1','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','02e18a01-42f6-5e5d-b18f-2ee9070e3b9d','POST /folders.json',1,'2026-07-09 08:49:39'),
('4fdecfe5-3c0c-44ff-95db-8aec05991031','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 17:44:41'),
('4ff5c089-5d75-4906-aad2-7050216e3ee4','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-21 01:19:16'),
('50e27ce9-5884-4ce2-b6e8-e7d966c69b51','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-21 16:53:48'),
('50f7b72a-ddeb-471f-a062-3425af86711c',NULL,'bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-09 12:54:44'),
('5252c063-65da-49c8-a930-e53a19a497b8',NULL,'bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-26 16:24:59'),
('5309442e-9198-419e-ac82-24a7841d6d4f','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/login.json',1,'2026-07-26 12:58:04'),
('53ffeaba-2688-4ead-9a71-c565b1eb1e50','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','d77de180-4626-54dd-80fb-a095ecc22aac','GET /resource-types/a28a04cd-6f53-518a-967c-9963bf9cec51.json',1,'2026-07-21 01:47:27'),
('5403379a-d105-4945-80d8-d6a8e16cd07c','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','e2aa01a9-84ec-55f8-aaed-24ee23259339','GET /resource-types.json',1,'2026-07-21 01:39:35'),
('540efc61-99e2-4b36-8160-57437fdb77a1','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','1035f824-fe76-5a69-b02c-9aa60a31858c','GET /',1,'2026-07-21 01:19:14'),
('54322a90-9c41-498e-aaf6-95f959251d0b','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','058f384b-6685-55ac-8e82-9b0579a4e210','GET /account/settings/themes.json',1,'2026-07-09 08:51:12'),
('5486d7dd-2371-4dc7-b143-9f95ffbb42a8','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 20:59:45'),
('54f93738-ab40-4a78-a317-e2c931321359',NULL,'a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/login.json',1,'2026-07-21 16:27:07'),
('553f7db5-b3d8-4035-ae26-41efc4fa49d8','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','c506210f-7866-5691-8fc1-58772e8f49f1','GET /resources.json',1,'2026-07-26 12:58:09'),
('555eef7f-207a-48e9-b02e-ae5043fcf3b8',NULL,'50ca4a19-b782-5842-bd2b-f59e9ff4eef9','GET /setup/start/2c22e1ca-66dc-4107-b375-f2d0d13dab9b/adb3e344-7b5e-11f1-8fe4-0e10625e4baf',1,'2026-07-09 08:45:05'),
('55a8f795-bdf0-4778-8189-c39d884cd80e','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/login.json',1,'2026-07-21 01:41:04'),
('55e65b23-eb98-4c4d-b573-4ff6ca628768','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','e73a6dad-9742-5f38-8929-180d09e1397a','GET /metadata/settings/getting-started.json',1,'2026-07-09 08:46:43'),
('56da428d-152c-4074-9950-03ad56c7659e','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','ad71952e-7842-599e-a19e-3a82e6974b23','GET /secrets/resource/b3f7b360-be12-4011-af21-756bae51f93b.json',1,'2026-07-21 16:27:09'),
('572518e6-665c-4363-8375-bf61b8fb47b3','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/login.json',1,'2026-07-21 16:53:48'),
('573409a2-f855-4418-88ef-0b7455a78219','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 18:14:42'),
('5767b364-0bbc-4572-95b5-9d1743a7d034','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','19f9a792-3495-597b-bc94-dff1bc3e3967','POST /auth/logout.json',1,'2026-07-21 01:47:26'),
('57ac3b60-64e4-4987-8fb7-82d2bbae8fcc','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','e2aa01a9-84ec-55f8-aaed-24ee23259339','GET /resource-types.json',1,'2026-07-21 01:40:49'),
('585f615e-9536-4f1b-8547-84c1137606dd','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','6f53faec-0c9e-5321-ac78-543e1001f7b1','POST /setup/complete/2c22e1ca-66dc-4107-b375-f2d0d13dab9b.json',1,'2026-07-09 08:46:05'),
('58beb262-3414-462b-90d0-ed42d29cf7a2','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','1cd53591-cb6b-5b03-b0be-05a54644263d','GET /folders.json',1,'2026-07-21 01:43:49'),
('594bf8d6-20a5-445e-9110-fb0ce097e349','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','19f9a792-3495-597b-bc94-dff1bc3e3967','POST /auth/logout.json',1,'2026-07-21 01:56:32'),
('59a1c0c8-b578-4856-aa61-94e8d3a20039','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','83bb8bd8-2006-5546-a3bb-9319ae6e8f9d','GET /resources/7672b60a-f739-48fe-9265-1ac6f710557f.json',1,'2026-07-21 16:53:49'),
('59d02071-7107-47ea-bb47-df9368933ac1','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/login.json',1,'2026-07-21 01:56:30'),
('59ebb828-ced2-4c70-9eb4-caa82b47b8ad','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','b20e3cc2-e4ea-5b42-804b-7edc9878ef3d','GET /metadata/keys/settings.json',1,'2026-07-21 01:40:48'),
('5a360d44-8a9c-4fa8-b6e4-980e65c799d0','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','ad71952e-7842-599e-a19e-3a82e6974b23','GET /secrets/resource/b3f7b360-be12-4011-af21-756bae51f93b.json',1,'2026-07-21 01:43:53'),
('5accb2e3-16e0-448f-8332-9f715791e1d7',NULL,'bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-26 16:25:42'),
('5bdb6c84-8ff4-4b70-b25d-c0a296f5ddfb',NULL,'a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/verify.json',1,'2026-07-26 16:25:42'),
('5c38ab4c-c1d5-4a2f-aad8-8d8d26b166e4','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','3cffe6ef-ea4c-5bc3-869b-945f26e2601a','GET /groups.json',1,'2026-07-26 12:58:08'),
('5c5713a0-d579-4804-a1a4-c1441cfa6ae1','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','19f9a792-3495-597b-bc94-dff1bc3e3967','POST /auth/logout.json',1,'2026-07-21 01:39:35'),
('5d7e9c51-bfeb-42a0-b4b3-ca0c4ec395f5','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','a04f2607-8cb6-56c6-a9cb-6b9c7603bacd','GET /rbacs/me.json',1,'2026-07-09 08:46:07'),
('5e04b924-d70a-4e81-a21e-6e7a74ca861c','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/2c22e1ca-66dc-4107-b375-f2d0d13dab9b.json',1,'2026-07-21 16:29:38'),
('5e618b27-320a-4de4-83f4-d456adf6702b',NULL,'a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/login.json',1,'2026-07-26 16:25:59'),
('5eb7ceaa-ead0-46d3-863c-12ceaec70773','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','9b473b19-0e3e-5efb-be19-8a1719843762','GET /account/settings.json',1,'2026-07-09 09:05:23'),
('615ebb57-d301-4a6b-b8f4-a6ccb32acde1','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','02e18a01-42f6-5e5d-b18f-2ee9070e3b9d','POST /folders.json',1,'2026-07-26 12:58:32'),
('62767551-9f59-4ef0-8981-e54705d17950','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/login.json',1,'2026-07-21 01:39:32'),
('62ffcf84-b688-41f7-bba6-a9c8d039535a','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','d77de180-4626-54dd-80fb-a095ecc22aac','GET /resource-types/a28a04cd-6f53-518a-967c-9963bf9cec51.json',1,'2026-07-21 16:27:09'),
('63705eb5-c2cd-4c6e-8a51-ce4c374c2752','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/2c22e1ca-66dc-4107-b375-f2d0d13dab9b.json',1,'2026-07-26 12:58:07'),
('63d45c35-2d1a-4cc7-9a57-33a8e272be60','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','c506210f-7866-5691-8fc1-58772e8f49f1','GET /resources.json',1,'2026-07-26 16:26:01'),
('6449b92f-8c1e-4eaf-94b8-e30d9208ec21','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','b20e3cc2-e4ea-5b42-804b-7edc9878ef3d','GET /metadata/keys/settings.json',1,'2026-07-09 09:05:16'),
('6461ff39-61ad-4ba8-9f94-defc040db19d','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','e73a6dad-9742-5f38-8929-180d09e1397a','GET /metadata/settings/getting-started.json',1,'2026-07-09 08:48:39'),
('65d6ff8c-0e88-4b45-aab0-2c2330296d1b',NULL,'bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-09 08:45:05'),
('663b94c4-cd02-4e41-8455-f7cb13d3adb0',NULL,'17b8a54b-8069-586a-8ca2-7e7569b28e08','HEAD /',0,'2026-07-09 00:44:37'),
('6664449b-f0ab-4de5-8dc4-99d4cc019744','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','e38db0b5-838d-5f43-8609-92a25843e9d3','GET /metadata/keys.json',1,'2026-07-21 01:26:12'),
('66b282fb-e099-4c1a-9eca-e9d2c1f7aa39',NULL,'a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/login.json',1,'2026-07-21 01:47:24'),
('66fb788a-8ee3-4f5a-9911-13250e95e528','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','1cd53591-cb6b-5b03-b0be-05a54644263d','GET /folders.json',1,'2026-07-09 08:49:17'),
('671ffad6-5d26-429f-821a-a80825ce9c5c','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','e2aa01a9-84ec-55f8-aaed-24ee23259339','GET /resource-types.json',1,'2026-07-21 01:39:33'),
('67620740-7a00-4ba4-ba57-8d2b01344063',NULL,'a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/verify.json',1,'2026-07-21 16:29:32'),
('67d3abf2-0b62-4631-8b09-3a96159fd789','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','b20e3cc2-e4ea-5b42-804b-7edc9878ef3d','GET /metadata/keys/settings.json',1,'2026-07-21 16:50:47'),
('686d4d83-0e26-48bc-ae86-77c5c0d237b1','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 01:39:32'),
('68e0e11f-c9f0-4f72-b495-08ea70d1626c',NULL,'a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/login.json',1,'2026-07-21 01:42:09'),
('69068bc2-1a14-46ac-ba56-65d4f9ac6a39','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','e2aa01a9-84ec-55f8-aaed-24ee23259339','GET /resource-types.json',1,'2026-07-21 01:19:17'),
('698065bd-c3b0-475c-95a2-43cd41cfa8de',NULL,'50ca4a19-b782-5842-bd2b-f59e9ff4eef9','GET /setup/install/2c22e1ca-66dc-4107-b375-f2d0d13dab9b/adb3e344-7b5e-11f1-8fe4-0e10625e4baf.json',1,'2026-07-09 08:44:32'),
('69abf39e-3e9a-42fb-8434-aeeacfd75409','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','b20e3cc2-e4ea-5b42-804b-7edc9878ef3d','GET /metadata/keys/settings.json',1,'2026-07-21 16:27:09'),
('69d09e19-0d1c-4d44-af65-022e7ea5f5cb','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','83bb8bd8-2006-5546-a3bb-9319ae6e8f9d','GET /resources/7672b60a-f739-48fe-9265-1ac6f710557f.json',1,'2026-07-21 01:56:31'),
('6a041352-3494-415a-ab35-9f53b0f21efa','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','12c1b158-0100-53d8-a979-83d3cc4a86bc','GET /metadata/types/settings.json',1,'2026-07-21 01:47:25'),
('6b3aa2fe-0154-448a-b186-699ded370a9f','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','72a35b3d-5baf-57cd-b6ba-a946bd879ad4','GET /password-policies/settings.json',1,'2026-07-26 16:26:01'),
('6c4c5ff8-9023-4689-b3e1-bc7ffe5738d5','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','a8b75aae-cb86-5fda-a8b3-d36ae6155023','GET /gpgkeys.json',1,'2026-07-21 01:44:28'),
('6cef9687-4b10-4f00-b119-14c0fe4af3ac',NULL,'17b8a54b-8069-586a-8ca2-7e7569b28e08','HEAD /',0,'2026-07-09 13:45:12'),
('6d3687eb-5f57-424e-847b-e297586dc402','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 19:29:43'),
('6d65e76e-0d2e-4b27-9cff-967b795792cc','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','a04f2607-8cb6-56c6-a9cb-6b9c7603bacd','GET /rbacs/me.json',1,'2026-07-09 08:47:22'),
('6d7133b7-f2e3-4ca0-bd8a-a1d0d207cf2e',NULL,'a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/login.json',1,'2026-07-21 01:39:56'),
('6d731dd2-032b-4e27-9d6f-72b26636dbbf','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 01:41:22'),
('6d9fcc3a-fa85-41ed-83ed-c8c009fd9010','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-09 11:05:15'),
('6de17b28-c282-4804-a634-3975325eb192','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','c506210f-7866-5691-8fc1-58772e8f49f1','GET /resources.json',1,'2026-07-21 01:40:30'),
('6f176042-f7d9-4475-89da-63200724131b','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','b20e3cc2-e4ea-5b42-804b-7edc9878ef3d','GET /metadata/keys/settings.json',1,'2026-07-21 01:40:30'),
('6f3c0283-0c5b-4171-87cb-7c7e331246e7','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','1cd53591-cb6b-5b03-b0be-05a54644263d','GET /folders.json',1,'2026-07-09 08:49:50'),
('700f922a-2412-429d-a8cf-dfb436983a84','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-09 08:46:07'),
('7062e801-4bc6-4f22-9ab8-f9cbd8735d39','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','e2aa01a9-84ec-55f8-aaed-24ee23259339','GET /resource-types.json',1,'2026-07-21 01:47:26'),
('70d3a0a3-e821-4260-a466-0f4cbd7b929d','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/login.json',1,'2026-07-21 01:42:09'),
('712a8c08-f7fe-4450-a05d-9bcd443c08e6','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-26 14:43:10'),
('729979b8-0f5d-4d6e-ab55-ab0b216fb7cc',NULL,'50ca4a19-b782-5842-bd2b-f59e9ff4eef9','GET /setup/start/2c22e1ca-66dc-4107-b375-f2d0d13dab9b/adb3e344-7b5e-11f1-8fe4-0e10625e4baf.json',1,'2026-07-09 08:45:07'),
('7321878e-9d4e-46ef-beba-11162ee28041',NULL,'50ca4a19-b782-5842-bd2b-f59e9ff4eef9','GET /setup/start/2c22e1ca-66dc-4107-b375-f2d0d13dab9b/adb3e344-7b5e-11f1-8fe4-0e10625e4baf',1,'2026-07-09 08:45:05'),
('735c9a74-a6d7-48d7-b6ab-ad3eb1e22c5b','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/login.json',1,'2026-07-21 01:39:56'),
('74476504-c457-4f21-9119-d2494fd2e977','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/login.json',1,'2026-07-09 09:05:14'),
('7459372c-19b5-450c-b4c3-d7279b6166a2',NULL,'a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/verify.json',1,'2026-07-26 16:25:39'),
('748f8d6d-9170-44e9-8c50-c9def148f4eb','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','3cffe6ef-ea4c-5bc3-869b-945f26e2601a','GET /groups.json',1,'2026-07-09 08:49:04'),
('74d5ec18-4898-4be2-9309-f9ddd51cedef','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','3cffe6ef-ea4c-5bc3-869b-945f26e2601a','GET /groups.json',1,'2026-07-09 08:48:37'),
('74eb55c3-98c2-4a9c-b91d-313b6ba6e141',NULL,'bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-18 17:12:59'),
('752f3479-8efc-4d85-87ef-fe7565e7e114','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','1035f824-fe76-5a69-b02c-9aa60a31858c','GET /app/passwords',1,'2026-07-09 09:05:14'),
('75359f93-7721-4d3a-94d1-b9a013a6db41','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','a04f2607-8cb6-56c6-a9cb-6b9c7603bacd','GET /rbacs/me.json',1,'2026-07-09 08:47:51'),
('758e739a-d46b-4fbd-b23b-e124439dc40f','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','e38db0b5-838d-5f43-8609-92a25843e9d3','GET /metadata/keys.json',1,'2026-07-26 13:44:00'),
('758ea9d3-04d3-465c-aa72-02b5b9bf8d95',NULL,'a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/verify.json',1,'2026-07-09 12:54:44'),
('75b35d31-f275-49be-b330-39e33b96b75b','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','1cd53591-cb6b-5b03-b0be-05a54644263d','GET /folders.json',1,'2026-07-09 08:49:39'),
('7654f45b-2732-418d-9b41-10c44ae7e630',NULL,'bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-21 01:18:58'),
('767f4ec3-5cfa-45df-837d-195939665317',NULL,'bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-26 12:57:53'),
('76cbd7fc-75b6-4033-bff2-bb8a5a6ffc34',NULL,'a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/login.json',1,'2026-07-26 12:58:04'),
('77686dd5-692e-4ec7-911f-d2a760d5d433','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','ad8bbc35-6435-538e-b1a7-80b87bcedb6a','POST /resources.json',1,'2026-07-21 01:26:12'),
('77acd363-1b72-4e10-83c9-1883ea7318a2','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','12c1b158-0100-53d8-a979-83d3cc4a86bc','GET /metadata/types/settings.json',1,'2026-07-21 01:41:39'),
('77b52616-bcc9-422f-9070-959cf3833ae6','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 16:44:37'),
('77c34c6b-6241-4451-90eb-6c1639efa4c0',NULL,'a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/login.json',1,'2026-07-21 01:39:34'),
('786a5ba3-74fb-4bbd-83b9-9b8cfcbed2a7',NULL,'a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/verify.json',1,'2026-07-09 09:03:28'),
('79877b0a-f7ca-4cff-af6e-965566d35994','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 01:41:04'),
('79db25aa-c809-4aa4-8979-488d37576e0a','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','9b473b19-0e3e-5efb-be19-8a1719843762','GET /account/settings.json',1,'2026-07-26 16:26:00'),
('7a45cd75-28de-4cee-9aad-4a3c6e6851e9',NULL,'bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-09 08:45:06'),
('7a490b83-fc4f-4dd3-a58b-51f5185b8340','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','c506210f-7866-5691-8fc1-58772e8f49f1','GET /resources.json',1,'2026-07-09 08:46:08'),
('7ac1ab06-2f61-402c-a802-6d9a44f6819a','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','30237a18-fd12-5935-b1be-1e2a62ccb71d','GET /roles.json',1,'2026-07-09 08:49:04'),
('7c641507-50d5-4925-b06c-1de9f52cbe5a','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','12c1b158-0100-53d8-a979-83d3cc4a86bc','GET /metadata/types/settings.json',1,'2026-07-21 01:40:32'),
('7d4b48af-3702-4bc5-a6a5-8f5c792ed91e','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-09 08:47:22'),
('7e0ecf72-3aa6-4d30-aa54-6cd7f835a7bc','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','a04f2607-8cb6-56c6-a9cb-6b9c7603bacd','GET /rbacs/me.json',1,'2026-07-21 16:29:38'),
('7e3881c0-3443-4c52-a3b0-bab77c392118','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','83bb8bd8-2006-5546-a3bb-9319ae6e8f9d','GET /resources/b3f7b360-be12-4011-af21-756bae51f93b.json',1,'2026-07-21 01:47:27'),
('7e73853a-0d72-4fa1-827f-afd46b1ca6c6','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/login.json',1,'2026-07-21 01:47:27'),
('7ebdde71-960d-4143-9fe7-b6dcdf3dfff6','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','12c1b158-0100-53d8-a979-83d3cc4a86bc','GET /metadata/types/settings.json',1,'2026-07-21 01:56:31'),
('7fafc501-4f09-4baa-926e-6e685094dfe2','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-21 01:39:32'),
('7fd31032-9495-4869-96ff-65d40d98d4f2','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','c506210f-7866-5691-8fc1-58772e8f49f1','GET /resources.json',1,'2026-07-09 09:05:16'),
('8001b5e0-e1c0-4c7e-afa7-915edeec213b',NULL,'bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-26 16:24:59'),
('8027b29f-d857-4bd9-adb3-cb9122a2dc84','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','058f384b-6685-55ac-8e82-9b0579a4e210','GET /account/settings/themes.json',1,'2026-07-09 08:48:30'),
('81021464-a410-45df-b21b-1e0842101d18',NULL,'50ca4a19-b782-5842-bd2b-f59e9ff4eef9','GET /setup/install/2c22e1ca-66dc-4107-b375-f2d0d13dab9b/adb3e344-7b5e-11f1-8fe4-0e10625e4baf.json',1,'2026-07-09 08:45:07'),
('83b4d6d7-d319-4df3-b145-f821254a9587','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-26 13:58:08'),
('84771fa6-fc85-441f-8bd8-16ae38f6ab16','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','9b473b19-0e3e-5efb-be19-8a1719843762','GET /account/settings.json',1,'2026-07-26 12:58:06'),
('851c4f71-9c62-41d2-95dc-d724a6c2bc22',NULL,'17b8a54b-8069-586a-8ca2-7e7569b28e08','HEAD /setup/start/2c22e1ca-66dc-4107-b375-f2d0d13dab9b/7e8bc0b3-14af-493e-8052-2ed4a2f46790',0,'2026-07-08 23:16:09'),
('86472f3e-ff77-4a91-9156-161e85ea7172','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-09 11:35:15'),
('86cd11b1-d17a-47e6-a0cd-7ebc5a5dadf7','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-09 12:05:15'),
('8776ec5c-17ac-4d43-b391-7454cc274e1f','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','e2aa01a9-84ec-55f8-aaed-24ee23259339','GET /resource-types.json',1,'2026-07-21 01:40:31'),
('87777d7b-d81e-4e9e-9915-47e6c0371074','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','c506210f-7866-5691-8fc1-58772e8f49f1','GET /resources.json',1,'2026-07-09 08:49:39'),
('87c3a95c-28a5-4918-8e6e-834f78970ded','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 01:41:39'),
('893de64e-6bc8-45ad-b8bb-c7cb327a161c','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','83bb8bd8-2006-5546-a3bb-9319ae6e8f9d','GET /resources/b3f7b360-be12-4011-af21-756bae51f93b.json',1,'2026-07-21 01:41:05'),
('8971614b-c8bc-43a9-a836-78fa819351bc','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-21 16:50:47'),
('897adfe8-18d3-4109-ac91-38021643493a','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 01:39:56'),
('8b245dc2-34b5-4b97-8b2c-171904bf75b5','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','d77de180-4626-54dd-80fb-a095ecc22aac','GET /resource-types/a28a04cd-6f53-518a-967c-9963bf9cec51.json',1,'2026-07-21 01:42:10'),
('8c9a6ac2-c938-4531-b6a9-ddc0fc9f070f',NULL,'a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/login.json',1,'2026-07-21 01:41:22'),
('8e33fa36-3ed7-4f8b-8dba-b96e34d3d08d',NULL,'a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/login.json',1,'2026-07-21 16:32:23'),
('8e695c33-6cb0-4b64-8e6c-7efbd0641e47','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','b20e3cc2-e4ea-5b42-804b-7edc9878ef3d','GET /metadata/keys/settings.json',1,'2026-07-21 16:32:24'),
('903bee0e-43ef-4ff5-a4bf-9b9fce869ea9','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','1cd53591-cb6b-5b03-b0be-05a54644263d','GET /folders.json',1,'2026-07-26 12:58:33'),
('90fb601f-c8ad-408d-b385-11c0997762a3','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 19:14:43'),
('913122dc-a5d5-4c92-b959-1dab29967d7a','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','ad71952e-7842-599e-a19e-3a82e6974b23','GET /secrets/resource/b3f7b360-be12-4011-af21-756bae51f93b.json',1,'2026-07-21 01:41:23'),
('91883c41-8997-45f7-8800-17fd3a636a0b','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','ad71952e-7842-599e-a19e-3a82e6974b23','GET /secrets/resource/7672b60a-f739-48fe-9265-1ac6f710557f.json',1,'2026-07-21 16:53:49'),
('92d0bd24-fe8f-43b2-b9f8-8fc76828613f','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','a04f2607-8cb6-56c6-a9cb-6b9c7603bacd','GET /rbacs/me.json',1,'2026-07-21 01:19:16'),
('92d9bdd1-5870-41f1-9c49-2e4bf15e5733','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','9b473b19-0e3e-5efb-be19-8a1719843762','GET /account/settings.json',1,'2026-07-09 09:05:15'),
('93bcc371-ca46-4f85-a6c1-b9f9e2c5689b',NULL,'bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-16 04:50:19'),
('94138bec-f362-4779-9d9a-84f65f5e9e5c','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','e2aa01a9-84ec-55f8-aaed-24ee23259339','GET /resource-types.json',1,'2026-07-09 09:05:16'),
('9475e8c0-18ce-48c5-a91b-7f7171e23f61','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-09 08:46:05'),
('94aa3f70-6c5d-427f-b04c-2ab4b6c401c1','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-21 16:27:09'),
('94ace5f7-cf68-4ab6-a8e7-761760dff783','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','6729d30a-1efa-53a4-8c03-e7542b2fedbe','GET /password-expiry/settings.json',1,'2026-07-21 01:19:16'),
('95fc8584-65d8-48ff-b9ac-871a02444204','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-21 01:40:48'),
('96425596-9af6-455a-adfc-9d8e072a1cd8',NULL,'bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-22 11:57:14'),
('96e516e0-49fa-45a0-8df9-ba282627eb94','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-21 16:29:38'),
('974443ba-5d23-41e0-a075-7e59cef94eb4','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','12c1b158-0100-53d8-a979-83d3cc4a86bc','GET /metadata/types/settings.json',1,'2026-07-21 01:40:30'),
('97986f04-c5e9-4a46-852e-ee8b8cf81790','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','83bb8bd8-2006-5546-a3bb-9319ae6e8f9d','GET /resources/b3f7b360-be12-4011-af21-756bae51f93b.json',1,'2026-07-21 16:32:24'),
('97a4962f-f784-46c6-b960-d8d8e8310882','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-21 01:56:31'),
('97d9beaa-a31f-41f1-906e-b757a42921fc','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','19f9a792-3495-597b-bc94-dff1bc3e3967','POST /auth/logout.json',1,'2026-07-21 01:42:11'),
('98180a76-3711-4041-8930-eab9ae6bef96','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/2c22e1ca-66dc-4107-b375-f2d0d13dab9b.json',1,'2026-07-09 08:46:07'),
('98b7f1c8-b0b4-487d-bcf5-c21cbbb763a9','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-09 08:47:51'),
('991bda61-b2b7-467a-8bbf-c32c4c0011f2','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/2c22e1ca-66dc-4107-b375-f2d0d13dab9b.json',1,'2026-07-09 09:05:15'),
('999c4a5a-0007-43a5-a218-f65f66b05874','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 19:44:43'),
('99b97389-458c-456b-9f74-16e23baa5da6','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','1cd53591-cb6b-5b03-b0be-05a54644263d','GET /folders.json',1,'2026-07-21 16:29:39'),
('9ad74111-4141-431d-ab32-2ff063185da4','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 16:50:46'),
('9b0cbc3f-34d8-4166-bffa-1c521ab917a2','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','3cffe6ef-ea4c-5bc3-869b-945f26e2601a','GET /groups.json',1,'2026-07-09 09:05:24'),
('9be0dffb-c069-4a15-a37c-cc14d670f896',NULL,'bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-09 09:03:28'),
('9bea8e52-be5f-4101-a3b5-d41cd9d9b291','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','c506210f-7866-5691-8fc1-58772e8f49f1','GET /resources.json',1,'2026-07-09 08:48:59'),
('9cdfb0c8-fceb-4b89-a030-c8ec8d8376e9','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','ad71952e-7842-599e-a19e-3a82e6974b23','GET /secrets/resource/b3f7b360-be12-4011-af21-756bae51f93b.json',1,'2026-07-21 01:41:40'),
('9d0d3d78-bbd6-4727-a820-e895a01c39d8',NULL,'bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-26 16:25:39'),
('9d168f08-4e9a-48df-bbc1-549ed455cf7f','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-09 09:05:15'),
('9d4773a7-cda2-44cc-9523-f44b0972360b','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-09 08:47:52'),
('9ddb68ed-2388-4b3e-8314-e1d18979edb1','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','ab13b3e0-eae8-5099-909f-8582a3c2ddae','GET /folders/50d49e9b-5e79-497d-876d-3eaddb5644fe.json',1,'2026-07-09 08:50:59'),
('9e280437-9dc1-4924-a8b6-537f26117111','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 18:29:42'),
('9ecfbadd-5edc-4560-bf20-ce0690906228','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','9b473b19-0e3e-5efb-be19-8a1719843762','GET /account/settings.json',1,'2026-07-09 08:47:51'),
('9efdb72c-8f20-4c93-9743-2412f7fb61d2',NULL,'bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-22 23:28:13'),
('9f38310b-954c-4472-853c-47d85969850a','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','ab13b3e0-eae8-5099-909f-8582a3c2ddae','GET /folders/50d49e9b-5e79-497d-876d-3eaddb5644fe.json',1,'2026-07-09 08:49:39'),
('9f6bd47e-75c3-403d-8a8d-5cd205b605b4',NULL,'17b8a54b-8069-586a-8ca2-7e7569b28e08','HEAD /',0,'2026-07-08 23:10:32'),
('9f782be4-457f-4209-9700-771560aa73c4','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','ab13b3e0-eae8-5099-909f-8582a3c2ddae','GET /folders/50d49e9b-5e79-497d-876d-3eaddb5644fe.json',1,'2026-07-09 08:49:57'),
('9ff05732-270e-42e4-b3ec-6125367c54a1','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','d7bc9044-a64e-5421-a4d7-7a94eaa39d37','GET /users.json',1,'2026-07-09 08:47:02'),
('a008f1ce-dc6f-4440-a009-25b4a301b7f7','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','ad71952e-7842-599e-a19e-3a82e6974b23','GET /secrets/resource/7672b60a-f739-48fe-9265-1ac6f710557f.json',1,'2026-07-21 01:42:10'),
('a267bcb5-868d-4e1d-b910-2c45de608425','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','9b473b19-0e3e-5efb-be19-8a1719843762','GET /account/settings.json',1,'2026-07-21 01:19:16'),
('a2b34bcd-daab-4313-89df-24b38bbe5d0b',NULL,'bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-24 10:14:05'),
('a2c6a9dd-b3a0-4f3e-9b25-2ebdfae94440','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 01:40:32'),
('a3ad4438-0796-498a-a630-0fb1c1967d04','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-09 10:20:28'),
('a3ebb498-1343-4632-b546-e53729d0f142','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-26 14:13:09'),
('a4078d5b-d531-4439-ac5c-95b86b66dd3d',NULL,'50ca4a19-b782-5842-bd2b-f59e9ff4eef9','GET /setup/install/2c22e1ca-66dc-4107-b375-f2d0d13dab9b/adb3e344-7b5e-11f1-8fe4-0e10625e4baf.json',1,'2026-07-09 08:45:11'),
('a4120bde-9a97-424c-9ebf-0c35435769d0','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/2c22e1ca-66dc-4107-b375-f2d0d13dab9b.json',1,'2026-07-21 01:19:16'),
('a477dbdd-48fb-41fc-9e24-daffe0a98a67','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','12c1b158-0100-53d8-a979-83d3cc4a86bc','GET /metadata/types/settings.json',1,'2026-07-21 16:32:23'),
('a5283aa8-5a50-4cf0-bdda-6108103abf64',NULL,'bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-09 12:49:09'),
('a56c4fdf-4d38-49d0-8f7b-1b168c161856','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','1cd53591-cb6b-5b03-b0be-05a54644263d','GET /folders.json',1,'2026-07-09 08:51:32'),
('a719e817-4d18-45b5-b79f-2fa940a753d4','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','b20e3cc2-e4ea-5b42-804b-7edc9878ef3d','GET /metadata/keys/settings.json',1,'2026-07-21 01:39:32'),
('a7a735f3-4f1e-4a29-940d-7fca013441a6','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','19f9a792-3495-597b-bc94-dff1bc3e3967','POST /auth/logout.json',1,'2026-07-21 01:39:57'),
('a86701cc-12cd-4ff9-961f-a23305f1bacb','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','b20e3cc2-e4ea-5b42-804b-7edc9878ef3d','GET /metadata/keys/settings.json',1,'2026-07-21 16:53:49'),
('a912e013-0f18-4768-bbfb-04f3df6888af','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/login.json',1,'2026-07-21 01:40:29'),
('a96d4ffd-0467-4630-9a84-a8061baf6f19','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 17:29:40'),
('a986e086-6138-4964-a73f-f4893582506e','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','1cd53591-cb6b-5b03-b0be-05a54644263d','GET /folders.json',1,'2026-07-09 08:48:37'),
('a9aec90c-ac9d-4a72-953f-3a0df10b7902','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','1df624ae-eea2-5055-a202-d1068feefe04','GET /permissions/resource/b3f7b360-be12-4011-af21-756bae51f93b.json',1,'2026-07-21 16:31:37'),
('aa10b047-339a-4276-b3ca-3ed5d4ed807c','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','ad71952e-7842-599e-a19e-3a82e6974b23','GET /secrets/resource/b3f7b360-be12-4011-af21-756bae51f93b.json',1,'2026-07-21 01:41:05'),
('aa1ca548-31e1-4e82-887a-a57a856bd7a2','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 01:40:48'),
('aa7772e9-5f87-4840-ac34-9930fb215dd7','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/2c22e1ca-66dc-4107-b375-f2d0d13dab9b.json',1,'2026-07-09 09:05:16'),
('ab4d486f-e2a9-47ee-ab4f-b778bfdd4148','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','19f9a792-3495-597b-bc94-dff1bc3e3967','POST /auth/logout.json',1,'2026-07-21 01:40:32'),
('abd19ceb-f264-462d-87d4-f78b6a1fcf99','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 16:53:48'),
('ad230c26-62fe-4561-983e-90593f66644b','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','19f9a792-3495-597b-bc94-dff1bc3e3967','POST /auth/logout.json',1,'2026-07-21 16:53:49'),
('ae60fc1d-acb3-4d62-be71-cb5f3dd72c8d','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-21 01:39:56'),
('ae8f49b1-b366-42a1-9cc7-638e34c92d86','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','3718aecb-1f9d-5d6f-83bb-fcd3562d014d','GET /secret-revisions/settings.json',1,'2026-07-09 08:51:00'),
('aed4bccc-4504-425a-9589-2b89a00da209','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-26 13:28:07'),
('af8a6e30-5489-45bc-8ea9-bde67da15c86','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','a04f2607-8cb6-56c6-a9cb-6b9c7603bacd','GET /rbacs/me.json',1,'2026-07-09 09:05:16'),
('afa90e20-d98e-40ad-b7f9-e814a7c35469','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','19f9a792-3495-597b-bc94-dff1bc3e3967','POST /auth/logout.json',1,'2026-07-21 01:41:40'),
('afbf4465-5bbd-4d2e-8ff4-9764f02856d5',NULL,'17b8a54b-8069-586a-8ca2-7e7569b28e08','HEAD /',0,'2026-07-21 01:28:11'),
('b05e84fa-bb1d-45f5-8988-1ed73a01c219','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','f5928fca-ddb3-5a40-b022-9a8bec18fd1c','PUT /resources/b3f7b360-be12-4011-af21-756bae51f93b.json',1,'2026-07-21 16:31:37'),
('b0b3d744-7675-45d8-a861-eb88253a60f6',NULL,'a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/verify.json',1,'2026-07-21 01:18:59'),
('b0fb3d66-2bc5-49c9-b579-a24192099df2','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','c506210f-7866-5691-8fc1-58772e8f49f1','GET /resources.json',1,'2026-07-21 01:39:57'),
('b11bf9f7-b95b-4d5b-ab10-d9d74b1f4e04','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','d77de180-4626-54dd-80fb-a095ecc22aac','GET /resource-types/a28a04cd-6f53-518a-967c-9963bf9cec51.json',1,'2026-07-21 01:41:23'),
('b122a897-f5c5-40cd-b9e5-1fa451334b8f',NULL,'a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/verify.json',1,'2026-07-26 12:57:55'),
('b1478dd5-c9ab-40d1-8708-f7af4e9c1151','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 19:59:43'),
('b147d86b-8903-4f97-bfed-66a71c23e67e','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 16:32:23'),
('b1f425d5-20b0-4119-aead-bc3e56048796','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','c506210f-7866-5691-8fc1-58772e8f49f1','GET /resources.json',1,'2026-07-09 08:49:54'),
('b319f7d5-850d-4231-a232-b274bcc2aa06','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','f5928fca-ddb3-5a40-b022-9a8bec18fd1c','PUT /resources/b3f7b360-be12-4011-af21-756bae51f93b.json',1,'2026-07-21 01:44:28'),
('b3a9403c-b0c3-47ea-9112-303e157e6444','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/login.json',1,'2026-07-21 01:41:22'),
('b59f9955-010e-4fa0-a265-32784060001c',NULL,'a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/login.json',1,'2026-07-21 01:41:39'),
('b5e29274-b642-407a-a729-960133da3b67','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','e73a6dad-9742-5f38-8929-180d09e1397a','GET /metadata/settings/getting-started.json',1,'2026-07-09 08:47:51'),
('b7149e50-4ab9-49c2-a920-88f2dd31c0d4','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/login.json',1,'2026-07-21 01:19:14'),
('b79570ee-0c45-470d-a7e7-75b41d93eb97',NULL,'08903e2d-1cb6-5908-8dbc-25b7a54e6bc4','GET /healthcheck',0,'2026-07-06 22:26:46'),
('b7f9c4b2-4206-4ec5-9d5d-09053a0cbd24',NULL,'50ca4a19-b782-5842-bd2b-f59e9ff4eef9','GET /setup/start/2c22e1ca-66dc-4107-b375-f2d0d13dab9b/adb3e344-7b5e-11f1-8fe4-0e10625e4baf',1,'2026-07-09 08:44:30'),
('b80ba471-f5d0-46c5-bc72-dfb6f44e7b7a','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','19f9a792-3495-597b-bc94-dff1bc3e3967','POST /auth/logout.json',1,'2026-07-21 01:47:28'),
('b87d924f-0388-4b0c-9457-1e6c7cae8322',NULL,'bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-22 23:28:13'),
('b8eebc65-601f-4d1b-8119-530575a240f3','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','c506210f-7866-5691-8fc1-58772e8f49f1','GET /resources.json',1,'2026-07-09 08:49:41'),
('b8f249ad-673b-4b12-b71f-f5cb8a7076c1',NULL,'a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/login.json',1,'2026-07-09 09:05:14'),
('b922120a-98bc-4915-a770-64c8922c5aab','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 16:59:38'),
('b9521b10-cfd2-47c6-b337-72eb6e105384','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','ab13b3e0-eae8-5099-909f-8582a3c2ddae','GET /folders/50d49e9b-5e79-497d-876d-3eaddb5644fe.json',1,'2026-07-21 01:39:35'),
('b961a9b0-586b-47aa-83b5-553cb452c3f8','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','3cffe6ef-ea4c-5bc3-869b-945f26e2601a','GET /groups.json',1,'2026-07-26 16:26:01'),
('b96d133b-b190-4749-acf1-d4ac24a4beba','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','b20e3cc2-e4ea-5b42-804b-7edc9878ef3d','GET /metadata/keys/settings.json',1,'2026-07-21 16:29:38'),
('b9732e49-79b4-4043-83c6-b39409ffbdf4','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 22:59:47'),
('b9820bd4-987d-4953-a78e-b65c5b7435d9','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','d77de180-4626-54dd-80fb-a095ecc22aac','GET /resource-types/a28a04cd-6f53-518a-967c-9963bf9cec51.json',1,'2026-07-21 16:50:47'),
('b9edebc0-8752-45e6-b310-03db9131a646','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','e2aa01a9-84ec-55f8-aaed-24ee23259339','GET /resource-types.json',1,'2026-07-21 01:47:26'),
('ba074c5c-ce18-4107-892a-ce50fce1724e','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','c506210f-7866-5691-8fc1-58772e8f49f1','GET /resources.json',1,'2026-07-21 01:39:35'),
('ba11a970-a2be-4528-ba07-0a0b3a291d85','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','72a35b3d-5baf-57cd-b6ba-a946bd879ad4','GET /password-policies/settings.json',1,'2026-07-26 12:58:08'),
('ba18798b-c4ee-453b-98cc-900aff2ef3cc',NULL,'bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-22 00:08:55'),
('bae9a13a-becb-443d-9e07-1a4482bd594e',NULL,'bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-26 16:25:37'),
('bb4322be-7d2d-40d3-865d-a400246e9632',NULL,'bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-09 12:54:44'),
('bbb834cf-1700-4bda-a12a-3cc6cc5bfa5a','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','e2aa01a9-84ec-55f8-aaed-24ee23259339','GET /resource-types.json',1,'2026-07-21 01:39:57'),
('bc8ece00-8e26-4279-b8f2-81729b04e8fb','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','c506210f-7866-5691-8fc1-58772e8f49f1','GET /resources.json',1,'2026-07-26 12:58:33'),
('bdc4bb0d-587a-484c-82f9-6129b9c7e515','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','d77de180-4626-54dd-80fb-a095ecc22aac','GET /resource-types/a28a04cd-6f53-518a-967c-9963bf9cec51.json',1,'2026-07-21 01:56:31'),
('bde6340b-890b-4254-97a7-e7a8e6a5d6e9','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','1cd53591-cb6b-5b03-b0be-05a54644263d','GET /folders.json',1,'2026-07-26 16:26:01'),
('be4d23b2-e0b3-45c7-9c18-492c662f35d2','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','b20e3cc2-e4ea-5b42-804b-7edc9878ef3d','GET /metadata/keys/settings.json',1,'2026-07-21 01:40:32'),
('bedc8d2e-1392-48e3-8942-a34583ac1fcd','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-09 10:35:14'),
('bf1ee1f4-ad2d-4b1b-bf39-6b7fddc845f2',NULL,'bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-09 08:45:06'),
('c018af05-18a6-4522-9ff0-4473e4cd6a1f','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','e73a6dad-9742-5f38-8929-180d09e1397a','GET /metadata/settings/getting-started.json',1,'2026-07-09 08:47:35'),
('c0d19702-6e61-4ae6-8de5-9ff0b9cd1e85','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-21 01:40:30'),
('c0d8176b-b17a-41a1-ad30-07fb7f2b8e16','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','12c1b158-0100-53d8-a979-83d3cc4a86bc','GET /metadata/types/settings.json',1,'2026-07-26 12:58:08'),
('c14e7ee0-4ad0-4ddd-a75f-e78280404f67','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','6729d30a-1efa-53a4-8c03-e7542b2fedbe','GET /password-expiry/settings.json',1,'2026-07-09 09:05:16'),
('c17a7cd3-7adc-45ba-89aa-944c4b08854f','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-09 11:20:15'),
('c1a07ab0-e498-4301-be3a-51e7c1a56533','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-09 10:05:14'),
('c2395049-cf52-44b1-9f91-86b2097810c5','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','12c1b158-0100-53d8-a979-83d3cc4a86bc','GET /metadata/types/settings.json',1,'2026-07-21 01:41:05'),
('c260ae92-aef9-4f0f-9a94-a14580d7ee94','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','30259dec-c224-509d-b742-96e2a6a85475','GET /mfa/setup/select.json',1,'2026-07-09 08:51:15'),
('c2928b81-afec-48ec-a3ee-85d0ffd79c39','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','72a35b3d-5baf-57cd-b6ba-a946bd879ad4','GET /password-policies/settings.json',1,'2026-07-09 08:46:07'),
('c3b3b420-2523-4d6c-a61b-93610186391c','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','19f9a792-3495-597b-bc94-dff1bc3e3967','POST /auth/logout.json',1,'2026-07-21 01:40:49'),
('c408e07c-d5ef-424f-be07-a87305c1f82b',NULL,'bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-09 08:44:31'),
('c4fad951-8226-464d-8d20-34346a2c8ac5','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','e2aa01a9-84ec-55f8-aaed-24ee23259339','GET /resource-types.json',1,'2026-07-26 16:26:01'),
('c57fc33f-907c-4d36-8309-c9b8dd0269c5','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','12c1b158-0100-53d8-a979-83d3cc4a86bc','GET /metadata/types/settings.json',1,'2026-07-21 01:39:57'),
('c66d57d0-f586-4407-98bc-8f54712511ef',NULL,'17b8a54b-8069-586a-8ca2-7e7569b28e08','HEAD /setup/start/2c22e1ca-66dc-4107-b375-f2d0d13dab9b/7e8bc0b3-14af-493e-8052-2ed4a2f46790',0,'2026-07-08 23:56:27'),
('c6c26d80-ea8a-4b65-9e8a-feacce1a9e46',NULL,'50ca4a19-b782-5842-bd2b-f59e9ff4eef9','GET /setup/start/2c22e1ca-66dc-4107-b375-f2d0d13dab9b/adb3e344-7b5e-11f1-8fe4-0e10625e4baf.json',1,'2026-07-09 08:45:07'),
('c770b6bb-9a2a-45dc-b7c4-464fae4e51de',NULL,'bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-11 23:08:09'),
('c79a5ccd-c8b0-4928-8974-ffdc98fce79d','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','1cd53591-cb6b-5b03-b0be-05a54644263d','GET /folders.json',1,'2026-07-09 09:05:16'),
('c7ba17b1-7a49-4c7a-b6e2-58fb11bf54b7',NULL,'bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-21 01:18:58'),
('c7d49fb4-7339-43bf-93c9-1e4fefab7bbf','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','b20e3cc2-e4ea-5b42-804b-7edc9878ef3d','GET /metadata/keys/settings.json',1,'2026-07-21 01:41:05'),
('c82e031e-d2d1-455c-a120-082a5c922503','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','19f9a792-3495-597b-bc94-dff1bc3e3967','POST /auth/logout.json',1,'2026-07-21 16:50:48'),
('c8de6f10-b892-434e-a7ce-54dace38c66a','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-09 12:20:15'),
('ca45f023-6559-4161-9aaa-fadd02544883',NULL,'bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-09 08:45:06'),
('cacc573e-c019-41af-9a6f-0930f46079f3','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/2c22e1ca-66dc-4107-b375-f2d0d13dab9b.json',1,'2026-07-09 08:47:51'),
('cb2c20a1-097b-4de9-be6d-1798ba72e2f8','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','30259dec-c224-509d-b742-96e2a6a85475','GET /mfa/setup/select.json',1,'2026-07-09 08:51:15'),
('cb388b31-0954-4e55-9748-e4154f19011b','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','6729d30a-1efa-53a4-8c03-e7542b2fedbe','GET /password-expiry/settings.json',1,'2026-07-21 16:29:38'),
('cc0ef618-16eb-46f4-99da-d22145d6c8cd',NULL,'bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-26 12:57:54'),
('cc458c4f-be71-4979-be04-ca82558bc5a7','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','b20e3cc2-e4ea-5b42-804b-7edc9878ef3d','GET /metadata/keys/settings.json',1,'2026-07-21 01:39:34'),
('cc856d9c-adf5-4d60-8a82-2c3f64efaed3','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','d77de180-4626-54dd-80fb-a095ecc22aac','GET /resource-types/a28a04cd-6f53-518a-967c-9963bf9cec51.json',1,'2026-07-21 16:53:49'),
('cd4b86ad-7713-46fc-bd13-c01cbf245f0d','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','b20e3cc2-e4ea-5b42-804b-7edc9878ef3d','GET /metadata/keys/settings.json',1,'2026-07-21 01:39:57'),
('cf349fb7-92eb-4a21-ac73-c0b57992b675','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','058f384b-6685-55ac-8e82-9b0579a4e210','GET /account/settings/themes.json',1,'2026-07-09 08:51:30'),
('cf3ba405-5a13-4658-a505-3b1b53b2b501','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','e73a6dad-9742-5f38-8929-180d09e1397a','GET /metadata/settings/getting-started.json',1,'2026-07-21 01:34:57'),
('cf564905-9da4-408c-8203-ab4a56fddd52','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 21:29:47'),
('cf89a934-a5fb-4f65-a0f1-700ea8a31b69','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-26 14:28:09'),
('cf9f3e32-3243-4af9-b7db-5014385d5a7c',NULL,'a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/login.json',1,'2026-07-21 01:56:30'),
('cffa9349-a858-4adc-921d-5daa14638ee0','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-21 01:41:04'),
('cffcd7e9-4297-4c62-938a-5c40b11c672b',NULL,'bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-09 09:03:28'),
('d08161b4-4da7-424a-b483-a04ddbfba2ff','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','9b473b19-0e3e-5efb-be19-8a1719843762','GET /account/settings.json',1,'2026-07-09 08:46:07'),
('d1d1384f-bbce-4999-8ae0-2ad064f72b3b','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-09 09:50:14'),
('d1ef4f53-6220-4605-ba8f-9bb259495e90',NULL,'bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-09 08:45:07'),
('d2dca42e-a73c-4ec9-920b-4b0c4432ffa6','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/2c22e1ca-66dc-4107-b375-f2d0d13dab9b.json',1,'2026-07-09 09:05:23'),
('d3bc425f-1bb3-4cb2-9074-36c56b9a7b42','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','bbcc91fb-c9fe-5a24-aaf6-0d36b61f9559','POST /account/settings/themes.json',1,'2026-07-09 08:48:33'),
('d3bc735b-f97d-4d22-bb43-3b3db9f5fc5f','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','9b473b19-0e3e-5efb-be19-8a1719843762','GET /account/settings.json',1,'2026-07-09 08:47:30'),
('d3d206cc-07bc-45e7-830c-b03c09b15269','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/2c22e1ca-66dc-4107-b375-f2d0d13dab9b.json',1,'2026-07-09 08:46:05'),
('d42681c8-ed94-4533-a478-bee70983c14a','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-21 01:41:39'),
('d465d055-4f99-4453-9184-8f9e1304d502',NULL,'a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/verify.json',1,'2026-07-21 01:18:59'),
('d471e8f8-9e07-4fd6-b9ba-b520b477046f','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','12c1b158-0100-53d8-a979-83d3cc4a86bc','GET /metadata/types/settings.json',1,'2026-07-21 16:53:48'),
('d50beee1-e1f4-4004-9981-2e037b7dc711','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','1035f824-fe76-5a69-b02c-9aa60a31858c','GET /app/passwords/view/edaec922-7cdf-40ec-8fa9-273015d3c125',1,'2026-07-26 16:25:59'),
('d5c11755-545f-4ce4-b798-30f269765089','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','b20e3cc2-e4ea-5b42-804b-7edc9878ef3d','GET /metadata/keys/settings.json',1,'2026-07-21 01:47:27'),
('d5d4da64-2e2a-4f82-89e8-fd14ebf2f628',NULL,'17b8a54b-8069-586a-8ca2-7e7569b28e08','GET /ee/subscription/key.json',0,'2026-07-09 08:47:02'),
('d6230e03-81cd-401f-bc24-b35cce5ad938','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','1df624ae-eea2-5055-a202-d1068feefe04','GET /permissions/resource/b3f7b360-be12-4011-af21-756bae51f93b.json',1,'2026-07-21 01:44:28'),
('d7a5785d-0f69-48fb-99b5-3a326ad13e3c','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','c506210f-7866-5691-8fc1-58772e8f49f1','GET /resources.json',1,'2026-07-09 08:48:37'),
('d895af79-1330-4591-acc1-05639f8a89ee','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 22:14:47'),
('d8a55ffd-9ebb-4789-bc5e-8df38c06294d','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','1035f824-fe76-5a69-b02c-9aa60a31858c','GET /',1,'2026-07-09 08:46:06'),
('d974c6f5-ed14-4842-94bb-c7e33a915be7',NULL,'bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-21 01:18:57'),
('d9bbec44-f942-4b86-afb5-ea950c1acbbd','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-09 08:47:34'),
('d9d6f66c-5d30-409d-9e42-8f00595e9f10','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','b20e3cc2-e4ea-5b42-804b-7edc9878ef3d','GET /metadata/keys/settings.json',1,'2026-07-21 01:41:22'),
('da56a8c2-2a23-47b5-be85-9367d6ffac67','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','6729d30a-1efa-53a4-8c03-e7542b2fedbe','GET /password-expiry/settings.json',1,'2026-07-09 08:46:07'),
('dbc97d49-d176-4828-bb42-deefad4f76c2','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','e2aa01a9-84ec-55f8-aaed-24ee23259339','GET /resource-types.json',1,'2026-07-21 01:39:33'),
('dd8979e3-c408-4cbe-8378-d9c839791d62','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','3cffe6ef-ea4c-5bc3-869b-945f26e2601a','GET /groups.json',1,'2026-07-09 08:46:07'),
('ddfde9ca-690e-46b3-ab51-83c63fdb5b78','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','3cffe6ef-ea4c-5bc3-869b-945f26e2601a','GET /groups.json',1,'2026-07-09 09:05:16'),
('de23609f-7d86-4c85-81a0-c980053ad5bc','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','12c1b158-0100-53d8-a979-83d3cc4a86bc','GET /metadata/types/settings.json',1,'2026-07-09 09:05:16'),
('dfc90bf3-47cd-4927-8cd4-52d606d4a668','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','e2aa01a9-84ec-55f8-aaed-24ee23259339','GET /resource-types.json',1,'2026-07-21 01:39:35'),
('e02b983d-4bca-4793-a7cf-6c0f416d399a','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-21 01:42:10'),
('e07a2e84-cf66-427b-8ca9-8ced281949bf','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','83bb8bd8-2006-5546-a3bb-9319ae6e8f9d','GET /resources/7672b60a-f739-48fe-9265-1ac6f710557f.json',1,'2026-07-21 01:42:10'),
('e17256e5-16a7-468b-9731-9a331643d13a','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-26 15:13:10'),
('e189aaa8-b643-467b-8001-0d901d55df9d','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','6729d30a-1efa-53a4-8c03-e7542b2fedbe','GET /password-expiry/settings.json',1,'2026-07-26 16:26:01'),
('e22ad3a5-d279-418f-8afa-d82c1125876c','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','c506210f-7866-5691-8fc1-58772e8f49f1','GET /resources.json',1,'2026-07-09 08:49:17'),
('e25916da-44a9-4e8e-923c-59c0ec154fed',NULL,'bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-09 08:45:07'),
('e268c815-6112-4fd1-b5d3-37f7674ef50a','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','3cffe6ef-ea4c-5bc3-869b-945f26e2601a','GET /groups.json',1,'2026-07-21 16:29:38'),
('e26f0811-b61f-4691-9b9f-7243a8b04da4','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','ad71952e-7842-599e-a19e-3a82e6974b23','GET /secrets/resource/b3f7b360-be12-4011-af21-756bae51f93b.json',1,'2026-07-21 16:29:51'),
('e28ce0ed-caae-402c-bd0d-8e5c0b8de6a4','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','72a35b3d-5baf-57cd-b6ba-a946bd879ad4','GET /password-policies/settings.json',1,'2026-07-21 16:29:38'),
('e4093386-f38e-4054-9553-6b91f37e7188','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-09 12:35:15'),
('e451e257-5fd8-494f-a719-54c98e966e18','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','d7bc9044-a64e-5421-a4d7-7a94eaa39d37','GET /users.json',1,'2026-07-21 01:44:28'),
('e53cf862-8564-4c63-8d85-c682abe7d042',NULL,'748dcd10-7d15-5498-9aa6-d26de348ff02','GET /auth/verify.json',1,'2026-07-09 08:45:07'),
('e57edde9-bea6-4ca3-b75e-0aa7c955f0e0','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','12c1b158-0100-53d8-a979-83d3cc4a86bc','GET /metadata/types/settings.json',1,'2026-07-26 16:26:01'),
('e5ee3c0d-ac2a-4b3b-9be8-c4f000362530','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/login.json',1,'2026-07-26 16:25:59'),
('e68f9b00-aa3e-450a-9316-749c4a50b011','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','c506210f-7866-5691-8fc1-58772e8f49f1','GET /resources.json',1,'2026-07-09 10:20:28'),
('e73c4aa6-28ff-4445-a5d3-7827e4980b58','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','b20e3cc2-e4ea-5b42-804b-7edc9878ef3d','GET /metadata/keys/settings.json',1,'2026-07-21 01:56:31'),
('e830cd85-0a78-4710-838d-66039d0e5baf','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 18:59:43'),
('e830f20c-0c19-47f8-b930-33810b7ba510',NULL,'748dcd10-7d15-5498-9aa6-d26de348ff02','GET /auth/verify.json',1,'2026-07-09 08:45:06'),
('e8bca7df-cdfd-45e8-9b0d-79293911ec39',NULL,'bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-09 08:45:06'),
('e8f512a2-4972-4482-b0c1-d6539a58fbcb','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','dad1db3f-4fbc-5b3a-9db2-b7413885c30c','GET /app/administration/internationalization',1,'2026-07-09 08:47:34'),
('ea3b4e58-f693-4e1e-bd01-a566ba394588','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 01:42:10'),
('ea415310-46ff-4e8b-8221-083840ae2a72','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/login.json',1,'2026-07-21 01:40:47'),
('eaa68f7a-6a70-410b-a263-0aac2542e195','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 21:59:47'),
('eab57646-89e3-43b4-9c42-d3257421ac2a','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','a8b75aae-cb86-5fda-a8b3-d36ae6155023','GET /gpgkeys.json',1,'2026-07-21 16:31:37'),
('ec47c391-aec3-401a-a176-7620cc2d6533',NULL,'a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/login.json',1,'2026-07-21 01:40:29'),
('ed9d89eb-589e-4b27-b14e-7fa0630ce0c9','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','3718aecb-1f9d-5d6f-83bb-fcd3562d014d','GET /secret-revisions/settings.json',1,'2026-07-26 16:26:01'),
('ee9553ac-eb50-4514-91d4-1f367a7ff257','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','f018952e-3020-55e7-9303-a5b326cedcdd','GET /metadata/setup/settings.json',1,'2026-07-09 08:46:06'),
('ef287218-f157-4c4b-ab79-0671106ee1ae',NULL,'a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/login.json',1,'2026-07-21 16:29:36'),
('ef4bdc76-5a07-424e-94cc-b1c5e6665fa3','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','a04f2607-8cb6-56c6-a9cb-6b9c7603bacd','GET /rbacs/me.json',1,'2026-07-26 16:26:00'),
('efcc3abb-4707-4153-9a64-19981fdb44d7','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/login.json',1,'2026-07-21 01:39:34'),
('f089c91e-8543-453d-8998-fc49ca97635b','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','e73a6dad-9742-5f38-8929-180d09e1397a','GET /metadata/settings/getting-started.json',1,'2026-07-09 08:47:52'),
('f0c38cc5-698f-4000-9c8f-be02ad02db46','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','ad71952e-7842-599e-a19e-3a82e6974b23','GET /secrets/resource/7672b60a-f739-48fe-9265-1ac6f710557f.json',1,'2026-07-21 01:56:31'),
('f10bf8c6-1c2b-450e-9509-eab3316cecae',NULL,'50ca4a19-b782-5842-bd2b-f59e9ff4eef9','GET /setup/install/2c22e1ca-66dc-4107-b375-f2d0d13dab9b/adb3e344-7b5e-11f1-8fe4-0e10625e4baf.json',1,'2026-07-09 08:45:09'),
('f1c3e82c-433d-49ea-b1c4-1d0370f64564','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','ad8bbc35-6435-538e-b1a7-80b87bcedb6a','POST /resources.json',1,'2026-07-26 13:44:01'),
('f20400d3-2eda-4788-842b-3790370a91e7',NULL,'bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-09 08:45:06'),
('f2177e14-c5ca-4dd3-8ca0-8dcb31514dee','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','b20e3cc2-e4ea-5b42-804b-7edc9878ef3d','GET /metadata/keys/settings.json',1,'2026-07-21 01:42:10'),
('f2764147-1ec4-4de1-b48b-7f47bf1f625e','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 01:47:27'),
('f2fc016d-b82b-438e-8ee0-40d0f731a8e3',NULL,'bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-21 03:26:28'),
('f46e0df3-300a-40af-b219-10aa24314962','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 21:44:47'),
('f62c985b-4759-40f2-8690-4fd5388c1143',NULL,'a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/login.json',1,'2026-07-21 01:47:26'),
('f637fdc5-0f6a-4add-84d9-136cdfd803c5',NULL,'bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-21 16:29:31'),
('f77503fe-0ecf-4046-94a6-5e15274aea7d','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','GET /settings.json',1,'2026-07-09 08:47:34'),
('f78ebefe-47eb-4b6b-8599-9673df2e8feb','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/2c22e1ca-66dc-4107-b375-f2d0d13dab9b.json',1,'2026-07-26 16:26:00'),
('f901e248-c102-4be6-a7e1-cce38e12e3ba','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','1cd53591-cb6b-5b03-b0be-05a54644263d','GET /folders.json',1,'2026-07-21 01:38:02'),
('f909bfc6-d0e2-46a0-9910-20668b643790',NULL,'a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/login.json',1,'2026-07-21 01:40:31'),
('f91d4e8e-c600-492a-a3a4-68dd73c95d0c','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','9b473b19-0e3e-5efb-be19-8a1719843762','GET /account/settings.json',1,'2026-07-09 08:47:22'),
('f94cd507-801c-4f5e-985d-c035d56ac92b',NULL,'a3c19ad2-8920-5395-86d0-8567cb34f382','POST /auth/verify.json',1,'2026-07-26 16:24:59'),
('fbcee625-2557-43d9-a829-c86b9dd36691','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','e38db0b5-838d-5f43-8609-92a25843e9d3','GET /metadata/keys.json',1,'2026-07-09 08:50:59'),
('fc2caf0e-779f-4010-a263-cca3eef6be4c','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','19f9a792-3495-597b-bc94-dff1bc3e3967','POST /auth/logout.json',1,'2026-07-21 01:40:31'),
('fc8b4212-3300-462b-bb78-36137bb397db','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-21 20:14:44'),
('fde3081e-0d72-48e6-a148-d45497d38111','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/2c22e1ca-66dc-4107-b375-f2d0d13dab9b.json',1,'2026-07-26 12:58:07'),
('fea93c43-c327-46fb-ae24-024b20cae76f','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','881ab948-e40f-5a72-91aa-54b442270029','GET /users/me.json',1,'2026-07-26 13:43:08'),
('ffbfae59-d800-48f3-9da1-e6b35a5a54ed','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','12c1b158-0100-53d8-a979-83d3cc4a86bc','GET /metadata/types/settings.json',1,'2026-07-21 16:29:38');
/*!40000 ALTER TABLE `action_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `actions`
--

DROP TABLE IF EXISTS `actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `actions` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `actions`
--

LOCK TABLES `actions` WRITE;
/*!40000 ALTER TABLE `actions` DISABLE KEYS */;
INSERT INTO `actions` VALUES
('98b30a6b-2979-5d5c-a8f6-b8a843aa25da','AccountRecoveryRequestsIndex.index'),
('e504a917-b977-5cac-967d-d7f90946861b','AccountRecoveryRequestsView.view'),
('6f880db8-aaaf-5736-8945-6686b3e1b3b9','AccountRecoveryResponsesCreate.post'),
('9b473b19-0e3e-5efb-be19-8a1719843762','AccountSettingsIndex.index'),
('a3c19ad2-8920-5395-86d0-8567cb34f382','AuthLogin.loginPost'),
('19f9a792-3495-597b-bc94-dff1bc3e3967','AuthLogout.logout'),
('748dcd10-7d15-5498-9aa6-d26de348ff02','AuthVerify.verifyGet'),
('17b8a54b-8069-586a-8ca2-7e7569b28e08','Error.error'),
('02e18a01-42f6-5e5d-b18f-2ee9070e3b9d','FoldersCreate.create'),
('1cd53591-cb6b-5b03-b0be-05a54644263d','FoldersIndex.index'),
('ab13b3e0-eae8-5099-909f-8582a3c2ddae','FoldersView.view'),
('a8b75aae-cb86-5fda-a8b3-d36ae6155023','GpgkeysIndex.index'),
('5bd4ecae-da08-577d-ac32-ce7b13bd7b0f','GroupsAdd.addPost'),
('3cffe6ef-ea4c-5bc3-869b-945f26e2601a','GroupsIndex.index'),
('08903e2d-1cb6-5908-8dbc-25b7a54e6bc4','HealthcheckIndex.index'),
('dad1db3f-4fbc-5b3a-9db2-b7413885c30c','Home.apiApp'),
('1035f824-fe76-5a69-b02c-9aa60a31858c','Home.apiExtApp'),
('e38db0b5-838d-5f43-8609-92a25843e9d3','MetadataKeysIndex.index'),
('b20e3cc2-e4ea-5b42-804b-7edc9878ef3d','MetadataKeysSettingsGet.get'),
('e73a6dad-9742-5f38-8929-180d09e1397a','MetadataSettingsGetStarted.get'),
('f018952e-3020-55e7-9303-a5b326cedcdd','MetadataSettingsSetup.get'),
('12c1b158-0100-53d8-a979-83d3cc4a86bc','MetadataTypesSettingsGet.get'),
('30259dec-c224-509d-b742-96e2a6a85475','MfaSetupSelectProvider.get'),
('2c50bb0d-c13b-517c-9930-ad29fcbc7d81','OrganizationLocalesSelect.select'),
('6729d30a-1efa-53a4-8c03-e7542b2fedbe','PasswordExpirySettingsGet.get'),
('72a35b3d-5baf-57cd-b6ba-a946bd879ad4','PasswordPoliciesSettingsGet.get'),
('1df624ae-eea2-5055-a202-d1068feefe04','PermissionsView.viewAcoPermissions'),
('a04f2607-8cb6-56c6-a9cb-6b9c7603bacd','RbacsView.viewForCurrentRole'),
('ad8bbc35-6435-538e-b1a7-80b87bcedb6a','ResourcesAdd.add'),
('c506210f-7866-5691-8fc1-58772e8f49f1','ResourcesIndex.index'),
('f5928fca-ddb3-5a40-b022-9a8bec18fd1c','ResourcesUpdate.update'),
('83bb8bd8-2006-5546-a3bb-9319ae6e8f9d','ResourcesView.view'),
('e2aa01a9-84ec-55f8-aaed-24ee23259339','ResourceTypesIndex.index'),
('d77de180-4626-54dd-80fb-a095ecc22aac','ResourceTypesView.view'),
('30237a18-fd12-5935-b1be-1e2a62ccb71d','RolesIndex.index'),
('3718aecb-1f9d-5d6f-83bb-fcd3562d014d','SecretRevisionsSettingsGet.get'),
('ad71952e-7842-599e-a19e-3a82e6974b23','SecretsView.view'),
('bef9f3ca-86ef-5c6a-9b38-320e03ceb5df','SettingsIndex.index'),
('6f53faec-0c9e-5321-ac78-543e1001f7b1','SetupComplete.complete'),
('50ca4a19-b782-5842-bd2b-f59e9ff4eef9','SetupStart.start'),
('058f384b-6685-55ac-8e82-9b0579a4e210','ThemesIndex.index'),
('bbcc91fb-c9fe-5a24-aaf6-0d36b61f9559','ThemesSelect.select'),
('87d717de-7f19-5f3b-88cd-97bcaf26e8fa','UserKeyPoliciesGetSettings.get'),
('d7bc9044-a64e-5421-a4d7-7a94eaa39d37','UsersIndex.index'),
('881ab948-e40f-5a72-91aa-54b442270029','UsersView.view');
/*!40000 ALTER TABLE `actions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authentication_tokens`
--

DROP TABLE IF EXISTS `authentication_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `authentication_tokens` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `token` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `user_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `type` varchar(16) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `data` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `type` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authentication_tokens`
--

LOCK TABLES `authentication_tokens` WRITE;
/*!40000 ALTER TABLE `authentication_tokens` DISABLE KEYS */;
INSERT INTO `authentication_tokens` VALUES
('1825f336-166c-4920-a9cb-2dede0d3a745','d1ace71b-b4b0-427d-b84c-05cd9ee08264','2c22e1ca-66dc-4107-b375-f2d0d13dab9b',0,'2026-07-21 01:41:22','2026-07-21 01:41:22','login',NULL),
('1cdf002c-dffe-4dea-a113-a0cee1e3d447','0533ed0d-f8f4-4859-b9b1-9daa2fad7269','2c22e1ca-66dc-4107-b375-f2d0d13dab9b',0,'2026-07-21 01:39:56','2026-07-21 01:39:56','login',NULL),
('29515002-ce13-40a7-bc7c-d0cb59afbc6f','1ac804fe-5c30-46b7-8a51-7e9574c95593','2c22e1ca-66dc-4107-b375-f2d0d13dab9b',0,'2026-07-21 01:42:09','2026-07-21 01:42:09','login',NULL),
('2c3be019-4dcc-4a6e-bc19-41007310270f','e86e7441-9f40-4530-85b3-dcfc968c8110','2c22e1ca-66dc-4107-b375-f2d0d13dab9b',0,'2026-07-21 16:50:46','2026-07-21 16:50:46','login',NULL),
('36d447ce-aad0-43ef-9c90-434df74dfe8c','adb39f88-7b5e-11f1-8fe4-0e10625e4baf','bd3c4edd-805f-4c49-9c76-a53270539320',1,'2026-07-09 00:42:53','2026-07-09 06:23:19','register',NULL),
('47229173-66ca-4620-9807-10c79eb12527','0469739f-65cf-4c3c-9c31-364bd4758eeb','2c22e1ca-66dc-4107-b375-f2d0d13dab9b',0,'2026-07-21 16:32:23','2026-07-21 16:32:23','login',NULL),
('4da5ceca-b9c0-45c7-b44d-24382e9714b7','b2468651-1334-4886-a8c9-f113798d14b3','2c22e1ca-66dc-4107-b375-f2d0d13dab9b',0,'2026-07-21 16:29:36','2026-07-21 16:29:36','login',NULL),
('5fc6f078-ffd7-4fc3-8400-8b18afcd78e6','6b8594ef-64e7-4001-9e16-eafad4a4b6aa','2c22e1ca-66dc-4107-b375-f2d0d13dab9b',0,'2026-07-21 01:47:24','2026-07-21 01:47:25','login',NULL),
('64dbe5c9-90ba-4af9-be05-59596107dc80','dd1b1590-771a-4644-80ae-b6e9f8a26759','2c22e1ca-66dc-4107-b375-f2d0d13dab9b',0,'2026-07-21 01:40:31','2026-07-21 01:40:32','login',NULL),
('6f796058-ddf1-4c1a-85d1-89cc36dacd2d','a365d004-7afc-486d-97cf-044ca598eaf4','b893fc0d-5ea6-4e4c-9511-fc550d8e7519',1,'2026-07-06 22:26:59','2026-07-06 22:26:59','register',NULL),
('6fdbba3b-951b-4a0a-975f-377ffd07a74e','e4fdbd10-4474-4ad2-bece-28db97bc61f1','2c22e1ca-66dc-4107-b375-f2d0d13dab9b',0,'2026-07-21 01:41:04','2026-07-21 01:41:04','login',NULL),
('73ac32f2-a82b-494c-bee4-3751d57b7df4','1a4d3ea9-b68a-486e-bcdd-a3dbf5f46b0e','2c22e1ca-66dc-4107-b375-f2d0d13dab9b',0,'2026-07-21 01:47:26','2026-07-21 01:47:27','login',NULL),
('75f38373-9f43-4e85-92a3-d97063477ff6','0b4260f0-f1c4-48fe-b05a-5da4fdf05bc4','2c22e1ca-66dc-4107-b375-f2d0d13dab9b',0,'2026-07-21 01:56:30','2026-07-21 01:56:30','login',NULL),
('80ca4057-a8ef-4253-8cb8-802cb3728715','fb6be5c1-7cf9-4efa-aa47-f3900096de4c','2c22e1ca-66dc-4107-b375-f2d0d13dab9b',0,'2026-07-21 01:39:34','2026-07-21 01:39:34','login',NULL),
('9a95441b-9b7d-491e-8142-d23bd01aef35','adb3e2ad-7b5e-11f1-8fe4-0e10625e4baf','51fc08f4-a945-4a70-b5a1-ee0549b66189',1,'2026-07-09 00:42:35','2026-07-09 06:23:19','register',NULL),
('9f3fe689-eea7-463b-a927-1e558bb64c5e','adb3e2fd-7b5e-11f1-8fe4-0e10625e4baf','0741af5f-6ee4-49c0-ab95-a347f9ebe02a',1,'2026-07-09 00:42:52','2026-07-09 06:23:19','register',NULL),
('a2848ec5-2b6e-4d14-a279-a28d93c6e137','5008aafb-cd1d-4f1c-8991-983e041f3d71','2c22e1ca-66dc-4107-b375-f2d0d13dab9b',0,'2026-07-21 01:39:32','2026-07-21 01:39:32','login',NULL),
('a5f0fabb-4ced-4082-a5ab-7936a14f453c','1490c300-0721-41ec-8743-d7ef1968aa4d','2c22e1ca-66dc-4107-b375-f2d0d13dab9b',0,'2026-07-09 08:46:05','2026-07-09 08:46:05','login',NULL),
('aa8adc0c-72d0-42ac-bc5d-6fd7d6dba255','4dce20ce-f493-4abf-9f20-fac9e23923cd','2c22e1ca-66dc-4107-b375-f2d0d13dab9b',0,'2026-07-09 09:05:14','2026-07-09 09:05:14','login',NULL),
('ae401040-68c1-4408-9ddf-8f7ff3d8289f','1aca302b-00d3-458d-894c-55c02dea83d4','2c22e1ca-66dc-4107-b375-f2d0d13dab9b',0,'2026-07-21 01:41:39','2026-07-21 01:41:39','login',NULL),
('b95439e9-a3b3-4ec3-8624-4788527937ac','362653bf-9090-44bb-875a-a7ff4d9b9de8','2c22e1ca-66dc-4107-b375-f2d0d13dab9b',0,'2026-07-21 16:53:48','2026-07-21 16:53:48','login',NULL),
('b992c457-0cac-48fb-9728-0caf8ed4d703','903ec9a2-3821-42e7-9514-9f3fd6fea9df','2c22e1ca-66dc-4107-b375-f2d0d13dab9b',0,'2026-07-21 01:40:47','2026-07-21 01:40:47','login',NULL),
('bcbc03f0-4de0-46b1-845f-b14a0a6b1b83','adb3e322-7b5e-11f1-8fe4-0e10625e4baf','c4c6fdac-fd5d-4980-8601-dfd7fab06f16',1,'2026-07-09 00:42:52','2026-07-09 06:23:19','register',NULL),
('c3079007-02b7-49a1-8f77-4c283ec9efb5','c45b7218-1b4f-4659-a93b-4aee43da1f58','2c22e1ca-66dc-4107-b375-f2d0d13dab9b',0,'2026-07-21 16:27:07','2026-07-21 16:27:08','login',NULL),
('c38c6117-d78c-492d-9925-f96d7eb587d8','adb3e344-7b5e-11f1-8fe4-0e10625e4baf','2c22e1ca-66dc-4107-b375-f2d0d13dab9b',0,'2026-07-08 18:52:16','2026-07-09 08:46:05','register',NULL),
('c78c400e-8be6-4d5d-96ac-e580d956fcf3','b3fb788e-7fff-45d6-affc-255da674f691','2c22e1ca-66dc-4107-b375-f2d0d13dab9b',0,'2026-07-26 12:58:03','2026-07-26 12:58:04','login',NULL),
('d4e4cb05-24da-4752-8706-44ada931304a','40b6b704-c36d-4622-868b-b5703ad81044','2c22e1ca-66dc-4107-b375-f2d0d13dab9b',0,'2026-07-26 16:25:59','2026-07-26 16:25:59','login',NULL),
('eb6eebe4-c1a9-41b1-a3ef-0595e8776d8d','3b832f15-c4c8-49c0-98fa-ee92aeb76a3a','2c22e1ca-66dc-4107-b375-f2d0d13dab9b',0,'2026-07-21 01:19:14','2026-07-21 01:19:14','login',NULL),
('f71d5553-631d-43b5-9ed5-4d6eacfca753','d793d3c5-7c50-45b3-9da9-14683ea7834a','2c22e1ca-66dc-4107-b375-f2d0d13dab9b',0,'2026-07-21 01:40:29','2026-07-21 01:40:29','login',NULL);
/*!40000 ALTER TABLE `authentication_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `avatars`
--

DROP TABLE IF EXISTS `avatars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `avatars` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `data` blob DEFAULT NULL,
  `profile_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `profile_id` (`profile_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `avatars`
--

LOCK TABLES `avatars` WRITE;
/*!40000 ALTER TABLE `avatars` DISABLE KEYS */;
/*!40000 ALTER TABLE `avatars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `comments` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `parent_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  `foreign_key` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `foreign_model` varchar(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `content` varchar(256) NOT NULL,
  `data` mediumtext DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `created_by` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `modified_by` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `user_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`,`foreign_model`,`created_by`,`modified_by`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `directory_entries`
--

DROP TABLE IF EXISTS `directory_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `directory_entries` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `foreign_model` varchar(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `foreign_key` char(36) CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  `directory_name` varchar(256) NOT NULL,
  `directory_created` datetime DEFAULT NULL,
  `directory_modified` datetime DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`,`foreign_model`,`foreign_key`,`directory_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `directory_entries`
--

LOCK TABLES `directory_entries` WRITE;
/*!40000 ALTER TABLE `directory_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `directory_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `directory_ignore`
--

DROP TABLE IF EXISTS `directory_ignore`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `directory_ignore` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `foreign_model` varchar(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`,`foreign_model`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `directory_ignore`
--

LOCK TABLES `directory_ignore` WRITE;
/*!40000 ALTER TABLE `directory_ignore` DISABLE KEYS */;
/*!40000 ALTER TABLE `directory_ignore` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `directory_relations`
--

DROP TABLE IF EXISTS `directory_relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `directory_relations` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `parent_key` char(36) CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  `child_key` char(36) CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`,`parent_key`,`child_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `directory_relations`
--

LOCK TABLES `directory_relations` WRITE;
/*!40000 ALTER TABLE `directory_relations` DISABLE KEYS */;
/*!40000 ALTER TABLE `directory_relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `directory_reports`
--

DROP TABLE IF EXISTS `directory_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `directory_reports` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `parent_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  `status` varchar(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`,`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `directory_reports`
--

LOCK TABLES `directory_reports` WRITE;
/*!40000 ALTER TABLE `directory_reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `directory_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `directory_reports_items`
--

DROP TABLE IF EXISTS `directory_reports_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `directory_reports_items` (
  `report_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `status` varchar(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `model` varchar(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `action` varchar(36) NOT NULL,
  `data` mediumtext DEFAULT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`,`status`,`model`,`action`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `directory_reports_items`
--

LOCK TABLES `directory_reports_items` WRITE;
/*!40000 ALTER TABLE `directory_reports_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `directory_reports_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_queue`
--

DROP TABLE IF EXISTS `email_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_queue` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(129) NOT NULL,
  `from_name` varchar(255) DEFAULT NULL,
  `from_email` varchar(255) DEFAULT NULL,
  `subject` varchar(255) NOT NULL,
  `config` varchar(30) NOT NULL,
  `template` varchar(100) DEFAULT NULL,
  `layout` varchar(50) NOT NULL,
  `theme` varchar(50) NOT NULL,
  `format` varchar(5) NOT NULL,
  `template_vars` longtext NOT NULL,
  `headers` text DEFAULT NULL,
  `sent` tinyint(1) NOT NULL DEFAULT 0,
  `locked` tinyint(1) NOT NULL DEFAULT 0,
  `send_tries` int(2) NOT NULL DEFAULT 0,
  `send_at` datetime DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime DEFAULT NULL,
  `attachments` text DEFAULT NULL,
  `error` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_queue`
--

LOCK TABLES `email_queue` WRITE;
/*!40000 ALTER TABLE `email_queue` DISABLE KEYS */;
INSERT INTO `email_queue` VALUES
(1,'patrick@patty.io',NULL,NULL,'Welcome to passbolt, Patrick!','default','AN/user_register_self','default','','html','{\"body\":{\"user\":{\"id\":\"b893fc0d-5ea6-4e4c-9511-fc550d8e7519\",\"role_id\":\"e66c3a09-1dda-4143-8fd0-4824233698d9\",\"username\":\"patrick@patty.io\",\"active\":false,\"deleted\":false,\"disabled\":null,\"last_logged_in\":null,\"created\":\"2026-07-06T22:26:59+00:00\",\"modified\":\"2026-07-06T22:26:59+00:00\",\"role\":{\"id\":\"e66c3a09-1dda-4143-8fd0-4824233698d9\",\"name\":\"admin\",\"description\":\"Organization administrator\",\"deleted\":null,\"created_by\":null,\"modified_by\":null,\"deleted_by\":null,\"created\":\"2012-07-04T13:39:25+00:00\",\"modified\":\"2012-07-04T13:39:25+00:00\"},\"profile\":{\"id\":\"7ba3c029-53b8-4719-8cb7-defa229cdf0b\",\"user_id\":\"b893fc0d-5ea6-4e4c-9511-fc550d8e7519\",\"first_name\":\"Patrick\",\"last_name\":\"Rho\",\"created\":\"2026-07-06T22:26:59+00:00\",\"modified\":\"2026-07-06T22:26:59+00:00\",\"avatar\":{\"url\":{\"medium\":\"https:\\/\\/100.121.233.93:8443\\/img\\/avatar\\/user_medium.png\",\"small\":\"https:\\/\\/100.121.233.93:8443\\/img\\/avatar\\/user.png\"}}},\"locale\":\"en-UK\"},\"token\":{\"user_id\":\"b893fc0d-5ea6-4e4c-9511-fc550d8e7519\",\"token\":\"a365d004-7afc-486d-97cf-044ca598eaf4\",\"active\":true,\"type\":\"register\",\"data\":null,\"created\":\"2026-07-06T22:26:59+00:00\",\"modified\":\"2026-07-06T22:26:59+00:00\",\"id\":\"6f796058-ddf1-4c1a-85d1-89cc36dacd2d\"},\"fullBaseUrl\":\"https:\\/\\/100.121.233.93:8443\"},\"title\":\"Welcome to passbolt, Patrick!\",\"fullBaseUrl\":\"https:\\/\\/100.121.233.93:8443\",\"locale\":\"en-UK\"}','{\"Auto-Submitted\":\"auto-generated\",\"Message-ID\":\"<3ccbd66ea69343a493624f4352b6d768@100.121.233.93>\"}',0,0,4,'2026-07-06 22:26:59','2026-07-06 22:26:59','2026-07-06 22:26:59','[]','stream_socket_client(): Unable to connect to tcp://localhost:25 (Connection refused)'),
(2,'patrick@patty.io',NULL,NULL,'Welcome to passbolt, Patrick!','default','AN/user_register_self','default','','html','{\"body\":{\"user\":{\"id\":\"2c22e1ca-66dc-4107-b375-f2d0d13dab9b\",\"role_id\":\"e66c3a09-1dda-4143-8fd0-4824233698d9\",\"username\":\"patrick@patty.io\",\"active\":false,\"deleted\":false,\"disabled\":null,\"last_logged_in\":null,\"created\":\"2026-07-08T18:52:16+00:00\",\"modified\":\"2026-07-08T18:52:16+00:00\",\"role\":{\"id\":\"e66c3a09-1dda-4143-8fd0-4824233698d9\",\"name\":\"admin\",\"description\":\"Organization administrator\",\"deleted\":null,\"created_by\":null,\"modified_by\":null,\"deleted_by\":null,\"created\":\"2012-07-04T13:39:25+00:00\",\"modified\":\"2012-07-04T13:39:25+00:00\"},\"profile\":{\"id\":\"45b62c17-d953-4186-825d-30068887222d\",\"user_id\":\"2c22e1ca-66dc-4107-b375-f2d0d13dab9b\",\"first_name\":\"Patrick\",\"last_name\":\"Rho\",\"created\":\"2026-07-08T18:52:16+00:00\",\"modified\":\"2026-07-08T18:52:16+00:00\",\"avatar\":{\"url\":{\"medium\":\"https:\\/\\/100.122.169.71:8443\\/img\\/avatar\\/user_medium.png\",\"small\":\"https:\\/\\/100.122.169.71:8443\\/img\\/avatar\\/user.png\"}}},\"locale\":\"en-UK\"},\"token\":{\"user_id\":\"2c22e1ca-66dc-4107-b375-f2d0d13dab9b\",\"token\":\"7e8bc0b3-14af-493e-8052-2ed4a2f46790\",\"active\":true,\"type\":\"register\",\"data\":null,\"created\":\"2026-07-08T18:52:16+00:00\",\"modified\":\"2026-07-08T18:52:16+00:00\",\"id\":\"c38c6117-d78c-492d-9925-f96d7eb587d8\"},\"fullBaseUrl\":\"https:\\/\\/100.122.169.71:8443\"},\"title\":\"Welcome to passbolt, Patrick!\",\"fullBaseUrl\":\"https:\\/\\/100.122.169.71:8443\",\"locale\":\"en-UK\"}','{\"Auto-Submitted\":\"auto-generated\",\"Message-ID\":\"<8f3f4a1332e1405592c0dba70417d6ac@100.122.169.71>\"}',0,0,4,'2026-07-08 18:52:17','2026-07-08 18:52:17','2026-07-08 18:52:17','[]','stream_socket_client(): Unable to connect to tcp://localhost:25 (Connection refused)'),
(3,'jin@patty.io',NULL,NULL,'Welcome to passbolt, Jin!','default','AN/user_register_self','default','','html','{\"body\":{\"user\":{\"id\":\"51fc08f4-a945-4a70-b5a1-ee0549b66189\",\"role_id\":\"4e7bbb1e-b5cf-450c-a489-c41de1e2908f\",\"username\":\"jin@patty.io\",\"active\":false,\"deleted\":false,\"disabled\":null,\"last_logged_in\":null,\"created\":\"2026-07-09T00:42:35+00:00\",\"modified\":\"2026-07-09T00:42:35+00:00\",\"role\":{\"id\":\"4e7bbb1e-b5cf-450c-a489-c41de1e2908f\",\"name\":\"user\",\"description\":\"Logged in user\",\"deleted\":null,\"created_by\":null,\"modified_by\":null,\"deleted_by\":null,\"created\":\"2012-07-04T13:39:25+00:00\",\"modified\":\"2012-07-04T13:39:25+00:00\"},\"profile\":{\"id\":\"0b5c17d7-bdc1-432d-b3db-2d054e868644\",\"user_id\":\"51fc08f4-a945-4a70-b5a1-ee0549b66189\",\"first_name\":\"Jin\",\"last_name\":\"Kim\",\"created\":\"2026-07-09T00:42:35+00:00\",\"modified\":\"2026-07-09T00:42:35+00:00\",\"avatar\":{\"url\":{\"medium\":\"https:\\/\\/pass.patty.io\\/img\\/avatar\\/user_medium.png\",\"small\":\"https:\\/\\/pass.patty.io\\/img\\/avatar\\/user.png\"}}},\"locale\":\"en-UK\"},\"token\":{\"user_id\":\"51fc08f4-a945-4a70-b5a1-ee0549b66189\",\"token\":\"890c9534-6637-44e5-a47f-c3c171be87a6\",\"active\":true,\"type\":\"register\",\"data\":null,\"created\":\"2026-07-09T00:42:35+00:00\",\"modified\":\"2026-07-09T00:42:35+00:00\",\"id\":\"9a95441b-9b7d-491e-8142-d23bd01aef35\"},\"fullBaseUrl\":\"https:\\/\\/pass.patty.io\"},\"title\":\"Welcome to passbolt, Jin!\",\"fullBaseUrl\":\"https:\\/\\/pass.patty.io\",\"locale\":\"en-UK\"}','{\"Auto-Submitted\":\"auto-generated\",\"Message-ID\":\"<15400abff7384404b512fb5e6fce8f12@pass.patty.io>\"}',0,0,4,'2026-07-09 00:42:35','2026-07-09 00:42:35','2026-07-09 00:42:35','[]','stream_socket_client(): Unable to connect to tcp://localhost:25 (Connection refused)'),
(4,'leo@patty.io',NULL,NULL,'Welcome to passbolt, Leo!','default','AN/user_register_self','default','','html','{\"body\":{\"user\":{\"id\":\"0741af5f-6ee4-49c0-ab95-a347f9ebe02a\",\"role_id\":\"4e7bbb1e-b5cf-450c-a489-c41de1e2908f\",\"username\":\"leo@patty.io\",\"active\":false,\"deleted\":false,\"disabled\":null,\"last_logged_in\":null,\"created\":\"2026-07-09T00:42:52+00:00\",\"modified\":\"2026-07-09T00:42:52+00:00\",\"role\":{\"id\":\"4e7bbb1e-b5cf-450c-a489-c41de1e2908f\",\"name\":\"user\",\"description\":\"Logged in user\",\"deleted\":null,\"created_by\":null,\"modified_by\":null,\"deleted_by\":null,\"created\":\"2012-07-04T13:39:25+00:00\",\"modified\":\"2012-07-04T13:39:25+00:00\"},\"profile\":{\"id\":\"fff2ab00-a86e-49e9-b719-4062caeca411\",\"user_id\":\"0741af5f-6ee4-49c0-ab95-a347f9ebe02a\",\"first_name\":\"Leo\",\"last_name\":\"Kwon\",\"created\":\"2026-07-09T00:42:52+00:00\",\"modified\":\"2026-07-09T00:42:52+00:00\",\"avatar\":{\"url\":{\"medium\":\"https:\\/\\/pass.patty.io\\/img\\/avatar\\/user_medium.png\",\"small\":\"https:\\/\\/pass.patty.io\\/img\\/avatar\\/user.png\"}}},\"locale\":\"en-UK\"},\"token\":{\"user_id\":\"0741af5f-6ee4-49c0-ab95-a347f9ebe02a\",\"token\":\"4d62d786-188e-4dd8-afa5-03d6a326153a\",\"active\":true,\"type\":\"register\",\"data\":null,\"created\":\"2026-07-09T00:42:52+00:00\",\"modified\":\"2026-07-09T00:42:52+00:00\",\"id\":\"9f3fe689-eea7-463b-a927-1e558bb64c5e\"},\"fullBaseUrl\":\"https:\\/\\/pass.patty.io\"},\"title\":\"Welcome to passbolt, Leo!\",\"fullBaseUrl\":\"https:\\/\\/pass.patty.io\",\"locale\":\"en-UK\"}','{\"Auto-Submitted\":\"auto-generated\",\"Message-ID\":\"<b83e7080f1f84a2f80a572c4abfe4307@pass.patty.io>\"}',0,0,4,'2026-07-09 00:42:52','2026-07-09 00:42:52','2026-07-09 00:42:52','[]','stream_socket_client(): Unable to connect to tcp://localhost:25 (Connection refused)'),
(5,'ilia@patty.io',NULL,NULL,'Welcome to passbolt, Ilia!','default','AN/user_register_self','default','','html','{\"body\":{\"user\":{\"id\":\"c4c6fdac-fd5d-4980-8601-dfd7fab06f16\",\"role_id\":\"4e7bbb1e-b5cf-450c-a489-c41de1e2908f\",\"username\":\"ilia@patty.io\",\"active\":false,\"deleted\":false,\"disabled\":null,\"last_logged_in\":null,\"created\":\"2026-07-09T00:42:52+00:00\",\"modified\":\"2026-07-09T00:42:52+00:00\",\"role\":{\"id\":\"4e7bbb1e-b5cf-450c-a489-c41de1e2908f\",\"name\":\"user\",\"description\":\"Logged in user\",\"deleted\":null,\"created_by\":null,\"modified_by\":null,\"deleted_by\":null,\"created\":\"2012-07-04T13:39:25+00:00\",\"modified\":\"2012-07-04T13:39:25+00:00\"},\"profile\":{\"id\":\"0cf32583-5015-4ea5-9821-0ba820f589ff\",\"user_id\":\"c4c6fdac-fd5d-4980-8601-dfd7fab06f16\",\"first_name\":\"Ilia\",\"last_name\":\"Kim\",\"created\":\"2026-07-09T00:42:52+00:00\",\"modified\":\"2026-07-09T00:42:52+00:00\",\"avatar\":{\"url\":{\"medium\":\"https:\\/\\/pass.patty.io\\/img\\/avatar\\/user_medium.png\",\"small\":\"https:\\/\\/pass.patty.io\\/img\\/avatar\\/user.png\"}}},\"locale\":\"en-UK\"},\"token\":{\"user_id\":\"c4c6fdac-fd5d-4980-8601-dfd7fab06f16\",\"token\":\"824dad76-9ee2-4522-978e-2073c3912da0\",\"active\":true,\"type\":\"register\",\"data\":null,\"created\":\"2026-07-09T00:42:52+00:00\",\"modified\":\"2026-07-09T00:42:52+00:00\",\"id\":\"bcbc03f0-4de0-46b1-845f-b14a0a6b1b83\"},\"fullBaseUrl\":\"https:\\/\\/pass.patty.io\"},\"title\":\"Welcome to passbolt, Ilia!\",\"fullBaseUrl\":\"https:\\/\\/pass.patty.io\",\"locale\":\"en-UK\"}','{\"Auto-Submitted\":\"auto-generated\",\"Message-ID\":\"<e2e1a4a182a94020bd94c10dad0087ea@pass.patty.io>\"}',0,0,4,'2026-07-09 00:42:52','2026-07-09 00:42:52','2026-07-09 00:42:52','[]','stream_socket_client(): Unable to connect to tcp://localhost:25 (Connection refused)'),
(6,'david@patty.io',NULL,NULL,'Welcome to passbolt, David!','default','AN/user_register_self','default','','html','{\"body\":{\"user\":{\"id\":\"bd3c4edd-805f-4c49-9c76-a53270539320\",\"role_id\":\"4e7bbb1e-b5cf-450c-a489-c41de1e2908f\",\"username\":\"david@patty.io\",\"active\":false,\"deleted\":false,\"disabled\":null,\"last_logged_in\":null,\"created\":\"2026-07-09T00:42:53+00:00\",\"modified\":\"2026-07-09T00:42:53+00:00\",\"role\":{\"id\":\"4e7bbb1e-b5cf-450c-a489-c41de1e2908f\",\"name\":\"user\",\"description\":\"Logged in user\",\"deleted\":null,\"created_by\":null,\"modified_by\":null,\"deleted_by\":null,\"created\":\"2012-07-04T13:39:25+00:00\",\"modified\":\"2012-07-04T13:39:25+00:00\"},\"profile\":{\"id\":\"7d7f5bb9-c807-4b41-a811-3d6b8c11fa1e\",\"user_id\":\"bd3c4edd-805f-4c49-9c76-a53270539320\",\"first_name\":\"David\",\"last_name\":\"Shin\",\"created\":\"2026-07-09T00:42:53+00:00\",\"modified\":\"2026-07-09T00:42:53+00:00\",\"avatar\":{\"url\":{\"medium\":\"https:\\/\\/pass.patty.io\\/img\\/avatar\\/user_medium.png\",\"small\":\"https:\\/\\/pass.patty.io\\/img\\/avatar\\/user.png\"}}},\"locale\":\"en-UK\"},\"token\":{\"user_id\":\"bd3c4edd-805f-4c49-9c76-a53270539320\",\"token\":\"87ee3f24-18c7-4fff-b0de-1128543b6b62\",\"active\":true,\"type\":\"register\",\"data\":null,\"created\":\"2026-07-09T00:42:53+00:00\",\"modified\":\"2026-07-09T00:42:53+00:00\",\"id\":\"36d447ce-aad0-43ef-9c90-434df74dfe8c\"},\"fullBaseUrl\":\"https:\\/\\/pass.patty.io\"},\"title\":\"Welcome to passbolt, David!\",\"fullBaseUrl\":\"https:\\/\\/pass.patty.io\",\"locale\":\"en-UK\"}','{\"Auto-Submitted\":\"auto-generated\",\"Message-ID\":\"<0a439c5744904db5aa3a630fba2d3ee9@pass.patty.io>\"}',0,0,4,'2026-07-09 00:42:53','2026-07-09 00:42:53','2026-07-09 00:42:53','[]','stream_socket_client(): Unable to connect to tcp://localhost:25 (Connection refused)'),
(7,'patrick@patty.io',NULL,NULL,'You edited the resource lkit_dotenv','default','LU/resource_update','default','','html','{\"body\":{\"user\":{\"id\":\"2c22e1ca-66dc-4107-b375-f2d0d13dab9b\",\"role_id\":\"e66c3a09-1dda-4143-8fd0-4824233698d9\",\"username\":\"patrick@patty.io\",\"active\":true,\"deleted\":false,\"disabled\":null,\"last_logged_in\":\"2026-07-21T01:42:09+00:00\",\"created\":\"2026-07-08T18:52:16+00:00\",\"modified\":\"2026-07-09T08:46:05+00:00\",\"role\":{\"id\":\"e66c3a09-1dda-4143-8fd0-4824233698d9\",\"name\":\"admin\",\"description\":\"Organization administrator\",\"deleted\":null,\"created_by\":null,\"modified_by\":null,\"deleted_by\":null,\"created\":\"2012-07-04T13:39:25+00:00\",\"modified\":\"2012-07-04T13:39:25+00:00\"},\"profile\":{\"id\":\"45b62c17-d953-4186-825d-30068887222d\",\"user_id\":\"2c22e1ca-66dc-4107-b375-f2d0d13dab9b\",\"first_name\":\"Patrick\",\"last_name\":\"Rho\",\"created\":\"2026-07-08T18:52:16+00:00\",\"modified\":\"2026-07-08T18:52:16+00:00\",\"avatar\":{\"url\":{\"medium\":\"https:\\/\\/pass.patty.io\\/img\\/avatar\\/user_medium.png\",\"small\":\"https:\\/\\/pass.patty.io\\/img\\/avatar\\/user.png\"}}},\"locale\":\"en-UK\"},\"recipient\":{\"id\":\"2c22e1ca-66dc-4107-b375-f2d0d13dab9b\",\"role_id\":\"e66c3a09-1dda-4143-8fd0-4824233698d9\",\"username\":\"patrick@patty.io\",\"active\":true,\"deleted\":false,\"disabled\":null,\"last_logged_in\":\"2026-07-21T01:42:09+00:00\",\"created\":\"2026-07-08T18:52:16+00:00\",\"modified\":\"2026-07-09T08:46:05+00:00\",\"locale\":\"en-UK\",\"groups_users\":[],\"profile\":{\"id\":\"45b62c17-d953-4186-825d-30068887222d\",\"user_id\":\"2c22e1ca-66dc-4107-b375-f2d0d13dab9b\",\"first_name\":\"Patrick\",\"last_name\":\"Rho\",\"created\":\"2026-07-08T18:52:16+00:00\",\"modified\":\"2026-07-08T18:52:16+00:00\",\"avatar\":{\"url\":{\"medium\":\"https:\\/\\/pass.patty.io\\/img\\/avatar\\/user_medium.png\",\"small\":\"https:\\/\\/pass.patty.io\\/img\\/avatar\\/user.png\"}}},\"gpgkey\":{\"id\":\"daf8fe0a-d901-43e9-860d-10dcc8aea0aa\",\"user_id\":\"2c22e1ca-66dc-4107-b375-f2d0d13dab9b\",\"armored_key\":\"-----BEGIN PGP PUBLIC KEY BLOCK-----\\n\\nxjMEak9fuBYJKwYBBAHaRw8BAQdAtxUCLC\\/\\/zhmHYBDOciQGpw6pfQkTlHkm\\nJUy3HP14qwfNHlBhdHJpY2sgUmhvIDxwYXRyaWNrQHBhdHR5LmlvPsLAEwQT\\nFgoAhQWCak9fuAMLCQcJkLtjY7\\/UA9mIRRQAAAAAABwAIHNhbHRAbm90YXRp\\nb25zLm9wZW5wZ3Bqcy5vcmcK7Kj2hAA9eaInncOY3gRpfg1pBOuT+o\\/ePd2e\\nV+I3CQUVCggODAQWAAIBAhkBApsDAh4BFiEErvt0LkIb0y7shGYAu2Njv9QD\\n2YgAAASdAP4h9hzkiLJvy+akbkMJC0IYnusr4IEmAGPg+AqNu\\/LwEgEA5oAh\\nu9432jmw0+CBe4jnaypthOnfCDEh0zApDkrGwQjOOARqT1+4EgorBgEEAZdV\\nAQUBAQdAVuhtKaohrZyb4FpX1c7vIqhDG5q\\/ZQk57bXQoxHrTgIDAQgHwr4E\\nGBYKAHAFgmpPX7gJkLtjY7\\/UA9mIRRQAAAAAABwAIHNhbHRAbm90YXRpb25z\\nLm9wZW5wZ3Bqcy5vcmepRmylsPRiZEkcRJKxEm23ai5EjjDmOPCCw0vvtTmh\\nCQKbDBYhBK77dC5CG9Mu7IRmALtjY7\\/UA9mIAAB5oQD+PlS4\\/ab0oudKi1iH\\nNlGaKnOXTjYVEzelw2md4CtIkOkBALxB1Ys12\\/Ki2RX\\/ueyUjEcc+WqUTB8X\\nPjCnZT1Xy1EC\\n=tjDF\\n-----END PGP PUBLIC KEY BLOCK-----\\n\",\"bits\":256,\"uid\":\"Patrick Rho <patrick@patty.io>\",\"key_id\":\"BB6363BFD403D988\",\"fingerprint\":\"AEFB742E421BD32EEC846600BB6363BFD403D988\",\"type\":\"EdDSA\",\"expires\":null,\"key_created\":\"2026-07-09T08:45:44+00:00\",\"deleted\":false,\"created\":\"2026-07-09T08:46:05+00:00\",\"modified\":\"2026-07-09T08:46:05+00:00\"},\"role\":{\"id\":\"e66c3a09-1dda-4143-8fd0-4824233698d9\",\"name\":\"admin\",\"description\":\"Organization administrator\",\"deleted\":null,\"created_by\":null,\"modified_by\":null,\"deleted_by\":null,\"created\":\"2012-07-04T13:39:25+00:00\",\"modified\":\"2012-07-04T13:39:25+00:00\"}},\"resource\":{\"id\":\"b3f7b360-be12-4011-af21-756bae51f93b\",\"name\":\"lkit_dotenv\",\"username\":\"\",\"uri\":\"\",\"description\":null,\"metadata\":null,\"metadata_key_id\":null,\"metadata_key_type\":null,\"deleted\":false,\"expired\":null,\"created\":\"2026-07-21T01:26:12+00:00\",\"modified\":\"2026-07-21T01:44:28+00:00\",\"created_by\":\"2c22e1ca-66dc-4107-b375-f2d0d13dab9b\",\"modified_by\":\"2c22e1ca-66dc-4107-b375-f2d0d13dab9b\",\"resource_type_id\":\"a28a04cd-6f53-518a-967c-9963bf9cec51\",\"secrets\":[{\"user_id\":\"2c22e1ca-66dc-4107-b375-f2d0d13dab9b\",\"data\":\"-----BEGIN PGP MESSAGE-----\\n\\nwV4Do6VaHHleMHkSAQdAC\\/mNqN2k8gEz9yMaiReSzjjQC8B6zCw5lB6IOXG9\\nFgEwsQbL7bd73tTM5EpvUaZS+YqlD0EN5bpbGMCJbmeCTYginNEJDtK6XvLt\\nC2yA4IMJ0tp4Ae6FCfWSSppBEyXOD3\\/pOoCws4tT2BR\\/kA8wGzxnIUOGy3mG\\nDKNf0qQgJCl1kW9RlVO4QId1wIjIhaeuphr+56pVzflM4mjSEdsLc7kqGLnu\\nMwnDdckqrzyqBg3ZFDqcz6dW7Xryou0KBt40jT94KHQbXe1tkuatrDaYFscF\\nRLjCm3NILOWIpy2x21HMxDF5msvvmmzmuICPV208+9+LYoxnW2xlmnuWmONp\\nOyLojReR8OHfGY+lhQe\\/lKlPw2GPcZrgrSB9qyTlXdCcKTb9KaSLjrKZ7eD1\\nzmMhQa\\/IAbFKHnhQ7EhM8S2cOPzayQ8cpwdUTePm62JkOwSSSpyZHLB+fNS9\\nPpEs1J3eYZSm+Ogj4wyeTnlzOG4Zzgc+2xl1uIPQR\\/XIgpEhs4TBXp36p9Hb\\nMHUu5fxp9TPtKdfM4NitbyPkYxysL9ogp63iARRIXtNu5Ks7ZAac\\/qjrVe0q\\n+kDadxCBwnhI2vXD2ZXQEh30zFlO8bS\\/Bt07RwJCEKQnLE6892eX5TSjk+pf\\njiHZFauesVwZbNylR0QjfcCiEkY0Qaoc0AfHG9meNoAxlV4PiqCaO+1t+\\/sd\\nq0XKtFiRwS5d7li+cZkG0tFTDfKgZzQPdxNEIyb1LdT07A9xZatUHtVsJ2VQ\\nlXVv8UwNFm61IYLHOOOjG2atAAREPxXJfgkp8W7deC8xjj\\/eFqMtcNgLgGqb\\n5Wkf2EWvOcdffKX7gtvNVeGRXSbCVeJvjxzmPIQE8O3m50Cnsu01u+g\\/aufw\\n8INEvYq\\/yLRoLHDuQ4LtwEDTN05KyFdDl7qLRLBfHIUtt3EzcEZF6Cao81+g\\njGpYJ+YKlirErvTHDnc6HX4C+yKOjXBcOQZL2FELYgNHeh6OqxJgrVz1R4sG\\ncOnDUxMeyynfrDTBOj4uulirRJo9REV9FRj9n4SdUSMeb6mK+faZBN3UkE6p\\nwdaOXPv0Vc7dMRTPSrhx46mEoV8TOCel6417q0dutO7B06zXBQ88jXr49cZM\\nN7DFOipUU1Ri7mo1WqSv+kCTyCHB1b5bQYRYOnBc2oSqoJPNx+u91t6ibO5q\\nJ6GGZR1pgYnPmVhZKNUdGC0LHIgUYckUeZSfQ\\/v4oqS4JkA9KmxEdH7CBPCD\\nroVYuhzIdZEQ1PRLXRnM4EA4mmNo0JyrdnavcnP\\/v8A77hA65kS2cmwiJcIk\\n\\/aSiRpOq0Hicp+yIFQDpnzK+R7STg6shIEzswSGTtvBsOy6LQ+N7jq0ttoWb\\nLA2EA8njzw4fVU9y8aIrX9BYgRYNHmnsTSLxFb4If5nuKU6qTeWVIplnKvaT\\nJ4Gxjfss\\/o\\/IqW8i7GH2EBsHVHZapk7uX2h5wzZNkqx1vHw2MTtbUxbEQjP4\\nb8dpRLITEza+Z0qZ21461T0EHitYOMrZ8S1Ak+KP+XYwFy0mosOvTBIt7sSh\\nPsL0SP88CeFmoWvWzOBW2GZmBk+wGqnDVjITte7njIOYFEboXsyMhetH81Bq\\nofN\\/yjO58WaX1KVXaZsGzt\\/vPuf3L1MhiMyYDkRYTPXuB+s2KfBzEntv6ZTQ\\nzsvo8wEVMRG+J+IfOueG0qCESJABUe+PaKLcnXdszc4N8CziNC3pnvVGqlYq\\nJ7+as+o\\/4ky\\/2EvUqDrgmDxg\\/5RXRZzS8g62SWV7E6XuJi0Gs6gDy9rYS6a+\\nJcamGm3g+M7cN02bcsUQcJOEhR\\/bwYU5jfkeWkKBmCg4vf7Sd6Yl41sKxwCj\\nNboKzu74rW7h3W2zXElXTbhfIpLtESeCD5V\\/W9tZeYgMFT10E8Wtgg7P742M\\ntq4797DYO58rkjFys5e7XF5vgOFzs6YxE8XujmSo631QF0w6lnWSBma62UmG\\nYYPecW8ZWkushtfNBqq3xOoPLb\\/dg2EuuRqRm3VLH3PFNLXeQU6vXnjQQdjl\\nHfBDFf\\/G1voN5Z+gsI7sZnombvdfTSImj6QWbLVyaTTrGHo2hv5NZCaTTlJU\\npqsxthraxfTHz6Yovq0uYB8bQJwvqrWOeU0gaLfnBw692igCtjMd+YsdoCVe\\nRLvW5cM3ldmhOQr8R28gQr1zQOy8DPswtOpkr\\/K01gbk5mB5HB+FCtGi9tA4\\nTPbTvvJyHGCj7AowOLGTg2YTshLzenvWb22MudT262C1prRyqfckQoaKLg1Q\\nqXEz5RsMlFU3TdiMQRwuzUF5ux7HhuQCOKiIazkMhbGP6td6WZRUpFcOju8s\\nSYH3B5OJrCDyCx5+6kXzBvYhC9aZ9URE1uoeK7tIqI2MDw7U8APWo22gQEAD\\njIN2sBWAX7LYt5fyDvppS+nnTUjVOTL5c5Snkbkki3Z+BUyNap\\/Hw39bsu\\/I\\nbqcrFaFpD6zcQL+oGllb+KY0IipdxWLe\\/wHRNr96vcZ7Jmh\\/7QoAHR7SiznT\\n9DuDu+VdYIl4micQ2lbBGZLA0\\/YBy\\/5CVLyWC1i10R6jA03+kVtjIcR4ickU\\nOlrk5+VunzCOEUKd67L6TVdc8fLuM7UNxMd5z9mMOdy+i1AWis1z1H05mD++\\n4qalDTfnsfTHpcvnEQGUhLarEJc2UEq43WN+oxhw76MF02Q2u8DV4q5PoRtD\\nckW4VMvTQEQ4ghKpvJRMouyq7a4vlrMUj8v1iy4X2SzW6FUM1T4Q1tp0NGvv\\naHK3FiNWtvitmteR0wp5rzYbcxA0kGh+o+xBoP7DbFCR7Iod6WfVdEhia2uZ\\n6L\\/vVXEsVdMj9tXH88omVkMdhjPirKa3NvMCdZ5bDYyozNSwn\\/20AE4KDg1x\\ntY0aEEj3hnDyFZ8v29bxMGcpSL3rvMsTgczOSBhrN2IhbzXkpB+RrWm9bdnH\\n7AvCZdR9xMoN3yQAbShILtclMBZrcXj4OCyZRr4ehRBjS8+v1kcbiicPwOFu\\nMJvaOV3PTsq7X78yCtqOaIPIgI5UuYXxnglenp7yzTivboYbDcs3jE0OUgLd\\nzUEFU7eGRDOJB9JeZYoXY77\\/E2qH8TVPFGCXjtxGmM3Rdjqb8Z1njVHDOyx+\\nOi13i1PKoPOv5NLnJ2pYEOgELi1vWXbUK6PrYwjeephOJo2wiVv0\\/ehq47Ss\\nH8mjODikuy6+7dJGMhlVyUSjdJF5dlWegYiCwPCC3T\\/nmCNTtGOILOnCsADZ\\nu\\/lZu9AR0uRSwZYJtYQdIZH2IC0AuOvU7MyogRvk+1umdHR7oY4beKHc+4V\\/\\nPFx3TOZFe50b0hkfILgIP1qh\\/a5gm7kCX5XvLP269wOTJkYiOMrXurn1afiC\\nYHQUjMxEJTP\\/bQIg0tJ8Ovid0W4f31CpQU18iO81YA2eK6ZebqsIxkpQPRsD\\n2t3uewVUIEbuh6y7EBifTzxuoldhguDSeu9kV5wjAzrLjJrdYapACXUrKp5V\\npzpjJoGPp362PTOG\\/+YXFmlNG9xZcbjJKLVTin3iLu4HvAIzLZ9VzdXe+Uov\\na98nvOqW9A7746LIx+axJe4qrQw8HTRgaze+RNRVNCCSL7LyehIymcnPoPZY\\nVq26Qb8DOTkQS1LtkHB0ZpZm9I8AtOQsdkfjJnCS1pKMGKzfL1SrPtFtzzF7\\nTcWc3e2yPiX1cdry52yQs+W32Gql7nCEx5kN26NJmnXlSWWNYPyQdGxFBPBs\\nqOcgPU\\/lsFk4cFaOv1\\/nD4URXaZZOstJBnYzUsrDqLPF16holPglEYuu2uMW\\noljSUfS\\/8tGJIPDTALelc9RcAFrALPgyJg9SyI+itmjRCtUAsY6Moz0fabfB\\nomPkfFNDHUpwfRgf\\/I\\/b9\\/yFygbvm+H6t1rPvIWe4r\\/h+svGmFZYUUPsIniC\\nQsZrrrqDhcipURgRaOWUNp2Tcf+fgmWRlKIcGt1s3\\/B4dD40RlQeXAxoFoHj\\nUJrl\\/U1I2fGEAFX6yEzQaHg3oVCOkxY8eZtKsacEWyfpoz7rkw8Qyu0WP\\/nm\\n5KwtyfYaU+iBqQcKeUE7lG+Ne\\/4NuzbAadd4tmJ1mcYhkZa1She4JnRUIb0P\\nSHKgAJj1ZiSkM7vFBZQFXkwY6eCLKBNAuKrUlCcRX46ZcR8u8m4KmiRs8ITF\\nfKyZcwVFf4emyOjzaTrNCEkUxoUaGEuvDaLi8bAa3Ps+6P+YytpeLsDvWaRz\\n2uArRWJXFt2VM3vnrEx9htd2bVRBloIYV\\/R7ge7UqgFgddT380W\\/Oc\\/R6op8\\nSfrmlooQ1TyCcBi8V3mS4RMwma6Zs59yurgQvmBunBkMb0UVOuipObx4uFRY\\nC8UWONrm\\/a6rfA87PrpbFpT2NGHvi8FlnB2NUfag7o2F1zbyh4YblnL4rWvx\\ncxOUi5krYNSn9tjc4tdr0R4AVKEc+h9pJtZjusPwbtHgODxJb91DRHIuh4Dt\\n0V22f2u7RgMSLEPutdALD\\/ZaTooZO2QKNACEAz+rghJvdaRaG3xol0kgUuKN\\ntHfW\\/5oxNr6Jin2St0tQYsgP8ppupzEURdarzMo25RFwQ17B+hhG3leKCIdd\\n8rukio9MhXb9KXptESeJwq9am1JvgHeSUpBTwDgCJdv4arlMruN8S1GdGxv6\\nMQxMgC3J6rTDX\\/WzokDV4\\/KZPq64x8gPkb7iMQ4BkY3e6RrgJCSPr+MZmsQm\\nMXFfoy5yV5eq0UulgNy6I8GsGuTvWV71YOXffu8Sj3gDLAYkgYq+cE8XSAzT\\nm1K7crZTglgjyNICyhz4vkGdbcJJu7fGu08jwdr5k9eD0fmNNUIRso11E\\/Kx\\nIOo9vXIyzYo1ni8JRwDxyUiKfUleYRSlQhb47CKpMhXN66Hja7ue3R8EwyB9\\nAAMLFdFUmaBMYJ72JWk18cLJ+s2c1jaCDMhl5+BGfMHar07XCE440hS8\\/4\\/W\\nzSsSA4fIvD8S43rejFd4gVxjgNL9pkE07k1QByF28UJhYKg11ZCXQB4vmybd\\nr9Z6vYEbbkzo4fC0IC\\/CMxsKGTPmYeLD4LSdiBLO6s64iIbDIRqQbHTGpwuv\\nNzvBgka4k4PJqoE0RK44Kff0ghGMWMlBO6qFZ1zQZVp0nHsgj8Kfs2xnWPFa\\nOxGUXGFNtscLAL5ISj0n8w405zIf5vNm7jwhD0unz1kSOz8RVX3Ory9eoPE2\\nAplea5FQgh4D94r1ZNhY4TqlBH4TAl0ICaWqi8FSLRg9l2ncoiiKGul+bl1E\\nZSSq2iRnkg0KM5SmmADSZjbaTznyYmgtCBcYD4gI70tRqyznuPN9zD6+NyQm\\nZ+n8Aaz7rx2H3RY8ZGZJSsbn3qGLGFgfoqdEe1Cu3gERGKfDWJxWsHV2F1n8\\nkpaOEfo+vy9om0YtKQyobu5dlkfXlFE8mRW+2aH+ExRL5d12iPIV3Q8cvoy5\\nOfA0NC6DVSPoFMzMlH7dSXPff01fktlwWNQsk3YC10WT0Ivn1vhBMdz9PUwp\\nJuNJD9M6koeSOv6xVxvtYml12tf+bfHCO3WKaYtn72aCnLVy32zO6xIEySch\\n3Emag80AuPhvPS985cORALDcnH5jzWwejn35cTAor9WrxH9nGK8x0o5vjomV\\nLf\\/xjZpM4tJ0vlfIs5cHC0p19wwV8KMy9Ws0qX2AsPUNGsgy0qs8ZJLQIerQ\\nmIOTihHohHGhIrWD4PmsuKkzlzJVkA+ra1cf8Gdcglg6wDNK4mcRRTCO56DP\\nNAPfRCUYs808TCkqCEkjVhsMj4zGXvnsvtlegDUO+j6izGSt8kAn4\\/OK8PrM\\ngK8+imB9nZZHAmUcLxrCI4jh+0kOSxqfFrSpmc0rYcQQ\\/pViLKUCV47xi2k4\\nton5nBeDtxYmveG1q2l7lR6Oz0oifMMltH8I7v65I9JKj7CakVGat3pDP20c\\nRZiCVikX6mma1vX9mMV\\/CYW1ioSVN91Kz\\/KGQ0X78+bnAN8MOGayuIcwPmal\\nuqktpLpvl2lau8qngTYzIAgYtDvYJrneRFabeCpZ86ZyRZVx+DdLIShIgLX2\\nY\\/hQPivgek0T88Yw8Ak\\/UjEBKCI2eKJeB1mcc3GPBm1xuoEYiAP9famDJkv+\\nD3HRSzsQmYDCHE9PQtHCQmu7zvBfwfDtKMJdhLckUYAbvl9+zHGQ3poS8BMG\\ndTxpgCr3JnD9d7imlLvZ\\/5Q1XpoF7KdiZkGNsO92zItmLlGD430UaHZpq87o\\nOhWOx+Wob5auOF77vFr3fHJZ2iP9PmpNoeXwuIzpNAXaLHffpbzqRmEik1il\\nh3YoNM1WSzkThEPo3W1pRAfpSmcj85wWI0LMIK3ZuyX2aBn\\/gf2wJh1C3LNA\\nL0bmqJIh6UmmNx1KDqRq0h0gby2cL0RiKbOXiLaT\\/pLROhpSwyu80wpWLzgX\\nAe7n8RauryWlVz4hnH363FRTByhHynRtUcydTROiIIC+e\\/A6oamPvA4yRW6m\\n+5M8a6nW8HZJrEGDfDEpq4Ifipl1Eu4a1KhvSqwOPm8eOVO5uDotvm92eZZa\\ni31e6og8KbDurvLh6AXvEwdXOOm47DDnu1EGTAmSKaDvcTPeVF6RuW\\/FZRDl\\nGX2h5\\/NEqcJI4pvulsHGdP2OE4OkDYvirhUCp6z4YWcqJerhggq4aps4flhq\\nufmcliW8ladQhcOv8ZXxwXdNfvdSqHXDZCx84LQ2RGGzqEZozDicfuudZVSd\\nsVYsafEpCykWiEn3gDjqLuaDAqAeze+g1chxhwqU0nLJuE2YmOWU9FtZYWrN\\nIq9RwwwiPFoWguFazJYeuX8Ht1oDfrT48wtjzpZ6iqxPVCQp0+47l7y+vS1I\\n1Xnaa\\/5ZhDwOoDAKB1b1OI8ZtbRyCXdM9Rujn2VDVmo2SYoPT8ELbN78+RH0\\nQ1O1rsdZ7mpha83+7327oFQLUY5PrMkAhxDwRfjBtIq1AsaG82vBEcwKd9en\\nyKplzE23pXPhcuEGeHgoLElMzp5l6WmdKjDA47bxqYxyvIBMelfvC\\/qZdypo\\nQswg6Rmp6vVIiRke9wUinXzDJSCJa1TcyaXOyodLzVxRQlJ74CYXrk+fwJpp\\niRGg4Zfrr6Cjq6RbPTEu\\/lPBYvLyzwHqv9qkbuaZ+53xyK\\/xCB3AGxrK3RxA\\nUkHvIuWizTbawDxxJOAAl\\/vd+d61e9PMIG\\/puEwKnfBFm3gyAYfFKnlk8Dnd\\nfuFuAeq8ydXRt4AGjVWpccqqJONu9RctA7ihK+M+iTB8AZU74cDiuQcuf2xh\\noKihiwchYUpRkDb8UbidBKq1E4FYo2tRCMKzWvAJojb3vW1owDK9mmnHJxUD\\nnNbwwochSjVx87RrUqhWeG85Xlpfj1W9Me0N2GfF+P+sLhzw7AkHyIsHa97p\\niDCnzS\\/zC7D4d2EfWswWZh\\/Dw++GLe0tX5ZOc+sgqGP\\/JUYaxa48hIqE\\/ZlH\\nPOtmSj8Gm4wsskOzoJUntGXLvs9rhDWcjzBouVRuGv7R\\/YzZCQvEkSQZNI6e\\nwRQzp1j6HgzsM1ahZ\\/JXvwtveScrltHq+E5lNFxxSs5uE4IuNfhbytLh3iR2\\nQc1pYiPoNS3lVhbjJCvqPpR8yeSPkryYE8X\\/0v5Ut5xr2fsDucsu5yfmZyPF\\nVsZmHoOy30wUTY8ndkPn0SWIDZUQpreNkJUhADley3ltCG53qmaxZLyh7eDz\\nRDKUWGE+cRls4qyAPxqSNVkclvrNW9OQi89B1EdHkFV7TIIAI5kYJgydWs5t\\n4wU4913A4mf0J54CF067RWQSYcqVhhtoKEG9FEn0jyhY5Rt0SrdaqxeQS6Ea\\nI7ZvWVX6fZXg7X1rFWn442jYK41HxKY8jGqRlPpWZ+jKmSE48yd\\/wOt7T\\/Te\\n57lfaGlE5TozUhq1XTJTkCiwrbr\\/IUnWbxTT915B9Y0p5YYIjMuJJDnwK1Ht\\neXir2Havh+9gOnszZZvAQSxL76FkCl5uZo0Wv5vbwUUu2App9tU4UE0vf1+h\\n46sDo1o9aBf7ZgyVwRLU4jn6\\/m2Fgo+JLw8G9wrpGpaOwX2geLkkSecbzM1G\\nt1rXJbtJex79mGuXYYby+BKBSo5jWzKy1fe0+G5AjO7KIo\\/UGhCnNk09YIe5\\ntsPHEuCKy3pq7x2OFlfy0j2PWLDiFF6V4mozDt8wwckBelAz1QBDF+fWYr\\/y\\nddS0slwDvXrWUA9DdncfhTKpaoZ31wIQczSrKAH5jazQqNPQ3OcNe20ak6hX\\nzGV5\\/Wz4KVdMjC0QijxKaq5qQIZw4RXdz79p\\/cihWbuYASqQhLAb3CBrpbgg\\nnaGad88sFNRhPapg7t9uM\\/M6pA41MD\\/gIDrJQ\\/Usbm8A\\/LQYghECcG0Fa3+e\\nNUHu83T7z+YFofYQ0eNX8mPFl7Akc6KcGh\\/1WGlZsGzl8OAu\\/QQJ7TLNkrsu\\n4fXJVW98TEf3dk462PgOlxYHkPrFszbJl4G6aen5u5qwPTMMcZmnD2AYU583\\nmkBPL2GBTZvXVCRbSGScC0H\\/IYqj7Jj3jwVpf8GAEq3ro+VgtmPlW1eeT6Gd\\nrvB0SgevtoLTsNR7sh9BbM2tUWtH\\/7j5nX6Tyqd5DeSmMrB1HJSAZzIQNUVS\\nSVFCqGHPusm2MCVNG+wibvXxUBScQlORugUcH5nMaZ6y8+QRoSffeI0SttWe\\nDV9GS8QjhHSIJpKh1D\\/VEnWtyt7wjd\\/M3zIWCVQqsYa28QdBcG\\/SNLJQYvxP\\nTb0G0WcgCCLaRa1CTa7BHk8FcApL1xSazVHf9fXthb0RsdmTeQ+bxyhknkNP\\new7L7ooUPPBXhSQGcYskZTtyzGhsvE4Yz\\/7ztZ3EMvYMfRgcTCxGj0ooADZ+\\n10AnPdsAzSZFDSa9ausP6Aj59+HCXrlIFFcNngZ1LGfU2UBBHaksuQgG1nXc\\n6U4BUSNiP5BEkcO5CDioa5YqZK4bkZP3HKc1z0ni6u31rQc00QJNz+kRtxBA\\nIUCGZQs+1yhxkBfaFSXlxoWTnJ5LlvyPLmxKk00NDGFvWFtSSmuBTS2N82GG\\nkZMDNeeyECb8bcJXN\\/HYBSzZE2EvvMCizZrc9ADWVrDmYgxOSEpfwqBlqj46\\nMMZKcXx6fiEHCxbPBMIxnJf5YhvV2quIDpoBEDNtU8fmrUpc1vva6T8txz6q\\nD6++dMo9uw8VKUbiEq+yNTcI\\/hw2McnntxgEYVv+bHK8L6xas6Xa1Eslet6k\\nkLa7SAuzjKQct3jKmuQvVDbepcDHie41RuzV7QwuhRdhkQibxFqP0QRy3LdR\\nX9IPGEFKPtGOwoMORaNr3o6EAP7d\\/mw5uAMnuJSknaxoWjHIrIqYWbRajQLq\\nF+IaTlNsaqK9goCUwTe0Lay+wvwrac\\/HrIQXL8A\\/LPlgbJnzoMpx72BxDRhR\\nELOfcxB7ULJ8NsRRNbyZ5GmOJpxuSVZJxgaL3TKzgSb3ijg4rx+JkTiI+oe7\\nPT881lrWh72Dco\\/xmHmHEnthjgBcZTMceP8rfl7dziWd2DbU9RoCGbvLQG2m\\nWjc=\\n=vOi1\\n-----END PGP MESSAGE-----\\n\",\"modified_by\":\"2c22e1ca-66dc-4107-b375-f2d0d13dab9b\",\"created_by\":\"2c22e1ca-66dc-4107-b375-f2d0d13dab9b\",\"secret_revision_id\":\"50352ea7-259a-47b1-ba8e-9852bffe81ab\",\"resource_id\":\"b3f7b360-be12-4011-af21-756bae51f93b\",\"created\":\"2026-07-21T01:44:28+00:00\",\"modified\":\"2026-07-21T01:44:28+00:00\",\"id\":\"e18ad78c-782d-458c-b965-14b270e6ea2b\"}]},\"armoredSecret\":\"-----BEGIN PGP MESSAGE-----\\n\\nwV4Do6VaHHleMHkSAQdAC\\/mNqN2k8gEz9yMaiReSzjjQC8B6zCw5lB6IOXG9\\nFgEwsQbL7bd73tTM5EpvUaZS+YqlD0EN5bpbGMCJbmeCTYginNEJDtK6XvLt\\nC2yA4IMJ0tp4Ae6FCfWSSppBEyXOD3\\/pOoCws4tT2BR\\/kA8wGzxnIUOGy3mG\\nDKNf0qQgJCl1kW9RlVO4QId1wIjIhaeuphr+56pVzflM4mjSEdsLc7kqGLnu\\nMwnDdckqrzyqBg3ZFDqcz6dW7Xryou0KBt40jT94KHQbXe1tkuatrDaYFscF\\nRLjCm3NILOWIpy2x21HMxDF5msvvmmzmuICPV208+9+LYoxnW2xlmnuWmONp\\nOyLojReR8OHfGY+lhQe\\/lKlPw2GPcZrgrSB9qyTlXdCcKTb9KaSLjrKZ7eD1\\nzmMhQa\\/IAbFKHnhQ7EhM8S2cOPzayQ8cpwdUTePm62JkOwSSSpyZHLB+fNS9\\nPpEs1J3eYZSm+Ogj4wyeTnlzOG4Zzgc+2xl1uIPQR\\/XIgpEhs4TBXp36p9Hb\\nMHUu5fxp9TPtKdfM4NitbyPkYxysL9ogp63iARRIXtNu5Ks7ZAac\\/qjrVe0q\\n+kDadxCBwnhI2vXD2ZXQEh30zFlO8bS\\/Bt07RwJCEKQnLE6892eX5TSjk+pf\\njiHZFauesVwZbNylR0QjfcCiEkY0Qaoc0AfHG9meNoAxlV4PiqCaO+1t+\\/sd\\nq0XKtFiRwS5d7li+cZkG0tFTDfKgZzQPdxNEIyb1LdT07A9xZatUHtVsJ2VQ\\nlXVv8UwNFm61IYLHOOOjG2atAAREPxXJfgkp8W7deC8xjj\\/eFqMtcNgLgGqb\\n5Wkf2EWvOcdffKX7gtvNVeGRXSbCVeJvjxzmPIQE8O3m50Cnsu01u+g\\/aufw\\n8INEvYq\\/yLRoLHDuQ4LtwEDTN05KyFdDl7qLRLBfHIUtt3EzcEZF6Cao81+g\\njGpYJ+YKlirErvTHDnc6HX4C+yKOjXBcOQZL2FELYgNHeh6OqxJgrVz1R4sG\\ncOnDUxMeyynfrDTBOj4uulirRJo9REV9FRj9n4SdUSMeb6mK+faZBN3UkE6p\\nwdaOXPv0Vc7dMRTPSrhx46mEoV8TOCel6417q0dutO7B06zXBQ88jXr49cZM\\nN7DFOipUU1Ri7mo1WqSv+kCTyCHB1b5bQYRYOnBc2oSqoJPNx+u91t6ibO5q\\nJ6GGZR1pgYnPmVhZKNUdGC0LHIgUYckUeZSfQ\\/v4oqS4JkA9KmxEdH7CBPCD\\nroVYuhzIdZEQ1PRLXRnM4EA4mmNo0JyrdnavcnP\\/v8A77hA65kS2cmwiJcIk\\n\\/aSiRpOq0Hicp+yIFQDpnzK+R7STg6shIEzswSGTtvBsOy6LQ+N7jq0ttoWb\\nLA2EA8njzw4fVU9y8aIrX9BYgRYNHmnsTSLxFb4If5nuKU6qTeWVIplnKvaT\\nJ4Gxjfss\\/o\\/IqW8i7GH2EBsHVHZapk7uX2h5wzZNkqx1vHw2MTtbUxbEQjP4\\nb8dpRLITEza+Z0qZ21461T0EHitYOMrZ8S1Ak+KP+XYwFy0mosOvTBIt7sSh\\nPsL0SP88CeFmoWvWzOBW2GZmBk+wGqnDVjITte7njIOYFEboXsyMhetH81Bq\\nofN\\/yjO58WaX1KVXaZsGzt\\/vPuf3L1MhiMyYDkRYTPXuB+s2KfBzEntv6ZTQ\\nzsvo8wEVMRG+J+IfOueG0qCESJABUe+PaKLcnXdszc4N8CziNC3pnvVGqlYq\\nJ7+as+o\\/4ky\\/2EvUqDrgmDxg\\/5RXRZzS8g62SWV7E6XuJi0Gs6gDy9rYS6a+\\nJcamGm3g+M7cN02bcsUQcJOEhR\\/bwYU5jfkeWkKBmCg4vf7Sd6Yl41sKxwCj\\nNboKzu74rW7h3W2zXElXTbhfIpLtESeCD5V\\/W9tZeYgMFT10E8Wtgg7P742M\\ntq4797DYO58rkjFys5e7XF5vgOFzs6YxE8XujmSo631QF0w6lnWSBma62UmG\\nYYPecW8ZWkushtfNBqq3xOoPLb\\/dg2EuuRqRm3VLH3PFNLXeQU6vXnjQQdjl\\nHfBDFf\\/G1voN5Z+gsI7sZnombvdfTSImj6QWbLVyaTTrGHo2hv5NZCaTTlJU\\npqsxthraxfTHz6Yovq0uYB8bQJwvqrWOeU0gaLfnBw692igCtjMd+YsdoCVe\\nRLvW5cM3ldmhOQr8R28gQr1zQOy8DPswtOpkr\\/K01gbk5mB5HB+FCtGi9tA4\\nTPbTvvJyHGCj7AowOLGTg2YTshLzenvWb22MudT262C1prRyqfckQoaKLg1Q\\nqXEz5RsMlFU3TdiMQRwuzUF5ux7HhuQCOKiIazkMhbGP6td6WZRUpFcOju8s\\nSYH3B5OJrCDyCx5+6kXzBvYhC9aZ9URE1uoeK7tIqI2MDw7U8APWo22gQEAD\\njIN2sBWAX7LYt5fyDvppS+nnTUjVOTL5c5Snkbkki3Z+BUyNap\\/Hw39bsu\\/I\\nbqcrFaFpD6zcQL+oGllb+KY0IipdxWLe\\/wHRNr96vcZ7Jmh\\/7QoAHR7SiznT\\n9DuDu+VdYIl4micQ2lbBGZLA0\\/YBy\\/5CVLyWC1i10R6jA03+kVtjIcR4ickU\\nOlrk5+VunzCOEUKd67L6TVdc8fLuM7UNxMd5z9mMOdy+i1AWis1z1H05mD++\\n4qalDTfnsfTHpcvnEQGUhLarEJc2UEq43WN+oxhw76MF02Q2u8DV4q5PoRtD\\nckW4VMvTQEQ4ghKpvJRMouyq7a4vlrMUj8v1iy4X2SzW6FUM1T4Q1tp0NGvv\\naHK3FiNWtvitmteR0wp5rzYbcxA0kGh+o+xBoP7DbFCR7Iod6WfVdEhia2uZ\\n6L\\/vVXEsVdMj9tXH88omVkMdhjPirKa3NvMCdZ5bDYyozNSwn\\/20AE4KDg1x\\ntY0aEEj3hnDyFZ8v29bxMGcpSL3rvMsTgczOSBhrN2IhbzXkpB+RrWm9bdnH\\n7AvCZdR9xMoN3yQAbShILtclMBZrcXj4OCyZRr4ehRBjS8+v1kcbiicPwOFu\\nMJvaOV3PTsq7X78yCtqOaIPIgI5UuYXxnglenp7yzTivboYbDcs3jE0OUgLd\\nzUEFU7eGRDOJB9JeZYoXY77\\/E2qH8TVPFGCXjtxGmM3Rdjqb8Z1njVHDOyx+\\nOi13i1PKoPOv5NLnJ2pYEOgELi1vWXbUK6PrYwjeephOJo2wiVv0\\/ehq47Ss\\nH8mjODikuy6+7dJGMhlVyUSjdJF5dlWegYiCwPCC3T\\/nmCNTtGOILOnCsADZ\\nu\\/lZu9AR0uRSwZYJtYQdIZH2IC0AuOvU7MyogRvk+1umdHR7oY4beKHc+4V\\/\\nPFx3TOZFe50b0hkfILgIP1qh\\/a5gm7kCX5XvLP269wOTJkYiOMrXurn1afiC\\nYHQUjMxEJTP\\/bQIg0tJ8Ovid0W4f31CpQU18iO81YA2eK6ZebqsIxkpQPRsD\\n2t3uewVUIEbuh6y7EBifTzxuoldhguDSeu9kV5wjAzrLjJrdYapACXUrKp5V\\npzpjJoGPp362PTOG\\/+YXFmlNG9xZcbjJKLVTin3iLu4HvAIzLZ9VzdXe+Uov\\na98nvOqW9A7746LIx+axJe4qrQw8HTRgaze+RNRVNCCSL7LyehIymcnPoPZY\\nVq26Qb8DOTkQS1LtkHB0ZpZm9I8AtOQsdkfjJnCS1pKMGKzfL1SrPtFtzzF7\\nTcWc3e2yPiX1cdry52yQs+W32Gql7nCEx5kN26NJmnXlSWWNYPyQdGxFBPBs\\nqOcgPU\\/lsFk4cFaOv1\\/nD4URXaZZOstJBnYzUsrDqLPF16holPglEYuu2uMW\\noljSUfS\\/8tGJIPDTALelc9RcAFrALPgyJg9SyI+itmjRCtUAsY6Moz0fabfB\\nomPkfFNDHUpwfRgf\\/I\\/b9\\/yFygbvm+H6t1rPvIWe4r\\/h+svGmFZYUUPsIniC\\nQsZrrrqDhcipURgRaOWUNp2Tcf+fgmWRlKIcGt1s3\\/B4dD40RlQeXAxoFoHj\\nUJrl\\/U1I2fGEAFX6yEzQaHg3oVCOkxY8eZtKsacEWyfpoz7rkw8Qyu0WP\\/nm\\n5KwtyfYaU+iBqQcKeUE7lG+Ne\\/4NuzbAadd4tmJ1mcYhkZa1She4JnRUIb0P\\nSHKgAJj1ZiSkM7vFBZQFXkwY6eCLKBNAuKrUlCcRX46ZcR8u8m4KmiRs8ITF\\nfKyZcwVFf4emyOjzaTrNCEkUxoUaGEuvDaLi8bAa3Ps+6P+YytpeLsDvWaRz\\n2uArRWJXFt2VM3vnrEx9htd2bVRBloIYV\\/R7ge7UqgFgddT380W\\/Oc\\/R6op8\\nSfrmlooQ1TyCcBi8V3mS4RMwma6Zs59yurgQvmBunBkMb0UVOuipObx4uFRY\\nC8UWONrm\\/a6rfA87PrpbFpT2NGHvi8FlnB2NUfag7o2F1zbyh4YblnL4rWvx\\ncxOUi5krYNSn9tjc4tdr0R4AVKEc+h9pJtZjusPwbtHgODxJb91DRHIuh4Dt\\n0V22f2u7RgMSLEPutdALD\\/ZaTooZO2QKNACEAz+rghJvdaRaG3xol0kgUuKN\\ntHfW\\/5oxNr6Jin2St0tQYsgP8ppupzEURdarzMo25RFwQ17B+hhG3leKCIdd\\n8rukio9MhXb9KXptESeJwq9am1JvgHeSUpBTwDgCJdv4arlMruN8S1GdGxv6\\nMQxMgC3J6rTDX\\/WzokDV4\\/KZPq64x8gPkb7iMQ4BkY3e6RrgJCSPr+MZmsQm\\nMXFfoy5yV5eq0UulgNy6I8GsGuTvWV71YOXffu8Sj3gDLAYkgYq+cE8XSAzT\\nm1K7crZTglgjyNICyhz4vkGdbcJJu7fGu08jwdr5k9eD0fmNNUIRso11E\\/Kx\\nIOo9vXIyzYo1ni8JRwDxyUiKfUleYRSlQhb47CKpMhXN66Hja7ue3R8EwyB9\\nAAMLFdFUmaBMYJ72JWk18cLJ+s2c1jaCDMhl5+BGfMHar07XCE440hS8\\/4\\/W\\nzSsSA4fIvD8S43rejFd4gVxjgNL9pkE07k1QByF28UJhYKg11ZCXQB4vmybd\\nr9Z6vYEbbkzo4fC0IC\\/CMxsKGTPmYeLD4LSdiBLO6s64iIbDIRqQbHTGpwuv\\nNzvBgka4k4PJqoE0RK44Kff0ghGMWMlBO6qFZ1zQZVp0nHsgj8Kfs2xnWPFa\\nOxGUXGFNtscLAL5ISj0n8w405zIf5vNm7jwhD0unz1kSOz8RVX3Ory9eoPE2\\nAplea5FQgh4D94r1ZNhY4TqlBH4TAl0ICaWqi8FSLRg9l2ncoiiKGul+bl1E\\nZSSq2iRnkg0KM5SmmADSZjbaTznyYmgtCBcYD4gI70tRqyznuPN9zD6+NyQm\\nZ+n8Aaz7rx2H3RY8ZGZJSsbn3qGLGFgfoqdEe1Cu3gERGKfDWJxWsHV2F1n8\\nkpaOEfo+vy9om0YtKQyobu5dlkfXlFE8mRW+2aH+ExRL5d12iPIV3Q8cvoy5\\nOfA0NC6DVSPoFMzMlH7dSXPff01fktlwWNQsk3YC10WT0Ivn1vhBMdz9PUwp\\nJuNJD9M6koeSOv6xVxvtYml12tf+bfHCO3WKaYtn72aCnLVy32zO6xIEySch\\n3Emag80AuPhvPS985cORALDcnH5jzWwejn35cTAor9WrxH9nGK8x0o5vjomV\\nLf\\/xjZpM4tJ0vlfIs5cHC0p19wwV8KMy9Ws0qX2AsPUNGsgy0qs8ZJLQIerQ\\nmIOTihHohHGhIrWD4PmsuKkzlzJVkA+ra1cf8Gdcglg6wDNK4mcRRTCO56DP\\nNAPfRCUYs808TCkqCEkjVhsMj4zGXvnsvtlegDUO+j6izGSt8kAn4\\/OK8PrM\\ngK8+imB9nZZHAmUcLxrCI4jh+0kOSxqfFrSpmc0rYcQQ\\/pViLKUCV47xi2k4\\nton5nBeDtxYmveG1q2l7lR6Oz0oifMMltH8I7v65I9JKj7CakVGat3pDP20c\\nRZiCVikX6mma1vX9mMV\\/CYW1ioSVN91Kz\\/KGQ0X78+bnAN8MOGayuIcwPmal\\nuqktpLpvl2lau8qngTYzIAgYtDvYJrneRFabeCpZ86ZyRZVx+DdLIShIgLX2\\nY\\/hQPivgek0T88Yw8Ak\\/UjEBKCI2eKJeB1mcc3GPBm1xuoEYiAP9famDJkv+\\nD3HRSzsQmYDCHE9PQtHCQmu7zvBfwfDtKMJdhLckUYAbvl9+zHGQ3poS8BMG\\ndTxpgCr3JnD9d7imlLvZ\\/5Q1XpoF7KdiZkGNsO92zItmLlGD430UaHZpq87o\\nOhWOx+Wob5auOF77vFr3fHJZ2iP9PmpNoeXwuIzpNAXaLHffpbzqRmEik1il\\nh3YoNM1WSzkThEPo3W1pRAfpSmcj85wWI0LMIK3ZuyX2aBn\\/gf2wJh1C3LNA\\nL0bmqJIh6UmmNx1KDqRq0h0gby2cL0RiKbOXiLaT\\/pLROhpSwyu80wpWLzgX\\nAe7n8RauryWlVz4hnH363FRTByhHynRtUcydTROiIIC+e\\/A6oamPvA4yRW6m\\n+5M8a6nW8HZJrEGDfDEpq4Ifipl1Eu4a1KhvSqwOPm8eOVO5uDotvm92eZZa\\ni31e6og8KbDurvLh6AXvEwdXOOm47DDnu1EGTAmSKaDvcTPeVF6RuW\\/FZRDl\\nGX2h5\\/NEqcJI4pvulsHGdP2OE4OkDYvirhUCp6z4YWcqJerhggq4aps4flhq\\nufmcliW8ladQhcOv8ZXxwXdNfvdSqHXDZCx84LQ2RGGzqEZozDicfuudZVSd\\nsVYsafEpCykWiEn3gDjqLuaDAqAeze+g1chxhwqU0nLJuE2YmOWU9FtZYWrN\\nIq9RwwwiPFoWguFazJYeuX8Ht1oDfrT48wtjzpZ6iqxPVCQp0+47l7y+vS1I\\n1Xnaa\\/5ZhDwOoDAKB1b1OI8ZtbRyCXdM9Rujn2VDVmo2SYoPT8ELbN78+RH0\\nQ1O1rsdZ7mpha83+7327oFQLUY5PrMkAhxDwRfjBtIq1AsaG82vBEcwKd9en\\nyKplzE23pXPhcuEGeHgoLElMzp5l6WmdKjDA47bxqYxyvIBMelfvC\\/qZdypo\\nQswg6Rmp6vVIiRke9wUinXzDJSCJa1TcyaXOyodLzVxRQlJ74CYXrk+fwJpp\\niRGg4Zfrr6Cjq6RbPTEu\\/lPBYvLyzwHqv9qkbuaZ+53xyK\\/xCB3AGxrK3RxA\\nUkHvIuWizTbawDxxJOAAl\\/vd+d61e9PMIG\\/puEwKnfBFm3gyAYfFKnlk8Dnd\\nfuFuAeq8ydXRt4AGjVWpccqqJONu9RctA7ihK+M+iTB8AZU74cDiuQcuf2xh\\noKihiwchYUpRkDb8UbidBKq1E4FYo2tRCMKzWvAJojb3vW1owDK9mmnHJxUD\\nnNbwwochSjVx87RrUqhWeG85Xlpfj1W9Me0N2GfF+P+sLhzw7AkHyIsHa97p\\niDCnzS\\/zC7D4d2EfWswWZh\\/Dw++GLe0tX5ZOc+sgqGP\\/JUYaxa48hIqE\\/ZlH\\nPOtmSj8Gm4wsskOzoJUntGXLvs9rhDWcjzBouVRuGv7R\\/YzZCQvEkSQZNI6e\\nwRQzp1j6HgzsM1ahZ\\/JXvwtveScrltHq+E5lNFxxSs5uE4IuNfhbytLh3iR2\\nQc1pYiPoNS3lVhbjJCvqPpR8yeSPkryYE8X\\/0v5Ut5xr2fsDucsu5yfmZyPF\\nVsZmHoOy30wUTY8ndkPn0SWIDZUQpreNkJUhADley3ltCG53qmaxZLyh7eDz\\nRDKUWGE+cRls4qyAPxqSNVkclvrNW9OQi89B1EdHkFV7TIIAI5kYJgydWs5t\\n4wU4913A4mf0J54CF067RWQSYcqVhhtoKEG9FEn0jyhY5Rt0SrdaqxeQS6Ea\\nI7ZvWVX6fZXg7X1rFWn442jYK41HxKY8jGqRlPpWZ+jKmSE48yd\\/wOt7T\\/Te\\n57lfaGlE5TozUhq1XTJTkCiwrbr\\/IUnWbxTT915B9Y0p5YYIjMuJJDnwK1Ht\\neXir2Havh+9gOnszZZvAQSxL76FkCl5uZo0Wv5vbwUUu2App9tU4UE0vf1+h\\n46sDo1o9aBf7ZgyVwRLU4jn6\\/m2Fgo+JLw8G9wrpGpaOwX2geLkkSecbzM1G\\nt1rXJbtJex79mGuXYYby+BKBSo5jWzKy1fe0+G5AjO7KIo\\/UGhCnNk09YIe5\\ntsPHEuCKy3pq7x2OFlfy0j2PWLDiFF6V4mozDt8wwckBelAz1QBDF+fWYr\\/y\\nddS0slwDvXrWUA9DdncfhTKpaoZ31wIQczSrKAH5jazQqNPQ3OcNe20ak6hX\\nzGV5\\/Wz4KVdMjC0QijxKaq5qQIZw4RXdz79p\\/cihWbuYASqQhLAb3CBrpbgg\\nnaGad88sFNRhPapg7t9uM\\/M6pA41MD\\/gIDrJQ\\/Usbm8A\\/LQYghECcG0Fa3+e\\nNUHu83T7z+YFofYQ0eNX8mPFl7Akc6KcGh\\/1WGlZsGzl8OAu\\/QQJ7TLNkrsu\\n4fXJVW98TEf3dk462PgOlxYHkPrFszbJl4G6aen5u5qwPTMMcZmnD2AYU583\\nmkBPL2GBTZvXVCRbSGScC0H\\/IYqj7Jj3jwVpf8GAEq3ro+VgtmPlW1eeT6Gd\\nrvB0SgevtoLTsNR7sh9BbM2tUWtH\\/7j5nX6Tyqd5DeSmMrB1HJSAZzIQNUVS\\nSVFCqGHPusm2MCVNG+wibvXxUBScQlORugUcH5nMaZ6y8+QRoSffeI0SttWe\\nDV9GS8QjhHSIJpKh1D\\/VEnWtyt7wjd\\/M3zIWCVQqsYa28QdBcG\\/SNLJQYvxP\\nTb0G0WcgCCLaRa1CTa7BHk8FcApL1xSazVHf9fXthb0RsdmTeQ+bxyhknkNP\\new7L7ooUPPBXhSQGcYskZTtyzGhsvE4Yz\\/7ztZ3EMvYMfRgcTCxGj0ooADZ+\\n10AnPdsAzSZFDSa9ausP6Aj59+HCXrlIFFcNngZ1LGfU2UBBHaksuQgG1nXc\\n6U4BUSNiP5BEkcO5CDioa5YqZK4bkZP3HKc1z0ni6u31rQc00QJNz+kRtxBA\\nIUCGZQs+1yhxkBfaFSXlxoWTnJ5LlvyPLmxKk00NDGFvWFtSSmuBTS2N82GG\\nkZMDNeeyECb8bcJXN\\/HYBSzZE2EvvMCizZrc9ADWVrDmYgxOSEpfwqBlqj46\\nMMZKcXx6fiEHCxbPBMIxnJf5YhvV2quIDpoBEDNtU8fmrUpc1vva6T8txz6q\\nD6++dMo9uw8VKUbiEq+yNTcI\\/hw2McnntxgEYVv+bHK8L6xas6Xa1Eslet6k\\nkLa7SAuzjKQct3jKmuQvVDbepcDHie41RuzV7QwuhRdhkQibxFqP0QRy3LdR\\nX9IPGEFKPtGOwoMORaNr3o6EAP7d\\/mw5uAMnuJSknaxoWjHIrIqYWbRajQLq\\nF+IaTlNsaqK9goCUwTe0Lay+wvwrac\\/HrIQXL8A\\/LPlgbJnzoMpx72BxDRhR\\nELOfcxB7ULJ8NsRRNbyZ5GmOJpxuSVZJxgaL3TKzgSb3ijg4rx+JkTiI+oe7\\nPT881lrWh72Dco\\/xmHmHEnthjgBcZTMceP8rfl7dziWd2DbU9RoCGbvLQG2m\\nWjc=\\n=vOi1\\n-----END PGP MESSAGE-----\\n\",\"showUsername\":false,\"showUri\":false,\"showDescription\":false,\"showSecret\":false,\"fullBaseUrl\":\"https:\\/\\/pass.patty.io\"},\"title\":\"You edited the resource lkit_dotenv\",\"fullBaseUrl\":\"https:\\/\\/pass.patty.io\",\"locale\":\"en-UK\"}','{\"Auto-Submitted\":\"auto-generated\",\"Message-ID\":\"<139227f920184398a274feec56e5d129@pass.patty.io>\"}',0,0,4,'2026-07-21 01:44:28','2026-07-21 01:44:28','2026-07-21 01:44:28','[]','stream_socket_client(): Unable to connect to tcp://localhost:25 (Connection refused)'),
(8,'patrick@patty.io',NULL,NULL,'You edited the resource lkit_dotenv','default','LU/resource_update','default','','html','{\"body\":{\"user\":{\"id\":\"2c22e1ca-66dc-4107-b375-f2d0d13dab9b\",\"role_id\":\"e66c3a09-1dda-4143-8fd0-4824233698d9\",\"username\":\"patrick@patty.io\",\"active\":true,\"deleted\":false,\"disabled\":null,\"last_logged_in\":\"2026-07-21T16:29:36+00:00\",\"created\":\"2026-07-08T18:52:16+00:00\",\"modified\":\"2026-07-09T08:46:05+00:00\",\"role\":{\"id\":\"e66c3a09-1dda-4143-8fd0-4824233698d9\",\"name\":\"admin\",\"description\":\"Organization administrator\",\"deleted\":null,\"created_by\":null,\"modified_by\":null,\"deleted_by\":null,\"created\":\"2012-07-04T13:39:25+00:00\",\"modified\":\"2012-07-04T13:39:25+00:00\"},\"profile\":{\"id\":\"45b62c17-d953-4186-825d-30068887222d\",\"user_id\":\"2c22e1ca-66dc-4107-b375-f2d0d13dab9b\",\"first_name\":\"Patrick\",\"last_name\":\"Rho\",\"created\":\"2026-07-08T18:52:16+00:00\",\"modified\":\"2026-07-08T18:52:16+00:00\",\"avatar\":{\"url\":{\"medium\":\"https:\\/\\/pass.patty.io\\/img\\/avatar\\/user_medium.png\",\"small\":\"https:\\/\\/pass.patty.io\\/img\\/avatar\\/user.png\"}}},\"locale\":\"en-UK\"},\"recipient\":{\"id\":\"2c22e1ca-66dc-4107-b375-f2d0d13dab9b\",\"role_id\":\"e66c3a09-1dda-4143-8fd0-4824233698d9\",\"username\":\"patrick@patty.io\",\"active\":true,\"deleted\":false,\"disabled\":null,\"last_logged_in\":\"2026-07-21T16:29:36+00:00\",\"created\":\"2026-07-08T18:52:16+00:00\",\"modified\":\"2026-07-09T08:46:05+00:00\",\"locale\":\"en-UK\",\"groups_users\":[],\"profile\":{\"id\":\"45b62c17-d953-4186-825d-30068887222d\",\"user_id\":\"2c22e1ca-66dc-4107-b375-f2d0d13dab9b\",\"first_name\":\"Patrick\",\"last_name\":\"Rho\",\"created\":\"2026-07-08T18:52:16+00:00\",\"modified\":\"2026-07-08T18:52:16+00:00\",\"avatar\":{\"url\":{\"medium\":\"https:\\/\\/pass.patty.io\\/img\\/avatar\\/user_medium.png\",\"small\":\"https:\\/\\/pass.patty.io\\/img\\/avatar\\/user.png\"}}},\"gpgkey\":{\"id\":\"daf8fe0a-d901-43e9-860d-10dcc8aea0aa\",\"user_id\":\"2c22e1ca-66dc-4107-b375-f2d0d13dab9b\",\"armored_key\":\"-----BEGIN PGP PUBLIC KEY BLOCK-----\\n\\nxjMEak9fuBYJKwYBBAHaRw8BAQdAtxUCLC\\/\\/zhmHYBDOciQGpw6pfQkTlHkm\\nJUy3HP14qwfNHlBhdHJpY2sgUmhvIDxwYXRyaWNrQHBhdHR5LmlvPsLAEwQT\\nFgoAhQWCak9fuAMLCQcJkLtjY7\\/UA9mIRRQAAAAAABwAIHNhbHRAbm90YXRp\\nb25zLm9wZW5wZ3Bqcy5vcmcK7Kj2hAA9eaInncOY3gRpfg1pBOuT+o\\/ePd2e\\nV+I3CQUVCggODAQWAAIBAhkBApsDAh4BFiEErvt0LkIb0y7shGYAu2Njv9QD\\n2YgAAASdAP4h9hzkiLJvy+akbkMJC0IYnusr4IEmAGPg+AqNu\\/LwEgEA5oAh\\nu9432jmw0+CBe4jnaypthOnfCDEh0zApDkrGwQjOOARqT1+4EgorBgEEAZdV\\nAQUBAQdAVuhtKaohrZyb4FpX1c7vIqhDG5q\\/ZQk57bXQoxHrTgIDAQgHwr4E\\nGBYKAHAFgmpPX7gJkLtjY7\\/UA9mIRRQAAAAAABwAIHNhbHRAbm90YXRpb25z\\nLm9wZW5wZ3Bqcy5vcmepRmylsPRiZEkcRJKxEm23ai5EjjDmOPCCw0vvtTmh\\nCQKbDBYhBK77dC5CG9Mu7IRmALtjY7\\/UA9mIAAB5oQD+PlS4\\/ab0oudKi1iH\\nNlGaKnOXTjYVEzelw2md4CtIkOkBALxB1Ys12\\/Ki2RX\\/ueyUjEcc+WqUTB8X\\nPjCnZT1Xy1EC\\n=tjDF\\n-----END PGP PUBLIC KEY BLOCK-----\\n\",\"bits\":256,\"uid\":\"Patrick Rho <patrick@patty.io>\",\"key_id\":\"BB6363BFD403D988\",\"fingerprint\":\"AEFB742E421BD32EEC846600BB6363BFD403D988\",\"type\":\"EdDSA\",\"expires\":null,\"key_created\":\"2026-07-09T08:45:44+00:00\",\"deleted\":false,\"created\":\"2026-07-09T08:46:05+00:00\",\"modified\":\"2026-07-09T08:46:05+00:00\"},\"role\":{\"id\":\"e66c3a09-1dda-4143-8fd0-4824233698d9\",\"name\":\"admin\",\"description\":\"Organization administrator\",\"deleted\":null,\"created_by\":null,\"modified_by\":null,\"deleted_by\":null,\"created\":\"2012-07-04T13:39:25+00:00\",\"modified\":\"2012-07-04T13:39:25+00:00\"}},\"resource\":{\"id\":\"b3f7b360-be12-4011-af21-756bae51f93b\",\"name\":\"lkit_dotenv\",\"username\":\"\",\"uri\":\"\",\"description\":null,\"metadata\":null,\"metadata_key_id\":null,\"metadata_key_type\":null,\"deleted\":false,\"expired\":null,\"created\":\"2026-07-21T01:26:12+00:00\",\"modified\":\"2026-07-21T16:31:37+00:00\",\"created_by\":\"2c22e1ca-66dc-4107-b375-f2d0d13dab9b\",\"modified_by\":\"2c22e1ca-66dc-4107-b375-f2d0d13dab9b\",\"resource_type_id\":\"a28a04cd-6f53-518a-967c-9963bf9cec51\",\"secrets\":[{\"user_id\":\"2c22e1ca-66dc-4107-b375-f2d0d13dab9b\",\"data\":\"-----BEGIN PGP MESSAGE-----\\n\\nwV4Do6VaHHleMHkSAQdAK7nLhoKlgNXWP6n\\/a6yMqxrC\\/2dLqwnZw\\/8WgsZE\\nG1Iw7o1xeb4vJnkLmkVd3j9x8nUNSsux9nQk2VtjHLTNtQaY\\/6Ap9\\/iQyJjQ\\nGeJ5BudF0tqXAQWri2ugBpBCQvVRjiQbfrcUHrbcp3T716tdMxXoD4m3Xbm6\\n3CtYyzlLvNlCRkwbonUSb7MrfI\\/lgrZOr0iAdFH0nQYUNmUqS0FVmKNtZHY2\\n6M\\/nAkOsWVNc8Vtrw\\/rKJQUl1wPx4ee2pqMB5p3qZJ\\/Z3sh+g8tEwXpDUWk5\\njggDBLY42aGN9E1MGf3yo\\/FtINFQvGW+ItBeUOwycue35evmqZAKBDbaWEEU\\nadwhphjs\\/WR8cEVQw0AMSFTmsWlKy5XljcUSVrrpZWOrs4QQk0vhycsNfDJe\\n51X+VvBaoYiudydLycZSuossSly9iFH9Y6JhfyPrqwyk\\/rhQ2wwyseBvkVxg\\nN57jdHvGvI9gSQI2EVIw5rWgKeDfBU7Kk7jxEWHFAy34h+mK5EntLB6grnQW\\nKoRJ5lkMV6BTDMd0wKcINkjq7MP7mDFKPaE6EJXFxBjVbV+G2qiJSdHsf0bN\\nOGOWMxbYSOw89YaIVcXs3oovFa22Ha4n+TCY3V8jhnC6vUWbM+6J26y5jFvC\\nFYI6VJBhOAvY03i4uyNOBwR3BgB5e8VZRcqtCLHnc1xjJFWcR9cYLFtbEPGc\\nCIEdJu3lA8XfGcOMtGI5T4Lp7zdUTsTBdUZi+NF3yANRo03QVN+zZu2TEoN0\\n+aYQm1druy9zDCC7PFFCKbvZrWUZ0FU3HkXS1Ti9yTrQzI8ykAYTZSuueMN9\\n8rBtUnlYQOuwoKbSb\\/hpPj3En57gj4yOehhDlsS3R3VTRav8w6HCgECcaMKe\\nLDShDI0IDQyR1ZNyFUK6aqJrlh8bO1Nx+A4aq3PW+LSd0l\\/hCikFd9Ky3ePU\\n9qNjeaomTy9LTQgpWNXdPBxjgSZXdcZiS\\/HOxJvpfYshKKPxAWLwzDYsEKkU\\nYJoZvm7ULmTxYdkuzb073B\\/D4V5EGbOnwx6cYnHKOAHwS6SOqmJ+yKsH7Mhy\\nfypM4mh34L0z\\/4LWdet8XAMKv6Tq4UfjP\\/nCKH5Mhjc9tmYRu1Vf+gJoCKgq\\n8JdE1Dhg36jc1U3vErwsXZ7U49njhVw51gI4ca6Dhg4sWrVQ8vpCi3Cem2x3\\npyP46lg+LvEH1ecODdHUMlT+ovNIzMWkageNeicp4fYDcL9s2jtlIKOWMer9\\naLoIY6nBOer5wZt2WtS0OL\\/LxDOZ19tr5f50feLAcl0APsf06Jlz2UraCe1I\\ngtyw54rx0KN4aGPrQmX+Pu663sxWqiI0Ssr1R+kZR3E5SZyDIl9uTR4iZlO0\\nsvD1OGHNdnq8luiLa1SPXNfw3st6HF9BPz4y8enNhaBmMUXZcPqxQ1apKGTH\\nJoFxO7fkbGCY0SxUa8br9YiH7u1g0gR7iYXtq6hojI9aNU0xKk2jjNhPSx9A\\nL+8Z9bfRXEmeSixwz0nnV6UpLX9WN8sxymWP43dZTy9vIOoELWH6SL5JmZzE\\nxnG4cEz+Ut7GhJoBY4lG0on4BhUyCps+Mm6G92igbW+4l42atlpWILPcQqfY\\nz7Du0K3QPSKhOEkVULG28BBUzgXQEt\\/pfkFdJBWy0lt\\/EAi8lMeZ+4K3drpE\\nrsv9kCgkzKt8e5Z3Il4IVuckbgt3cLrRdPv+cS68bZ75BOzcwy8UcUx+jeRC\\nkM+K6hAoRwj\\/IgNs+UhuUVfcHXRZW+U2WeXs7ZlPjLcNoFUe9S2M88X7xGGL\\nXRyiSVQSA+XrLCV\\/QZROFa0r182Yk4Eas64RjRp4Xnij21vyemc4rn3ofIhk\\nwo85G7vgka0WQVcP3IClvM+i0RyQKkyF0a9o\\/orHtzIpGzldfEygnt5eYIWE\\nNxLz3k1b\\/Gm7STO+gyQ\\/FGKj0TEGxTnJod\\/52ZBoLntgegmLiTAvYHPRITFf\\nY29cmk3WGCgAzGe4TMS1rMcN1vGhdFHfDRBoRkIFewDws3NO6ynHTo8AaLbU\\nkCJ8HsC5wdmHIUuTI0iE2tDYBcVcKcgS32totcdw4ikih7Drg1mCv1MXmuKG\\nco5s16P1UEvT13SmvLPKKoM+jmmyw9I4kQXjG8e0oUtLhDD0Dla9krlobtbP\\nXIXmv0aMu\\/OtRYOXdZgdRR3\\/nEO6xZuHR6ZlERfpo\\/6C303H+tLqbH4w32oY\\niPPn7vlod7cdAy4ud\\/znLvIYpRhpYY+cFQqBIyNBm+sV0XltdSFDdMGVzMxU\\nILnEGk3uzj5Y4+NhXJSkCNgsda2IabYbahrduWn7NbeTMOEzsAhZwTLvEEnQ\\nWBF62+BIYaLOD5iF2Ktoek9JoFosjIxvpQt4XaU5z\\/ts5M+sODVJTfNN7s0K\\n3QMvg5Gq3BVIFe1IVvnPj06n8OzSU4OBK79zuhjTM\\/NmyK45X4tYwq6hJTc8\\nwRUDS8way9N9RMmXLtKh2xCI15XRIYD42DhlTXzXb0RYSw0b2ebGzcoyurlv\\n7niJCd0wM88MLucy2AMm3dj7fOEThaez5uJ0UPKZCn03KUQrXkQbNs59apO8\\nVYen6LIi6r89QRQdTS8fIjAfvuv9y46wbR6MCMdOMpL9Z51S7RJDu\\/S+8VhW\\nXXLWhV365DmnLgCP\\/lrrg1TcYu0lFt0TU0j8TuAWtG6SK\\/fkMj6PuRIPi+Is\\n2Nvl4NEe8aD6oQd19BHYhS\\/\\/GjexLRWNOShU8N9eU5Czsfpgh32vV3igoMyb\\nmeUaF3NfFZA4vy1BS\\/0ozZ59VkJDd0XAbzGyjo1Y6hebfh5qtgPgoXymEZ6p\\noGkX4cyGRKzWrLS5UaC40ypQ4\\/2ems83HOROHcbogiR9bTiVn5BTDfvfXjLa\\nRqFoIleWPO4Ey\\/0C0O0qHiv4alMwrgswe5AaUJn2AsmJkyV4F24kro+YA87P\\nJ1Lw11LpJdTmcymGCEdFNFqoIBav2xO63aicBNnrbCVav796K4r2HNwKdmOw\\nugZ5rUIPP17\\/LijKTEPpBF10B3UxZUeLYhTkyimfdAWRbybYV3YNslNRh7mR\\nvUhXI2Dpuntm1oFjnw2STi3+DNB44eFA4vSg2GZ3oc\\/1f9m\\/xLyAy8XfjS8v\\nQuIf5nI8DI6cibBrwDKlyqQqMdSwxLs8XgPTvecUmfSHHj5sBEgnmlnVy47L\\n9yDlmH3SFjrurSKHCvD7hEzxrwrcM4s1+yrsCJD0ObX9tpGoMIa3W\\/YbOvUe\\nFoVRIrpDd\\/Vc+iO5kJS7NrNwv19Gavgk3bprg7yygCvg0SkxI95tZfCHVz5r\\nCVgKBPKqrxD\\/BML3ACGnHBR4VA4rIO72zmMlU5WMdgtExt2e6C2QF8jLmzWb\\n0Y5zG+LgCPZYgoi6bzGf0c8pxG9hhTh9Y4Scld8YuGk9UapgtRacPavDsc3w\\nrgrpg7EDepRTqUoWLHAgcdrcip78N7iBkMatFx4wclkor4ngO2RHGQZiGlT5\\nS+gxKdDrpi\\/tuWTEXBvY96ban9jvhfqZv9L6rLWCBsTCZSbomTgYUPzAszox\\nh+pXUDJNQB1t\\/UCHf6uuxOFFMqSEe5gCnzAp0MnrH+9e1dL4YcWl+lK9E7hr\\nTFxu2SZ32hrlUComKo+0tXXwqpZ7rvVCfoRYE615nqciZWi6q5v3Hl\\/iuV8y\\n88XJVivrB6uHZ9qaXexr01GpCzBFhFDrQyf0GRPdJq1Ca+lJJfvo9FwSfd37\\nMG3LJK4GNCJMWPZNi3qqTkZlBqJqy8D7jOQ\\/m6qQryW0y7FDxTDabA+92Qq0\\nZqehdvGsZfZv\\/9KqFl7SNwXCbv48+1EWDc8mOMa5hOdKRjm4cAtcYYIH6FFC\\nqV2qYwyVp0M\\/MMjr0rRkNaIaOJxZ2rMgvOn17Z0y03nPc2IPkJOjcYl6A7kz\\nCpvXT9JkmKHSU8eyOZmID\\/DTt39ZgHp0WgiyCXBPhiwqxEzbOVXI0M41WW01\\n85L4re4Jsh7xqAE69l8woHGHZwsRDZxemEyXjz\\/1MpISzgxfcrgwstt8mjFL\\n1Q5Grcmpf9TPMECnNWjQSkOp9zu4pdyot3Rcrea0ad2\\/HOwFiN5nPj4wHJSm\\n8r3vlyYwP\\/NBAXpA\\/a5oLkdfMrSaaNwhfEImUOb+vy2Ub5iRwCBfQUzieU75\\njPtRmHDzoCQlYVYtOShYgfyxZNSvDL2fGV8W8bUyfoqpEvnSFQ+moLsgubDO\\nTTzrDwsW1tw\\/VHZYxMLXlX1qFmF4I+a07eiZW8CaoAR2ZOpTf4u9AJ7NH62t\\nMsUwqMbQfNg\\/SAgY8o8YLX7G8FVHTUUW+0iKnWkhRLocBdu\\/Qpoo3nkxBrgI\\n6vUU20E4oMf4zlwN0N0a0EZ1LSeFciYiK\\/X9olrS9AgyCj5HsKN7hQ1FvRUr\\nEs1mHTGdwVi+AvNVag8ypwVLqk1wYGhco5q+3CETIaCqrUEhqsqaHpnjgkNK\\nPjlu415ppCcuDv2KS6vc12UUQVYeqtnfemb8qEa8CiI8xa\\/O+kw85sztr7EG\\niKKl0AqEZvHgi9c287fjaDe7dmUohByNILF\\/uxwcZvBDTfnb7vHylw2fCyQr\\nDegtLFh\\/25ntCq\\/rTHZ3RAXJwlZmx5J76YTW60MDxnK4xQD7R7+oileNwBFP\\nJicr6muQbXXcoJs+PCe3q5d9bKgztmB1SSJtgtPnvVzPS9iW9rztk15DMyEt\\npMO00kihYRxM0Xm3e\\/ncTO19\\/rgDT8l5nlwQWoiFAloxR035M54mBlJvO6zQ\\nOAk+ucgVQ+P8rYCJ4T1+WdZ\\/bal0Kce4cDv7mAJ3z\\/opKPVMqIB8eJXeImIF\\n0dKmIOk\\/aqGcqA1tA\\/C6bvPaZ2L2PVeemPfc2NDX991gdsnz+ARWZhFGrqO7\\n2DK1+21sUvSZ1vqqJdUkkQy8oq+d0ghG7cn7SADPR83IxCvSAp9hjz4BTd9V\\nxGcE2soySSw3KONs6N95psVeG0iCiMYz4tbJOmB3\\/ZQnzLdyH96qFr21eor7\\n4OfhBsZFvPXIw+r\\/cPgX+sLQQ2uYXZmEbgbjdzB0uWJnIepjNTD9lrFvEKvl\\nSwtXuyiSPCSYXaJloOgKm\\/hpapAMBI8EJOWurrA+27k7MGuUDbotlTjchcuK\\niW+dB93F9J3kjTCja1Jn4Ilkt0L2GvloHIRXE1uLOopsIGcPU5SFniTCGRlc\\nS5sBwovNhLnuK4VkKzpjUGKYQV1FZ35qzSBreYwwCjgHFwv1+dpJvMLo30YQ\\nmxOyH1\\/73T0o\\/QM7juT3K4h1SZtnyKT2\\/CGyyjTjQrRyyM7MD1v1wZUCWvcY\\nh31X+9KDPMCUVwv2uMVx4zRsln8OA6nN\\/iOJUaqgkgcPnfd7ej+N9cKvLMvP\\nXLt3tJEQhka9bpTgwJVe1RBqoV1PoTaBSDENzlLgMgeMAOeJTuLd7w9nyN65\\nliQdHI3+iT7j1XDFfxq3EUozaggTmpYfVka3zjKFxLFNvKzqy5JsSVAi2V0U\\nHg3v9316kotc4Zhs1cHe\\/gy8T8U+j4W0kgdAdX89D6jGsAIQA8Pr9k\\/XJiGA\\n8\\/1cb8Wj7WQxynM8o7Aqops\\/6rLvEutphKPVyre\\/81u9Xt4XFb9Nn15xDYVD\\ny9NQrEg6J53CECrCYwE4oAtYGkCcUKXqwe9aIU1YwpCRSvEnkAZ+7Lmx4rtk\\njUECA474cIeFehRheOPYFxmYkz6SgS8wXBkZrfm64N0C5vcPHzMbYZrE40P2\\npQv4Lv4JvpbOOe0cwxVGXzDz0ikFhYKuFg5iPqEY0vDGuYU3CK67mM3JnLXz\\nvpcHrEVDXNwwU3baZt2OP3cR8ejVRfJTiKXIePCHpuwY\\/bcAW4DRebzcS4\\/d\\ngdscp48f0duqM1TmwLIwKv+2cse6UZIdEWnuCFBNSAqySRghiZ5rEFRsGG72\\ngp7sCwwSgYFeHIW9SxNI6q6MRh+AlcU2q8A4YLvUgZIaJ\\/Qx8BvT8oOm\\/c\\/j\\n0J5xXFVm0k4obVP5fT1UsvkiTJ\\/YVQTHL\\/0dRGxHz9QHCjSQgzrNIvcbkmGX\\nVDwIyjk4Mg1ADbz44S\\/DHGs2pnBS8\\/cF0LzM9gUFZiBVYCgA+nb\\/GHOjszDU\\nGQbLeZzlrOfvhOy6E6U92hzrDG+MsCkPKe2GKHuwShvnK\\/lmZRWReiFAmMA3\\nOas+kKED77VwYVUq+TD8\\/M89btmZ+nj9sfwsW+yOztqIBJk0IwcRXIFTMh\\/k\\nE9VeDAtVkgtW9DFiziYMJebrmup5iOHwUPajGsFqsQZ\\/BTmvfsdvXiAMTUCi\\ntV+IdOU806qS2bXQ\\/Zb6fD8xTquwwu6j+RCatOTWnxPgyPhoIO1KgOM43+bK\\nV2TDVSB1Cdr07h3IOffsRbiUn8wzqyQu9\\/zYB07Jb6iajUH2MQe32wE8J34w\\n4XT0+s29q9ttSvK9qlw3oyykc57hDbiMAuSIEpUVb17qJq3VFw3XpJrIeVz7\\nsXI2CSiYOJGdI58b0ZDW1cHxTq2BjTEVlH\\/K7YObxtMHqA7fkRqIASPjM6gb\\n2ezRZTP4JGIf20V4deVHwWcLquxIHcJqHY8B3jMkktboxu\\/qdDJaYmDpn0M\\/\\npDyejWy1+h2LpgMuooxmHd0\\/Xmlm+zaNKa9axN2myYUcygl0jXw4kT\\/Lboav\\nKGJcVTHX3fWt6+TICYYp7VrO7VYnJlWsrdut3w4VEaXZ84oUmLQQOLsqSzJI\\nqefix3xpIg1EfycVh24Oj598FgGTfoLHMvYtgliQRRZWLgZoemGiivrHbtva\\nfCpn9SZy1KtVIvookQCH2\\/6hdGiAo8MVl2bWhJWvAEM2yA6a6FnSi2dWM\\/nn\\n7IQAUcbETxolfBJAUB2xPZ698IITgwPmDmEU28SOAIlfSdfM7NFqR+p22E5M\\n8XEq+PyTHJrQCtO9QpkOJMcO1mOuiJfY\\/CU7ohvfy5gbBBAFmNqZMwoeCMQD\\nf2eSyrocx8fqkJuYj5EeT4EhpreL4HnmwI\\/hAvtRQkxVKNxM7\\/SRL3etHsi9\\nJ7+PRTgr6a\\/BI0a9cmF+jM6r3VU5qQ0k4UwgQ0hisRxgsy4ahrLq47FetPrU\\nSOg2x5Do1zO8pV\\/rcZueRB92Hhto6f1tLX6molS2yc2+xwkYanoNmvA2y5Bj\\n4DsMvAKLAc3oxPk3WzqT4sdeJBuwCUEyoDR+lhVDrwaFL0ZvIxlBMugzc7Fp\\nXncb+8wfJoNErGBbUht+XaK\\/h9QdYj\\/V0YxF0JYUVJ6Kx9lj4+nfaKt+jADq\\newhmuHV8nqQ\\/sgloA8lRsJRIzVHDXDx1IW2agqeeafqCP0QhWMHGx3mH0iWR\\nEJJ+SWr8Pg6HnuTJ1cuFKCoQ6ZnZCVA\\/r3e\\/ecqTIRJcIM2KqDIs+7DIBkUW\\nO4SF5NdKa12b7ww6qDbvHB5JcelNIm8vourOeXMMgPqBIrGcmisNTSRsj4i2\\nNQ1JpvacMiZtFO1RqafR9xEv6Mz1AXrDVI7XkrBi3M1dgLuqZ4Q4CLPJVfO6\\n5xDTneq0EYQ1QjKd3YP452Fqtf9zrOJeOf4gqz0dG2AcjqdF6CN1Fg7PvmZo\\nn6lh80kqLi1xZcb3KSYHn7zCPV2WCNum2JHD2fVbGayNpGkSx877BH4Ec0S+\\nxzJ1Egn2ipzuLdQtMSgsHmIXXIO0vAEZPgJybS78a0ngfXYJMqUI+Vk18TyW\\nMiVJu18xPYsNbcFt1Nqsu6K\\/UlcDlzSKZd6eZDnZ0ngLzgnvJShEwMzyohWc\\nZ7d\\/cYDVaq\\/+eV87a62NmjYzkW9riPAVHR3vNjQsrl81hAD6qxRq46t1s3Zt\\ntsJe9QbTb1IoRttjy17iaJC+CeNITvR+YNgBvZYLDNlv0iBDIr8vkQ9Bq488\\nh8d2zX3VLZgjo0Bw0Kct4opuTcJphi8od+kDIsh1FcGzHOg94Gb0tLHYpmA1\\nrcLZMmXT1wiJWlOgJB1kmOD7GM7hE\\/Hq88Kfjve62L1iJebcdwWKgnZyQ7jd\\nnfkbSgampteS4GVzCV5vDWTCDBmXT70D34o8x5IX6V6GlJlaXJkMrihsVUqu\\nZlRmzWXinFv9nleayWTi\\/hr4ZhWOxcCJPCh3CyYDtQf4\\/iPKRfE10m\\/0hTRA\\nKpnn6\\/OUwjfbPcR1i5eUHvKM3NkjUYQoToe88q9Sn\\/FoJQyb1CGo4pIoSpYP\\nw7F6hZsPG6FIQIK1LWqWwadwP2AlkVMFYNtjNjf7kP0CnwuhDn\\/cwRAcidWX\\nWtczqK4bjLsVU99e2LUVlbQv0Nb2kiDcwp+cXhK0OWSPqzNEyplizDfXM3c+\\nXfqbKNl5qa4PN7zrt9zMd62UMpDHFaUh4\\/tirzSpKvprGAi3mkEKgMsTxg0h\\nUqUAdgQzb8F9WRz3LdKQtys8qaL8dZrsvj0XUKRxshi0JcosRS2Xxi+9S3Q2\\nCwFiFvGiIJSrk+WFoMVQs8CSk\\/UI6VHllSuZQ1sOIDksJ8O17rK5nqKtDUbz\\nwYfwWmOwbAKfm5DFY\\/K+dmnI9x4X2FwL2fnZ5GHZVwny+6wn1TpogUbn4odL\\n\\/VCJ2dG5hoNXTDVltbrW25lUkinZfNBwJ59a\\/wz3lPgGBN8M5lB3Jce07NxH\\n4P\\/zIG+aEHMOVojHOwa64t43xPSOTqZKy74iivdE++JNs8WWFSU45abfAK7C\\nmh6wjWx028LztNEqjuz5UH8n4LObDAGxiFGkVZYsed\\/w8RYcM+U9rr0xPJ7i\\nKh5LMpTlQLaedaN8UNcuWVE1+a07HbTSVZR8LEf4Rg3oWUAPsGJR0rigvA3O\\nwkYi2Xmk6LtNuL1VsMNOwg2rdexoCdS6o9m66rLVCJOYkw5SIl3jSrtcBOHl\\nNw3P83+xs9SIyC+xYasnHD4yatZs496iJ7C1JywqUY9SQNGTuo+ANJt0eUZq\\nqXama\\/N7At8Qnoo\\/xcqDa2lV3dooG+e63mbP9fKBzrzNrpr5ZX\\/16U8Qz9LW\\nIDEmKHRSyVnjiFz2vQOHlMp9bueQm7tT8HulCwYqnjizryQOhOz\\/7u\\/zMN69\\nZHGSiQat9BFy03OeoW6hjZpVn6VPL6LlxjkkzuLzJoFF\\/UGaWwoeRzES+cgl\\n1kqx1\\/3oHT6A87uUXBozu4huUXTLnsCNKZMz3ShlavnsSarIEALRmRoi2Nzr\\nb3czubSOzTRIHzVs8nBtlGduhZbqmqOuk1YY2Heq0XdG8QBylxnUi0tws6jL\\nW++oeLhxYIe1w1zjcgSWsVFcEL1YHDKcdWoW3DDKSrE\\/xQJ2I8Lh5hH\\/1FOj\\neUkapFanFpYAMQ\\/5ybtwpNDtta2GtR4ZrJNGXI3qMemfkkb5+ehCg2xCGork\\naDKE7sELHFoq5SWwMEN4uTKWUrFciFIIsC+pQTk6x4mNJ13A\\/N+Rdk+Z0u3S\\nBajVO+ypyiv\\/5Io+EZClTNifX+oHJSXfFJHoJhkkluunm6yk9OTtPs1ks9n1\\nOYcD8OhH\\/oaGx\\/ks\\/f3YUS6KtYT314hXPbstDOFXPczT1xS2Wjeo+8PGguUa\\nMBvGAMUAdUKdh0s8zaKouP4WpckKRSfNX6Ax0WK7bUTX\\n=WN+J\\n-----END PGP MESSAGE-----\\n\",\"modified_by\":\"2c22e1ca-66dc-4107-b375-f2d0d13dab9b\",\"created_by\":\"2c22e1ca-66dc-4107-b375-f2d0d13dab9b\",\"secret_revision_id\":\"57bc5e37-b80f-4244-9dee-5b6e13a4464f\",\"resource_id\":\"b3f7b360-be12-4011-af21-756bae51f93b\",\"created\":\"2026-07-21T16:31:37+00:00\",\"modified\":\"2026-07-21T16:31:37+00:00\",\"id\":\"468afc4a-df1d-45e7-a876-b7f60b57ff62\"}]},\"armoredSecret\":\"-----BEGIN PGP MESSAGE-----\\n\\nwV4Do6VaHHleMHkSAQdAK7nLhoKlgNXWP6n\\/a6yMqxrC\\/2dLqwnZw\\/8WgsZE\\nG1Iw7o1xeb4vJnkLmkVd3j9x8nUNSsux9nQk2VtjHLTNtQaY\\/6Ap9\\/iQyJjQ\\nGeJ5BudF0tqXAQWri2ugBpBCQvVRjiQbfrcUHrbcp3T716tdMxXoD4m3Xbm6\\n3CtYyzlLvNlCRkwbonUSb7MrfI\\/lgrZOr0iAdFH0nQYUNmUqS0FVmKNtZHY2\\n6M\\/nAkOsWVNc8Vtrw\\/rKJQUl1wPx4ee2pqMB5p3qZJ\\/Z3sh+g8tEwXpDUWk5\\njggDBLY42aGN9E1MGf3yo\\/FtINFQvGW+ItBeUOwycue35evmqZAKBDbaWEEU\\nadwhphjs\\/WR8cEVQw0AMSFTmsWlKy5XljcUSVrrpZWOrs4QQk0vhycsNfDJe\\n51X+VvBaoYiudydLycZSuossSly9iFH9Y6JhfyPrqwyk\\/rhQ2wwyseBvkVxg\\nN57jdHvGvI9gSQI2EVIw5rWgKeDfBU7Kk7jxEWHFAy34h+mK5EntLB6grnQW\\nKoRJ5lkMV6BTDMd0wKcINkjq7MP7mDFKPaE6EJXFxBjVbV+G2qiJSdHsf0bN\\nOGOWMxbYSOw89YaIVcXs3oovFa22Ha4n+TCY3V8jhnC6vUWbM+6J26y5jFvC\\nFYI6VJBhOAvY03i4uyNOBwR3BgB5e8VZRcqtCLHnc1xjJFWcR9cYLFtbEPGc\\nCIEdJu3lA8XfGcOMtGI5T4Lp7zdUTsTBdUZi+NF3yANRo03QVN+zZu2TEoN0\\n+aYQm1druy9zDCC7PFFCKbvZrWUZ0FU3HkXS1Ti9yTrQzI8ykAYTZSuueMN9\\n8rBtUnlYQOuwoKbSb\\/hpPj3En57gj4yOehhDlsS3R3VTRav8w6HCgECcaMKe\\nLDShDI0IDQyR1ZNyFUK6aqJrlh8bO1Nx+A4aq3PW+LSd0l\\/hCikFd9Ky3ePU\\n9qNjeaomTy9LTQgpWNXdPBxjgSZXdcZiS\\/HOxJvpfYshKKPxAWLwzDYsEKkU\\nYJoZvm7ULmTxYdkuzb073B\\/D4V5EGbOnwx6cYnHKOAHwS6SOqmJ+yKsH7Mhy\\nfypM4mh34L0z\\/4LWdet8XAMKv6Tq4UfjP\\/nCKH5Mhjc9tmYRu1Vf+gJoCKgq\\n8JdE1Dhg36jc1U3vErwsXZ7U49njhVw51gI4ca6Dhg4sWrVQ8vpCi3Cem2x3\\npyP46lg+LvEH1ecODdHUMlT+ovNIzMWkageNeicp4fYDcL9s2jtlIKOWMer9\\naLoIY6nBOer5wZt2WtS0OL\\/LxDOZ19tr5f50feLAcl0APsf06Jlz2UraCe1I\\ngtyw54rx0KN4aGPrQmX+Pu663sxWqiI0Ssr1R+kZR3E5SZyDIl9uTR4iZlO0\\nsvD1OGHNdnq8luiLa1SPXNfw3st6HF9BPz4y8enNhaBmMUXZcPqxQ1apKGTH\\nJoFxO7fkbGCY0SxUa8br9YiH7u1g0gR7iYXtq6hojI9aNU0xKk2jjNhPSx9A\\nL+8Z9bfRXEmeSixwz0nnV6UpLX9WN8sxymWP43dZTy9vIOoELWH6SL5JmZzE\\nxnG4cEz+Ut7GhJoBY4lG0on4BhUyCps+Mm6G92igbW+4l42atlpWILPcQqfY\\nz7Du0K3QPSKhOEkVULG28BBUzgXQEt\\/pfkFdJBWy0lt\\/EAi8lMeZ+4K3drpE\\nrsv9kCgkzKt8e5Z3Il4IVuckbgt3cLrRdPv+cS68bZ75BOzcwy8UcUx+jeRC\\nkM+K6hAoRwj\\/IgNs+UhuUVfcHXRZW+U2WeXs7ZlPjLcNoFUe9S2M88X7xGGL\\nXRyiSVQSA+XrLCV\\/QZROFa0r182Yk4Eas64RjRp4Xnij21vyemc4rn3ofIhk\\nwo85G7vgka0WQVcP3IClvM+i0RyQKkyF0a9o\\/orHtzIpGzldfEygnt5eYIWE\\nNxLz3k1b\\/Gm7STO+gyQ\\/FGKj0TEGxTnJod\\/52ZBoLntgegmLiTAvYHPRITFf\\nY29cmk3WGCgAzGe4TMS1rMcN1vGhdFHfDRBoRkIFewDws3NO6ynHTo8AaLbU\\nkCJ8HsC5wdmHIUuTI0iE2tDYBcVcKcgS32totcdw4ikih7Drg1mCv1MXmuKG\\nco5s16P1UEvT13SmvLPKKoM+jmmyw9I4kQXjG8e0oUtLhDD0Dla9krlobtbP\\nXIXmv0aMu\\/OtRYOXdZgdRR3\\/nEO6xZuHR6ZlERfpo\\/6C303H+tLqbH4w32oY\\niPPn7vlod7cdAy4ud\\/znLvIYpRhpYY+cFQqBIyNBm+sV0XltdSFDdMGVzMxU\\nILnEGk3uzj5Y4+NhXJSkCNgsda2IabYbahrduWn7NbeTMOEzsAhZwTLvEEnQ\\nWBF62+BIYaLOD5iF2Ktoek9JoFosjIxvpQt4XaU5z\\/ts5M+sODVJTfNN7s0K\\n3QMvg5Gq3BVIFe1IVvnPj06n8OzSU4OBK79zuhjTM\\/NmyK45X4tYwq6hJTc8\\nwRUDS8way9N9RMmXLtKh2xCI15XRIYD42DhlTXzXb0RYSw0b2ebGzcoyurlv\\n7niJCd0wM88MLucy2AMm3dj7fOEThaez5uJ0UPKZCn03KUQrXkQbNs59apO8\\nVYen6LIi6r89QRQdTS8fIjAfvuv9y46wbR6MCMdOMpL9Z51S7RJDu\\/S+8VhW\\nXXLWhV365DmnLgCP\\/lrrg1TcYu0lFt0TU0j8TuAWtG6SK\\/fkMj6PuRIPi+Is\\n2Nvl4NEe8aD6oQd19BHYhS\\/\\/GjexLRWNOShU8N9eU5Czsfpgh32vV3igoMyb\\nmeUaF3NfFZA4vy1BS\\/0ozZ59VkJDd0XAbzGyjo1Y6hebfh5qtgPgoXymEZ6p\\noGkX4cyGRKzWrLS5UaC40ypQ4\\/2ems83HOROHcbogiR9bTiVn5BTDfvfXjLa\\nRqFoIleWPO4Ey\\/0C0O0qHiv4alMwrgswe5AaUJn2AsmJkyV4F24kro+YA87P\\nJ1Lw11LpJdTmcymGCEdFNFqoIBav2xO63aicBNnrbCVav796K4r2HNwKdmOw\\nugZ5rUIPP17\\/LijKTEPpBF10B3UxZUeLYhTkyimfdAWRbybYV3YNslNRh7mR\\nvUhXI2Dpuntm1oFjnw2STi3+DNB44eFA4vSg2GZ3oc\\/1f9m\\/xLyAy8XfjS8v\\nQuIf5nI8DI6cibBrwDKlyqQqMdSwxLs8XgPTvecUmfSHHj5sBEgnmlnVy47L\\n9yDlmH3SFjrurSKHCvD7hEzxrwrcM4s1+yrsCJD0ObX9tpGoMIa3W\\/YbOvUe\\nFoVRIrpDd\\/Vc+iO5kJS7NrNwv19Gavgk3bprg7yygCvg0SkxI95tZfCHVz5r\\nCVgKBPKqrxD\\/BML3ACGnHBR4VA4rIO72zmMlU5WMdgtExt2e6C2QF8jLmzWb\\n0Y5zG+LgCPZYgoi6bzGf0c8pxG9hhTh9Y4Scld8YuGk9UapgtRacPavDsc3w\\nrgrpg7EDepRTqUoWLHAgcdrcip78N7iBkMatFx4wclkor4ngO2RHGQZiGlT5\\nS+gxKdDrpi\\/tuWTEXBvY96ban9jvhfqZv9L6rLWCBsTCZSbomTgYUPzAszox\\nh+pXUDJNQB1t\\/UCHf6uuxOFFMqSEe5gCnzAp0MnrH+9e1dL4YcWl+lK9E7hr\\nTFxu2SZ32hrlUComKo+0tXXwqpZ7rvVCfoRYE615nqciZWi6q5v3Hl\\/iuV8y\\n88XJVivrB6uHZ9qaXexr01GpCzBFhFDrQyf0GRPdJq1Ca+lJJfvo9FwSfd37\\nMG3LJK4GNCJMWPZNi3qqTkZlBqJqy8D7jOQ\\/m6qQryW0y7FDxTDabA+92Qq0\\nZqehdvGsZfZv\\/9KqFl7SNwXCbv48+1EWDc8mOMa5hOdKRjm4cAtcYYIH6FFC\\nqV2qYwyVp0M\\/MMjr0rRkNaIaOJxZ2rMgvOn17Z0y03nPc2IPkJOjcYl6A7kz\\nCpvXT9JkmKHSU8eyOZmID\\/DTt39ZgHp0WgiyCXBPhiwqxEzbOVXI0M41WW01\\n85L4re4Jsh7xqAE69l8woHGHZwsRDZxemEyXjz\\/1MpISzgxfcrgwstt8mjFL\\n1Q5Grcmpf9TPMECnNWjQSkOp9zu4pdyot3Rcrea0ad2\\/HOwFiN5nPj4wHJSm\\n8r3vlyYwP\\/NBAXpA\\/a5oLkdfMrSaaNwhfEImUOb+vy2Ub5iRwCBfQUzieU75\\njPtRmHDzoCQlYVYtOShYgfyxZNSvDL2fGV8W8bUyfoqpEvnSFQ+moLsgubDO\\nTTzrDwsW1tw\\/VHZYxMLXlX1qFmF4I+a07eiZW8CaoAR2ZOpTf4u9AJ7NH62t\\nMsUwqMbQfNg\\/SAgY8o8YLX7G8FVHTUUW+0iKnWkhRLocBdu\\/Qpoo3nkxBrgI\\n6vUU20E4oMf4zlwN0N0a0EZ1LSeFciYiK\\/X9olrS9AgyCj5HsKN7hQ1FvRUr\\nEs1mHTGdwVi+AvNVag8ypwVLqk1wYGhco5q+3CETIaCqrUEhqsqaHpnjgkNK\\nPjlu415ppCcuDv2KS6vc12UUQVYeqtnfemb8qEa8CiI8xa\\/O+kw85sztr7EG\\niKKl0AqEZvHgi9c287fjaDe7dmUohByNILF\\/uxwcZvBDTfnb7vHylw2fCyQr\\nDegtLFh\\/25ntCq\\/rTHZ3RAXJwlZmx5J76YTW60MDxnK4xQD7R7+oileNwBFP\\nJicr6muQbXXcoJs+PCe3q5d9bKgztmB1SSJtgtPnvVzPS9iW9rztk15DMyEt\\npMO00kihYRxM0Xm3e\\/ncTO19\\/rgDT8l5nlwQWoiFAloxR035M54mBlJvO6zQ\\nOAk+ucgVQ+P8rYCJ4T1+WdZ\\/bal0Kce4cDv7mAJ3z\\/opKPVMqIB8eJXeImIF\\n0dKmIOk\\/aqGcqA1tA\\/C6bvPaZ2L2PVeemPfc2NDX991gdsnz+ARWZhFGrqO7\\n2DK1+21sUvSZ1vqqJdUkkQy8oq+d0ghG7cn7SADPR83IxCvSAp9hjz4BTd9V\\nxGcE2soySSw3KONs6N95psVeG0iCiMYz4tbJOmB3\\/ZQnzLdyH96qFr21eor7\\n4OfhBsZFvPXIw+r\\/cPgX+sLQQ2uYXZmEbgbjdzB0uWJnIepjNTD9lrFvEKvl\\nSwtXuyiSPCSYXaJloOgKm\\/hpapAMBI8EJOWurrA+27k7MGuUDbotlTjchcuK\\niW+dB93F9J3kjTCja1Jn4Ilkt0L2GvloHIRXE1uLOopsIGcPU5SFniTCGRlc\\nS5sBwovNhLnuK4VkKzpjUGKYQV1FZ35qzSBreYwwCjgHFwv1+dpJvMLo30YQ\\nmxOyH1\\/73T0o\\/QM7juT3K4h1SZtnyKT2\\/CGyyjTjQrRyyM7MD1v1wZUCWvcY\\nh31X+9KDPMCUVwv2uMVx4zRsln8OA6nN\\/iOJUaqgkgcPnfd7ej+N9cKvLMvP\\nXLt3tJEQhka9bpTgwJVe1RBqoV1PoTaBSDENzlLgMgeMAOeJTuLd7w9nyN65\\nliQdHI3+iT7j1XDFfxq3EUozaggTmpYfVka3zjKFxLFNvKzqy5JsSVAi2V0U\\nHg3v9316kotc4Zhs1cHe\\/gy8T8U+j4W0kgdAdX89D6jGsAIQA8Pr9k\\/XJiGA\\n8\\/1cb8Wj7WQxynM8o7Aqops\\/6rLvEutphKPVyre\\/81u9Xt4XFb9Nn15xDYVD\\ny9NQrEg6J53CECrCYwE4oAtYGkCcUKXqwe9aIU1YwpCRSvEnkAZ+7Lmx4rtk\\njUECA474cIeFehRheOPYFxmYkz6SgS8wXBkZrfm64N0C5vcPHzMbYZrE40P2\\npQv4Lv4JvpbOOe0cwxVGXzDz0ikFhYKuFg5iPqEY0vDGuYU3CK67mM3JnLXz\\nvpcHrEVDXNwwU3baZt2OP3cR8ejVRfJTiKXIePCHpuwY\\/bcAW4DRebzcS4\\/d\\ngdscp48f0duqM1TmwLIwKv+2cse6UZIdEWnuCFBNSAqySRghiZ5rEFRsGG72\\ngp7sCwwSgYFeHIW9SxNI6q6MRh+AlcU2q8A4YLvUgZIaJ\\/Qx8BvT8oOm\\/c\\/j\\n0J5xXFVm0k4obVP5fT1UsvkiTJ\\/YVQTHL\\/0dRGxHz9QHCjSQgzrNIvcbkmGX\\nVDwIyjk4Mg1ADbz44S\\/DHGs2pnBS8\\/cF0LzM9gUFZiBVYCgA+nb\\/GHOjszDU\\nGQbLeZzlrOfvhOy6E6U92hzrDG+MsCkPKe2GKHuwShvnK\\/lmZRWReiFAmMA3\\nOas+kKED77VwYVUq+TD8\\/M89btmZ+nj9sfwsW+yOztqIBJk0IwcRXIFTMh\\/k\\nE9VeDAtVkgtW9DFiziYMJebrmup5iOHwUPajGsFqsQZ\\/BTmvfsdvXiAMTUCi\\ntV+IdOU806qS2bXQ\\/Zb6fD8xTquwwu6j+RCatOTWnxPgyPhoIO1KgOM43+bK\\nV2TDVSB1Cdr07h3IOffsRbiUn8wzqyQu9\\/zYB07Jb6iajUH2MQe32wE8J34w\\n4XT0+s29q9ttSvK9qlw3oyykc57hDbiMAuSIEpUVb17qJq3VFw3XpJrIeVz7\\nsXI2CSiYOJGdI58b0ZDW1cHxTq2BjTEVlH\\/K7YObxtMHqA7fkRqIASPjM6gb\\n2ezRZTP4JGIf20V4deVHwWcLquxIHcJqHY8B3jMkktboxu\\/qdDJaYmDpn0M\\/\\npDyejWy1+h2LpgMuooxmHd0\\/Xmlm+zaNKa9axN2myYUcygl0jXw4kT\\/Lboav\\nKGJcVTHX3fWt6+TICYYp7VrO7VYnJlWsrdut3w4VEaXZ84oUmLQQOLsqSzJI\\nqefix3xpIg1EfycVh24Oj598FgGTfoLHMvYtgliQRRZWLgZoemGiivrHbtva\\nfCpn9SZy1KtVIvookQCH2\\/6hdGiAo8MVl2bWhJWvAEM2yA6a6FnSi2dWM\\/nn\\n7IQAUcbETxolfBJAUB2xPZ698IITgwPmDmEU28SOAIlfSdfM7NFqR+p22E5M\\n8XEq+PyTHJrQCtO9QpkOJMcO1mOuiJfY\\/CU7ohvfy5gbBBAFmNqZMwoeCMQD\\nf2eSyrocx8fqkJuYj5EeT4EhpreL4HnmwI\\/hAvtRQkxVKNxM7\\/SRL3etHsi9\\nJ7+PRTgr6a\\/BI0a9cmF+jM6r3VU5qQ0k4UwgQ0hisRxgsy4ahrLq47FetPrU\\nSOg2x5Do1zO8pV\\/rcZueRB92Hhto6f1tLX6molS2yc2+xwkYanoNmvA2y5Bj\\n4DsMvAKLAc3oxPk3WzqT4sdeJBuwCUEyoDR+lhVDrwaFL0ZvIxlBMugzc7Fp\\nXncb+8wfJoNErGBbUht+XaK\\/h9QdYj\\/V0YxF0JYUVJ6Kx9lj4+nfaKt+jADq\\newhmuHV8nqQ\\/sgloA8lRsJRIzVHDXDx1IW2agqeeafqCP0QhWMHGx3mH0iWR\\nEJJ+SWr8Pg6HnuTJ1cuFKCoQ6ZnZCVA\\/r3e\\/ecqTIRJcIM2KqDIs+7DIBkUW\\nO4SF5NdKa12b7ww6qDbvHB5JcelNIm8vourOeXMMgPqBIrGcmisNTSRsj4i2\\nNQ1JpvacMiZtFO1RqafR9xEv6Mz1AXrDVI7XkrBi3M1dgLuqZ4Q4CLPJVfO6\\n5xDTneq0EYQ1QjKd3YP452Fqtf9zrOJeOf4gqz0dG2AcjqdF6CN1Fg7PvmZo\\nn6lh80kqLi1xZcb3KSYHn7zCPV2WCNum2JHD2fVbGayNpGkSx877BH4Ec0S+\\nxzJ1Egn2ipzuLdQtMSgsHmIXXIO0vAEZPgJybS78a0ngfXYJMqUI+Vk18TyW\\nMiVJu18xPYsNbcFt1Nqsu6K\\/UlcDlzSKZd6eZDnZ0ngLzgnvJShEwMzyohWc\\nZ7d\\/cYDVaq\\/+eV87a62NmjYzkW9riPAVHR3vNjQsrl81hAD6qxRq46t1s3Zt\\ntsJe9QbTb1IoRttjy17iaJC+CeNITvR+YNgBvZYLDNlv0iBDIr8vkQ9Bq488\\nh8d2zX3VLZgjo0Bw0Kct4opuTcJphi8od+kDIsh1FcGzHOg94Gb0tLHYpmA1\\nrcLZMmXT1wiJWlOgJB1kmOD7GM7hE\\/Hq88Kfjve62L1iJebcdwWKgnZyQ7jd\\nnfkbSgampteS4GVzCV5vDWTCDBmXT70D34o8x5IX6V6GlJlaXJkMrihsVUqu\\nZlRmzWXinFv9nleayWTi\\/hr4ZhWOxcCJPCh3CyYDtQf4\\/iPKRfE10m\\/0hTRA\\nKpnn6\\/OUwjfbPcR1i5eUHvKM3NkjUYQoToe88q9Sn\\/FoJQyb1CGo4pIoSpYP\\nw7F6hZsPG6FIQIK1LWqWwadwP2AlkVMFYNtjNjf7kP0CnwuhDn\\/cwRAcidWX\\nWtczqK4bjLsVU99e2LUVlbQv0Nb2kiDcwp+cXhK0OWSPqzNEyplizDfXM3c+\\nXfqbKNl5qa4PN7zrt9zMd62UMpDHFaUh4\\/tirzSpKvprGAi3mkEKgMsTxg0h\\nUqUAdgQzb8F9WRz3LdKQtys8qaL8dZrsvj0XUKRxshi0JcosRS2Xxi+9S3Q2\\nCwFiFvGiIJSrk+WFoMVQs8CSk\\/UI6VHllSuZQ1sOIDksJ8O17rK5nqKtDUbz\\nwYfwWmOwbAKfm5DFY\\/K+dmnI9x4X2FwL2fnZ5GHZVwny+6wn1TpogUbn4odL\\n\\/VCJ2dG5hoNXTDVltbrW25lUkinZfNBwJ59a\\/wz3lPgGBN8M5lB3Jce07NxH\\n4P\\/zIG+aEHMOVojHOwa64t43xPSOTqZKy74iivdE++JNs8WWFSU45abfAK7C\\nmh6wjWx028LztNEqjuz5UH8n4LObDAGxiFGkVZYsed\\/w8RYcM+U9rr0xPJ7i\\nKh5LMpTlQLaedaN8UNcuWVE1+a07HbTSVZR8LEf4Rg3oWUAPsGJR0rigvA3O\\nwkYi2Xmk6LtNuL1VsMNOwg2rdexoCdS6o9m66rLVCJOYkw5SIl3jSrtcBOHl\\nNw3P83+xs9SIyC+xYasnHD4yatZs496iJ7C1JywqUY9SQNGTuo+ANJt0eUZq\\nqXama\\/N7At8Qnoo\\/xcqDa2lV3dooG+e63mbP9fKBzrzNrpr5ZX\\/16U8Qz9LW\\nIDEmKHRSyVnjiFz2vQOHlMp9bueQm7tT8HulCwYqnjizryQOhOz\\/7u\\/zMN69\\nZHGSiQat9BFy03OeoW6hjZpVn6VPL6LlxjkkzuLzJoFF\\/UGaWwoeRzES+cgl\\n1kqx1\\/3oHT6A87uUXBozu4huUXTLnsCNKZMz3ShlavnsSarIEALRmRoi2Nzr\\nb3czubSOzTRIHzVs8nBtlGduhZbqmqOuk1YY2Heq0XdG8QBylxnUi0tws6jL\\nW++oeLhxYIe1w1zjcgSWsVFcEL1YHDKcdWoW3DDKSrE\\/xQJ2I8Lh5hH\\/1FOj\\neUkapFanFpYAMQ\\/5ybtwpNDtta2GtR4ZrJNGXI3qMemfkkb5+ehCg2xCGork\\naDKE7sELHFoq5SWwMEN4uTKWUrFciFIIsC+pQTk6x4mNJ13A\\/N+Rdk+Z0u3S\\nBajVO+ypyiv\\/5Io+EZClTNifX+oHJSXfFJHoJhkkluunm6yk9OTtPs1ks9n1\\nOYcD8OhH\\/oaGx\\/ks\\/f3YUS6KtYT314hXPbstDOFXPczT1xS2Wjeo+8PGguUa\\nMBvGAMUAdUKdh0s8zaKouP4WpckKRSfNX6Ax0WK7bUTX\\n=WN+J\\n-----END PGP MESSAGE-----\\n\",\"showUsername\":false,\"showUri\":false,\"showDescription\":false,\"showSecret\":false,\"fullBaseUrl\":\"https:\\/\\/pass.patty.io\"},\"title\":\"You edited the resource lkit_dotenv\",\"fullBaseUrl\":\"https:\\/\\/pass.patty.io\",\"locale\":\"en-UK\"}','{\"Auto-Submitted\":\"auto-generated\",\"Message-ID\":\"<9323c32b2a7045898934c8eed4ee54fd@pass.patty.io>\"}',0,0,4,'2026-07-21 16:31:37','2026-07-21 16:31:37','2026-07-21 16:31:37','[]','stream_socket_client(): Unable to connect to tcp://localhost:25 (Connection refused)');
/*!40000 ALTER TABLE `email_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entities_history`
--

DROP TABLE IF EXISTS `entities_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `entities_history` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `action_log_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `foreign_model` varchar(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `foreign_key` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `crud` char(1) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `action_log_id` (`action_log_id`,`foreign_model`,`foreign_key`,`crud`),
  KEY `foreign_key` (`foreign_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entities_history`
--

LOCK TABLES `entities_history` WRITE;
/*!40000 ALTER TABLE `entities_history` DISABLE KEYS */;
INSERT INTO `entities_history` VALUES
('0115a5fc-0d76-4414-a68e-cbb600165f00','4fb81e44-bbb5-4364-84db-ce61c7c9d1f1','FoldersRelationsHistory','bdd90737-b5ad-4c93-8084-d7fb9b0c6d2b','c','2026-07-09 08:49:39'),
('03536e94-257a-4b40-bf50-bd048bfc44f9','e26f0811-b61f-4691-9b9f-7243a8b04da4','SecretAccesses','1f8a0898-bdb5-424d-b735-88588acdb31f','c','2026-07-21 16:29:51'),
('09ffbd38-36f6-471e-9a23-bb15e6f114e1','f1c3e82c-433d-49ea-b1c4-1d0370f64564','Resources','edaec922-7cdf-40ec-8fa9-273015d3c125','c','2026-07-26 13:44:01'),
('0a5282b3-3417-4f2d-95ad-40ff4ef1f354','f0c38cc5-698f-4000-9c8f-be02ad02db46','SecretAccesses','56852481-6356-4996-81a3-7531ba1fe902','c','2026-07-21 01:56:31'),
('0bc3ad44-ce07-4344-8716-261f147cc443','5a360d44-8a9c-4fa8-b6e4-980e65c799d0','SecretAccesses','e791200f-3fea-449a-9b67-2f4e41265771','c','2026-07-21 01:43:53'),
('13bb4ea7-0979-467f-9095-3a0109d1999d','9cdfb0c8-fceb-4b89-a030-c8ec8d8376e9','SecretAccesses','79850e23-a951-433d-9c68-75bee383928c','c','2026-07-21 01:41:40'),
('2269b90f-ab36-4b7a-b9d0-c2bbffb27916','2b2efef9-b4bb-4757-8dcb-3326156376fb','SecretAccesses','197e21c5-5179-4bcc-95be-a79ce081db0a','c','2026-07-21 16:32:24'),
('242190e8-e3e3-4400-8c7a-053c83cb517c','1a842ea3-6544-4330-a41c-fff5a1aef2be','Resources','7672b60a-f739-48fe-9265-1ac6f710557f','c','2026-07-09 08:50:59'),
('3a9a2b9c-5a5b-41d2-9c71-46ce32fa577b','913122dc-a5d5-4c92-b959-1dab29967d7a','SecretAccesses','cddd5357-bc8c-452b-a5bc-1ad2a8d37715','c','2026-07-21 01:41:23'),
('553729fe-ed8c-4927-a7c4-80e60f45791d','b319f7d5-850d-4231-a232-b274bcc2aa06','Resources','b3f7b360-be12-4011-af21-756bae51f93b','u','2026-07-21 01:44:28'),
('5c7a7d2c-e1e9-47c6-92c1-f0a925f68bc5','56da428d-152c-4074-9950-03ad56c7659e','SecretAccesses','ef811f29-34f5-462c-97df-25ba6adbbc53','c','2026-07-21 16:27:09'),
('6da66b54-53d7-452d-864a-8898dfd184d1','b05e84fa-bb1d-45f5-8988-1ed73a01c219','SecretRevisions','57bc5e37-b80f-4244-9dee-5b6e13a4464f','c','2026-07-21 16:31:37'),
('70959f31-8712-4734-9420-028676859620','615ebb57-d301-4a6b-b8f4-a6ccb32acde1','FoldersRelationsHistory','7541eb76-8ed7-4695-a44b-c534c4737eaf','c','2026-07-26 12:58:32'),
('780275ae-b8cb-460b-8d42-441b11d1052d','77686dd5-692e-4ec7-911f-d2a760d5d433','Resources','b3f7b360-be12-4011-af21-756bae51f93b','c','2026-07-21 01:26:12'),
('839d3045-2323-4074-bbf0-2cc7f01ee4ee','b319f7d5-850d-4231-a232-b274bcc2aa06','SecretRevisions','50352ea7-259a-47b1-ba8e-9852bffe81ab','c','2026-07-21 01:44:28'),
('8f06ecc4-a27a-4889-b547-38b4ac5c1191','3814905d-e1f5-47d4-b20b-e5feddb2179f','SecretAccesses','2312e70f-649d-497b-a88c-c0302d883876','c','2026-07-21 16:50:47'),
('a5c93f87-d959-457e-8b1f-70569d698d44','b05e84fa-bb1d-45f5-8988-1ed73a01c219','Resources','b3f7b360-be12-4011-af21-756bae51f93b','u','2026-07-21 16:31:37'),
('b4ebd56d-a806-4ff7-bc20-c6ed75f12e63','aa10b047-339a-4276-b3ca-3ed5d4ed807c','SecretAccesses','822ecb1d-9ef9-47fb-bf07-976f11008c4b','c','2026-07-21 01:41:05'),
('c1613963-73e0-4b32-85ba-2242ca1ccd18','615ebb57-d301-4a6b-b8f4-a6ccb32acde1','FoldersHistory','616e29af-8439-42b2-a98c-e15f3c4708fd','c','2026-07-26 12:58:32'),
('c85ff16a-7a73-477a-ac42-68a5da2a3561','91883c41-8997-45f7-8800-17fd3a636a0b','SecretAccesses','3e30ffc6-8478-4d00-806a-e9764c8a0eda','c','2026-07-21 16:53:49'),
('de497297-1e53-4316-af60-8ad59f0ed540','4fb81e44-bbb5-4364-84db-ce61c7c9d1f1','FoldersHistory','a7df349d-c38a-4444-947f-b30d17834009','c','2026-07-09 08:49:39'),
('e41a24cb-6f17-4ec1-8a1d-a536fef39a83','26337bb3-ef0a-4a4a-a1a0-9c6f794ce564','SecretAccesses','9853fdfe-fb60-4496-85ea-912f3a70de5e','c','2026-07-21 01:47:28'),
('ee8fee51-4640-4d2b-a827-9fd6f5e7f2ee','a008f1ce-dc6f-4440-a009-25b4a301b7f7','SecretAccesses','5debf391-9f7d-40ba-b9d6-413744687770','c','2026-07-21 01:42:10'),
('fa7d6818-edc5-4e97-b28e-b5613335c861','10fd557d-15c1-4e48-ab69-616704ecc717','SecretAccesses','eaafa92d-369c-4bb3-a207-58ddcbc62c05','c','2026-07-21 01:21:33');
/*!40000 ALTER TABLE `entities_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `favorites`
--

DROP TABLE IF EXISTS `favorites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `favorites` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `user_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  `foreign_key` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `foreign_model` varchar(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`,`foreign_model`),
  KEY `foreign_key` (`foreign_key`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `favorites`
--

LOCK TABLES `favorites` WRITE;
/*!40000 ALTER TABLE `favorites` DISABLE KEYS */;
/*!40000 ALTER TABLE `favorites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `folders`
--

DROP TABLE IF EXISTS `folders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `folders` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `name` varchar(256) DEFAULT NULL,
  `metadata` mediumtext DEFAULT NULL,
  `metadata_key_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  `metadata_key_type` varchar(100) DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `created_by` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `modified_by` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `folders`
--

LOCK TABLES `folders` WRITE;
/*!40000 ALTER TABLE `folders` DISABLE KEYS */;
INSERT INTO `folders` VALUES
('50d49e9b-5e79-497d-876d-3eaddb5644fe','Lawyerkit',NULL,NULL,NULL,'2026-07-09 08:49:39','2026-07-09 08:49:39','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','2c22e1ca-66dc-4107-b375-f2d0d13dab9b'),
('f2060f14-7c39-4958-a909-93d6171a1624','PIE',NULL,NULL,NULL,'2026-07-26 12:58:31','2026-07-26 12:58:31','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','2c22e1ca-66dc-4107-b375-f2d0d13dab9b');
/*!40000 ALTER TABLE `folders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `folders_history`
--

DROP TABLE IF EXISTS `folders_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `folders_history` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `folder_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `name` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `folders_history`
--

LOCK TABLES `folders_history` WRITE;
/*!40000 ALTER TABLE `folders_history` DISABLE KEYS */;
INSERT INTO `folders_history` VALUES
('616e29af-8439-42b2-a98c-e15f3c4708fd','f2060f14-7c39-4958-a909-93d6171a1624','PIE'),
('a7df349d-c38a-4444-947f-b30d17834009','50d49e9b-5e79-497d-876d-3eaddb5644fe','Lawyerkit');
/*!40000 ALTER TABLE `folders_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `folders_relations`
--

DROP TABLE IF EXISTS `folders_relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `folders_relations` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `foreign_model` varchar(30) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `foreign_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `user_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `folder_parent_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `folder_parent_id` (`folder_parent_id`),
  KEY `foreign_model_2` (`foreign_model`,`foreign_id`,`user_id`),
  KEY `user_id_2` (`user_id`,`foreign_id`),
  KEY `foreign_id` (`foreign_id`,`folder_parent_id`,`created`),
  KEY `foreign_model` (`foreign_model`,`folder_parent_id`,`user_id`),
  KEY `foreign_model_3` (`foreign_model`,`folder_parent_id`,`foreign_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `folders_relations`
--

LOCK TABLES `folders_relations` WRITE;
/*!40000 ALTER TABLE `folders_relations` DISABLE KEYS */;
INSERT INTO `folders_relations` VALUES
('3bc9874c-0ad4-4574-b46e-0de25dd405be','Resource','edaec922-7cdf-40ec-8fa9-273015d3c125','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','f2060f14-7c39-4958-a909-93d6171a1624','2026-07-26 13:44:01','2026-07-26 13:44:01'),
('57f10ed6-fef3-47f0-afbc-27cb9f71b484','Resource','b3f7b360-be12-4011-af21-756bae51f93b','2c22e1ca-66dc-4107-b375-f2d0d13dab9b',NULL,'2026-07-21 01:26:12','2026-07-21 01:26:12'),
('6191002e-29f9-43b0-9a56-9e4c540be896','Resource','7672b60a-f739-48fe-9265-1ac6f710557f','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','50d49e9b-5e79-497d-876d-3eaddb5644fe','2026-07-09 08:50:59','2026-07-09 08:50:59'),
('7541eb76-8ed7-4695-a44b-c534c4737eaf','Folder','f2060f14-7c39-4958-a909-93d6171a1624','2c22e1ca-66dc-4107-b375-f2d0d13dab9b',NULL,'2026-07-26 12:58:32','2026-07-26 12:58:32'),
('bdd90737-b5ad-4c93-8084-d7fb9b0c6d2b','Folder','50d49e9b-5e79-497d-876d-3eaddb5644fe','2c22e1ca-66dc-4107-b375-f2d0d13dab9b',NULL,'2026-07-09 08:49:39','2026-07-09 08:49:39');
/*!40000 ALTER TABLE `folders_relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `folders_relations_history`
--

DROP TABLE IF EXISTS `folders_relations_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `folders_relations_history` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `foreign_model` varchar(30) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `foreign_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `user_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `folder_parent_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `folders_relations_history`
--

LOCK TABLES `folders_relations_history` WRITE;
/*!40000 ALTER TABLE `folders_relations_history` DISABLE KEYS */;
INSERT INTO `folders_relations_history` VALUES
('7541eb76-8ed7-4695-a44b-c534c4737eaf','Folder','f2060f14-7c39-4958-a909-93d6171a1624','2c22e1ca-66dc-4107-b375-f2d0d13dab9b',NULL),
('bdd90737-b5ad-4c93-8084-d7fb9b0c6d2b','Folder','50d49e9b-5e79-497d-876d-3eaddb5644fe','2c22e1ca-66dc-4107-b375-f2d0d13dab9b',NULL);
/*!40000 ALTER TABLE `folders_relations_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gpgkeys`
--

DROP TABLE IF EXISTS `gpgkeys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `gpgkeys` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `user_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `armored_key` text NOT NULL,
  `bits` int(11) DEFAULT 2048,
  `uid` varchar(769) DEFAULT NULL,
  `key_id` varchar(16) DEFAULT NULL,
  `fingerprint` varchar(51) NOT NULL,
  `type` varchar(16) DEFAULT NULL,
  `expires` datetime DEFAULT NULL,
  `key_created` datetime DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fingerprint` (`fingerprint`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gpgkeys`
--

LOCK TABLES `gpgkeys` WRITE;
/*!40000 ALTER TABLE `gpgkeys` DISABLE KEYS */;
INSERT INTO `gpgkeys` VALUES
('59617fea-6289-429c-915d-b176a1100151','f6af0e88-6246-4f02-9278-e664f61dd3ef','-----BEGIN PGP PUBLIC KEY BLOCK-----\n\nmQGNBGpO8iMBDADJ8JLAhCbplf5mlee//cS+RCrkU85B497UvI5jDw1MltsgxKgc\nv8u5YexE88qOGZuR6imbGAuZvjwuLVt/5HpfPYHM2WMUgvTAiUqHFWhzCccogY/w\n35zsEfylG2d/Pagch3NV9N6L45NJy3pB+dcUyf8yuCc/djOzIX2puHET5uCelRHb\n1tyBFcgH9sCd1fGv3HyS8PxtkCUPNRKNghizsq5ZytxQmYW7uzns7DjnuvllxB59\niKvAQXSUS5hZT5XBWhdcXs8FKWk1bg9xjiDhtSqFVdmo0VL5IVJzT9VrqMX8AC/n\nzrGCF5FXmCTlpkCV3OP2lTKzAggUI/jgJxOlFpNPRXu8eAQdEqV4q3XS5+UfRLs0\ncr5HwQRwIyzrIDOlZPK1X0srn82O6+LXiiuqtmrpslsO4TSOuzu1gx9+VyHi75NB\nFavSmUEM3ulzCt7tRoo0ui56WtHCWgvgDIEV+Ztk2TBMebwzK69gUW0gD8fGPrY+\npHVMEo8hXfg9QusAEQEAAbQtUGF0dHkgQ29kZXggS2V5IEJyb2tlciA8cGF0dHkt\nY29kZXhAcGF0dHkuaW8+iQHSBBMBCgA8FiEEDYOL09jImGjLhxAEZxu96IKFGuEF\nAmpO8iMDGy8EBQsJCAcCAiICBhUKCQgLAgQWAgMBAh4HAheAAAoJEGcbveiChRrh\nlBUL/idcpnMebAr5pezZAGcTT4dK9/63s0Oi/3LaATnEMawgRZY3vFGi78t0EkYN\n+Zkf4QYOGGyrqiBtm58/N+pMoEYiOyBx0gprkXgz3RXYJWXPsJL26/DDD4IShyNC\nZDyP0h2IGc/TqzYQk6v+geJ8c17cI3DJLUy97BrzyZOVrQYLatTaomLcUS1Oqifq\nm0OGFcwCysNIszEb4/wrOW+FtbTHPkwZTIuCgOyaNG70OKGKm8J6BgiRE7ArfER7\nsvzSkiARYgmQelrXT6+HIGqtuKMZmM4qy3wwmPfuOsCoUjPB4VBP8QBRzu3oRQEt\nUmQtqO8avm68Rz5fagQ6c5BsykPhoWfNXCHQ238EKlf/p9tVGowXtBm7At1RvPzv\nlLmeD8GKrO0YjqRKbqpXEMf4z4dish3JJHsD8vtdvQ5wA+7cDoie/1eTRH5blQ4R\nU4e/p8vKids3dtNNRgCUH8Y8x+igwLzqfoxU8tazIFhzoZBYvgv+WF4AabVgK5ZU\n5aY64LkBjQRqTvIjAQwA0GKb6UJFpn7flGjPr3idhOFdCnkFEOw2JI32Zqohe66F\n8oyyLcXYgcnQXOcsb8OBk4cKcAl81c3PXgbsawsVG/ZhruxShpl/T5qpEDhKtOjN\nP3m6MgDZunKJu1yyDjsMGGwj1Gzg1/vuJEPq5f4nPf/BWLIZteGS2PCbrcGXCwDJ\nqU+xmRsL1ZFRt/v0H5vmFpK3FPmSpqKzSZJMOHd8sdnJATI2/mD7m+gt+Cvt5ZCE\nbVMTVmS4bxmW/x+hiGh6P+QyXuyVMuF2DAtkA8LgzYbbIyhyAjVAUJ013q2cG25F\nrHrJ9GW0aDyed1+OrPbhI9xZh8VPQEH1khsbXf/8Atz+ihQkWCmE4PukAA6H8v72\nzBU/A1KsaFYMf1eKfEYM9jOUidkW2ZlK+hY30UfjnmS0bZkeZ9wI283d5qZtiWGx\ntUTnqIyp5JTt6EsgN5AAwGtElLlXtTrSYeBf3Qf8WBxtxcq62qCdkXrr0JvE+75v\n1JtUdiJukqQ2hxMKOSubABEBAAGJA2wEGAEKACAWIQQNg4vT2MiYaMuHEARnG73o\ngoUa4QUCak7yIwIbLgHACRBnG73ogoUa4cD0IAQZAQoAHRYhBIKSoQtyml6jcaI/\nheS/rjlK3hjmBQJqTvIjAAoJEOS/rjlK3hjms94MAMqzMebugjoz28a09Az7GREL\nt8D/4DGRP+2vt4HSYJS/Qlrm2+n2xQEKFQYC2OB4wue1EIJNE9isj0LgP+hGQnh6\nZr5bH9uUO3zjme4HUq4WetmBNp0dtECllUoiQwsM72awMfGMbm+QlkvUWJwDWigY\n9gpcAkUDMFFvjKejeLeQ//1CAVPPb/uOO8RO0AesB3H6htVqqDQu0UT24MvkOnFR\nrO8+yOBrdVAQdcwPa1koHOUyknruC9jxg5sVKbyBMtc+Oq36h6mwRhc+h0E0lj3o\nNMX4K6TPdp0n/BfHHvXgmaYuLetsBW8V+Vn72KQMaa93K7Bw8R7Gv4kVhpaRVPoa\ntO/girxg3r3oMZT3JPKkg3UKXN2iJ7CqTQ7cU2kEWrpKjqUK7zRCyqo68dhXY9Zv\ncF21zLyuj2HLv6TMrScKOAlP4u10/q+jc7CraVeFXf8GjeO8E1T3Uyjqnsahkc3g\ncem/siZ6kh9b59ZLyXpLf7byANpqu33ZJ8DRkUB/tlRkC/4zltuVdeIpBr+Og0Fo\n3t4JaN4W72p2JjFHTX5QhU41MNlS39Fm83dbEYNm6WdjDGxq6PaXwFhaVK0Rh2AY\nf1jyqg0Ek+KmuZQKRldKmDbduCs44G8d2y2kWnThqVleWOvQf1tDcQIR4rRp/AAl\nnU7saeWDOJdP5o+dJ+BPeu9qgIj3CYny3px3R8FdJ/YVgB7trSefxYy652Y0E4BM\nVbRAZT1i20MKxpPOcjU2pkLSPEnWt6IuWTg1l5PlbVRddJ3UXtXkWUoSkfdhIyvU\nsnHnGtWi1AZoDmp7QBgbhYIXSZWLrsug4OcT9A4rL2bGlRtF2UJ6rdLwy65X8SPI\nknWrpk5t5yd94NmQChelMaOiMOgp/7cIUjR+s8NMBM+iIPobKrxVUvEPzRMzOB/0\nVLa7J9Jv9UJiQDdBk9Dtgh6rbEc7doTgRbPKs86Ht6uaGEu1LzklAlf6kNnnzU70\np/596hg6B1YzdMlnkx7MioK1bux21w+93jveIH1UAhtLueA=\n=Y1XE\n-----END PGP PUBLIC KEY BLOCK-----',3072,'Patty Codex Key Broker <patty-codex@patty.io>','671BBDE882851AE1','0D838BD3D8C89868CB871004671BBDE882851AE1','RSA',NULL,'2026-07-09 00:58:13',0,'2026-07-09 00:58:13','2026-07-09 00:58:13'),
('daf8fe0a-d901-43e9-860d-10dcc8aea0aa','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','-----BEGIN PGP PUBLIC KEY BLOCK-----\n\nxjMEak9fuBYJKwYBBAHaRw8BAQdAtxUCLC//zhmHYBDOciQGpw6pfQkTlHkm\nJUy3HP14qwfNHlBhdHJpY2sgUmhvIDxwYXRyaWNrQHBhdHR5LmlvPsLAEwQT\nFgoAhQWCak9fuAMLCQcJkLtjY7/UA9mIRRQAAAAAABwAIHNhbHRAbm90YXRp\nb25zLm9wZW5wZ3Bqcy5vcmcK7Kj2hAA9eaInncOY3gRpfg1pBOuT+o/ePd2e\nV+I3CQUVCggODAQWAAIBAhkBApsDAh4BFiEErvt0LkIb0y7shGYAu2Njv9QD\n2YgAAASdAP4h9hzkiLJvy+akbkMJC0IYnusr4IEmAGPg+AqNu/LwEgEA5oAh\nu9432jmw0+CBe4jnaypthOnfCDEh0zApDkrGwQjOOARqT1+4EgorBgEEAZdV\nAQUBAQdAVuhtKaohrZyb4FpX1c7vIqhDG5q/ZQk57bXQoxHrTgIDAQgHwr4E\nGBYKAHAFgmpPX7gJkLtjY7/UA9mIRRQAAAAAABwAIHNhbHRAbm90YXRpb25z\nLm9wZW5wZ3Bqcy5vcmepRmylsPRiZEkcRJKxEm23ai5EjjDmOPCCw0vvtTmh\nCQKbDBYhBK77dC5CG9Mu7IRmALtjY7/UA9mIAAB5oQD+PlS4/ab0oudKi1iH\nNlGaKnOXTjYVEzelw2md4CtIkOkBALxB1Ys12/Ki2RX/ueyUjEcc+WqUTB8X\nPjCnZT1Xy1EC\n=tjDF\n-----END PGP PUBLIC KEY BLOCK-----\n',256,'Patrick Rho <patrick@patty.io>','BB6363BFD403D988','AEFB742E421BD32EEC846600BB6363BFD403D988','EdDSA',NULL,'2026-07-09 08:45:44',0,'2026-07-09 08:46:05','2026-07-09 08:46:05');
/*!40000 ALTER TABLE `gpgkeys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groups`
--

DROP TABLE IF EXISTS `groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `groups` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `created_by` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `modified_by` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `deleted` (`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groups`
--

LOCK TABLES `groups` WRITE;
/*!40000 ALTER TABLE `groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groups_users`
--

DROP TABLE IF EXISTS `groups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `groups_users` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `group_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  `user_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  `is_admin` tinyint(1) NOT NULL DEFAULT 0,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`,`group_id`),
  KEY `group_id` (`group_id`),
  KEY `user_id_2` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groups_users`
--

LOCK TABLES `groups_users` WRITE;
/*!40000 ALTER TABLE `groups_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `groups_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metadata_keys`
--

DROP TABLE IF EXISTS `metadata_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `metadata_keys` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `fingerprint` varchar(51) NOT NULL,
  `armored_key` text NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `expired` datetime DEFAULT NULL,
  `deleted` datetime DEFAULT NULL,
  `created_by` char(36) CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  `modified_by` char(36) CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `modified_by` (`modified_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metadata_keys`
--

LOCK TABLES `metadata_keys` WRITE;
/*!40000 ALTER TABLE `metadata_keys` DISABLE KEYS */;
/*!40000 ALTER TABLE `metadata_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metadata_private_keys`
--

DROP TABLE IF EXISTS `metadata_private_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `metadata_private_keys` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `metadata_key_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `user_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  `data` mediumtext NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `created_by` char(36) CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  `modified_by` char(36) CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `modified_by` (`modified_by`),
  KEY `metadata_key_id` (`metadata_key_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metadata_private_keys`
--

LOCK TABLES `metadata_private_keys` WRITE;
/*!40000 ALTER TABLE `metadata_private_keys` DISABLE KEYS */;
/*!40000 ALTER TABLE `metadata_private_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metadata_session_keys`
--

DROP TABLE IF EXISTS `metadata_session_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `metadata_session_keys` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `user_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `data` mediumtext NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metadata_session_keys`
--

LOCK TABLES `metadata_session_keys` WRITE;
/*!40000 ALTER TABLE `metadata_session_keys` DISABLE KEYS */;
/*!40000 ALTER TABLE `metadata_session_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organization_settings`
--

DROP TABLE IF EXISTS `organization_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `organization_settings` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `property_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `property` varchar(256) NOT NULL,
  `value` text NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `created_by` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `modified_by` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `property_id` (`property_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organization_settings`
--

LOCK TABLES `organization_settings` WRITE;
/*!40000 ALTER TABLE `organization_settings` DISABLE KEYS */;
INSERT INTO `organization_settings` VALUES
('086d52a9-c807-4ce2-8e1e-3dd31e24d6f2','e5bb8c65-2dab-51c3-b82b-438c77a8c2e8','locale','ko-KR','2026-07-09 08:47:30','2026-07-09 08:47:30','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','2c22e1ca-66dc-4107-b375-f2d0d13dab9b'),
('fdd08c9d-6460-4761-9578-6b1bdf5a89a8','71bc1066-33c2-5746-99f8-c3acfae69beb','edition','ce','2026-07-06 22:26:32','2026-07-06 22:26:32','00000000-0000-0000-0000-000000000000','00000000-0000-0000-0000-000000000000');
/*!40000 ALTER TABLE `organization_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `aco` varchar(30) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `aco_foreign_key` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `aro` varchar(30) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `aro_foreign_key` char(36) CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  `type` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `aco_foreign_key` (`aco_foreign_key`),
  KEY `aro_foreign_key` (`aro_foreign_key`),
  KEY `aco_foreign_key_2` (`aco_foreign_key`,`aro_foreign_key`,`aco`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES
('11a8c7fe-af2a-4597-8c65-f350663ac39e','Resource','edaec922-7cdf-40ec-8fa9-273015d3c125','User','2c22e1ca-66dc-4107-b375-f2d0d13dab9b',15,'2026-07-26 13:44:01','2026-07-26 13:44:01'),
('1dd09841-184c-4949-8eed-c373df1a0bc9','Resource','b619e31a-f69a-48c4-b248-9fd03aea8005','User','f6af0e88-6246-4f02-9278-e664f61dd3ef',15,'2026-07-09 00:58:13','2026-07-09 00:58:13'),
('2c3d3245-2c73-4bb5-8dc5-1f366489c57b','Resource','b3f7b360-be12-4011-af21-756bae51f93b','User','2c22e1ca-66dc-4107-b375-f2d0d13dab9b',15,'2026-07-21 01:26:12','2026-07-21 01:26:12'),
('32995010-01f1-46c6-a1be-dba87b9b0981','Resource','7672b60a-f739-48fe-9265-1ac6f710557f','User','2c22e1ca-66dc-4107-b375-f2d0d13dab9b',15,'2026-07-09 08:50:59','2026-07-09 08:50:59'),
('63c58e98-438d-46f2-8c6c-05e7cdf3fa64','Folder','50d49e9b-5e79-497d-876d-3eaddb5644fe','User','2c22e1ca-66dc-4107-b375-f2d0d13dab9b',15,'2026-07-09 08:49:39','2026-07-09 08:49:39'),
('fe012c5f-2f21-4006-8bd7-0d9d8a6fffe1','Folder','f2060f14-7c39-4958-a909-93d6171a1624','User','2c22e1ca-66dc-4107-b375-f2d0d13dab9b',15,'2026-07-26 12:58:32','2026-07-26 12:58:32');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions_history`
--

DROP TABLE IF EXISTS `permissions_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions_history` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `aco` varchar(30) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `aco_foreign_key` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `aro` varchar(30) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `aro_foreign_key` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `aco_foreign_key` (`aco_foreign_key`),
  KEY `aro_foreign_key` (`aro_foreign_key`),
  KEY `aco` (`aco`,`aro`),
  KEY `type` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions_history`
--

LOCK TABLES `permissions_history` WRITE;
/*!40000 ALTER TABLE `permissions_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `permissions_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phinxlog`
--

DROP TABLE IF EXISTS `phinxlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `phinxlog` (
  `version` bigint(20) NOT NULL,
  `migration_name` varchar(100) DEFAULT NULL,
  `start_time` timestamp NULL DEFAULT NULL,
  `end_time` timestamp NULL DEFAULT NULL,
  `breakpoint` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phinxlog`
--

LOCK TABLES `phinxlog` WRITE;
/*!40000 ALTER TABLE `phinxlog` DISABLE KEYS */;
INSERT INTO `phinxlog` VALUES
(20170830064410,'V162InitialMigration','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20170830065037,'V200ActiveMustBeBoolean','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20170830065038,'V200DropUnusedProfileFields','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20170830065039,'V200IncreaseEmailSize','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20170830065040,'V200DropUnusedCreatedBy','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20170830065041,'V200MigrateUUID','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20170830065042,'V200MigrateKeyField','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20171002061834,'V200DropUnusedResourceFields','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20171006141922,'V200AddFavoriteModifiedField','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20171009093000,'V200DropUnusedPermissionTypesTable','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20171009093001,'V200MigrateEmailsTable','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20171009093002,'V200MigrateFileStorageTable','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20171025154754,'V200AddCommentsUserIdField','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20180102065042,'V200MigrateForeignIdField','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20180102180000,'V200DropUnusedTables','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20180102221500,'V200AddMissingTablesIndexes','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20180202221501,'V200InstallTagsPlugin','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20180413171600,'V202ForceColumnsCharset','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20180503135810,'V210InstallAccountSettingsPlugin','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20180809150900,'V220InstallDirectorySyncPlugin','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20180924163810,'V210AddOrganizationSettingsTable','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20180930151500,'V240AddAuthenticationTokenType','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20181002171600,'V240ExtendAccountSettingsPlugin','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20181024124300,'V250ChangeMfaAccountSettingsDataFormat','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20181210170000,'V270AddMissingIndexes','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20190106170300,'V280AdditionalEmailMigration','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20190106170301,'V280AdditionalFileStorageMigration','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20190106170302,'V280FileDirectoryPathsMigrations','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20190112124290,'V270AddActionsTable','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20190112124300,'V270AddActionLogsTable','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20190121111100,'V270AddEntitiesHistoryTable','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20190121121100,'V270AddPermissionsHistoryTable','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20190211124300,'V270AddSecretsHistoryTable','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20190221124300,'V270AddSecretAccessesTable','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20190327142000,'V280AddTagsIndexesMigrations','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20190512115400,'V2100AddOrganizationSettingsTable','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20190623143400,'V2110ExtendKeyIdSizeField','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20190923103000,'V2120UpdateEmailQueue','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20191119092944,'V2130AddFoldersTable','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20191119092945,'V2130AddFoldersHistoryTable','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20191119160000,'V2120DropUnusedTables','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20191216092944,'V2130AddFoldersRelationsTable','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20191216092945,'V2130AddFoldersRelationsHistoryTable','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20200108135000,'V2130DropLegacyAnonymousUser','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20200205135000,'V2130AddResourcesFoldersRelations','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20200319135000,'V2130SoftDeleteGpgKeysForSoftDeletedUsers','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20200501182000,'V2130ReconcileLoginHistory','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20200609192000,'V2130AddMissingFoldersIndexes','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20200806110200,'V300ExtendSecretsDataField','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20200806110201,'V300AddResourceTypeIdField','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20200806110202,'V300AddResourceTypesTable','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20200806110203,'V300AddResourceTypesDefaultData','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20200806110204,'V300AddResourceTypesToResources','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20200824191900,'V2136CleanupUnusedActionLogs','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20200824191901,'V2136AddActionLogsRelatedIndexes','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20201021165200,'V300ExtendDirectoryReportItemData','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20201221093528,'V300DeleteMetadataOfSoftDeletedResources','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20210111163200,'V300AddActionLogsExtraIndex','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20210121141742,'V320AddAvatarsTable','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20210125212543,'V320TransferFileStorageToAvatars','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20210206521254,'V320DropFileStorage','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20210329110000,'V320FixResourceTypesDefaultData','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20210427124200,'V330AddMobileTransferTable','2026-07-06 22:26:31','2026-07-06 22:26:31',0),
(20211121231000,'V3120MigrateASCIIFieldsEncodingFolders','2026-07-06 22:26:31','2026-07-06 22:26:32',0),
(20211121231001,'V3120MigrateASCIIFieldsEncodingDirectorySync','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20211121231002,'V3120MigrateASCIIFieldsEncodingTags','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20211121231300,'V340MigrateASCIIFieldsEncoding','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20211121231301,'V340MigrateASCIIFieldsEncodingPro','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20211121232400,'V340AddFoldersRelationsExtraIndexes','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20211122732400,'V350ConvertIdFieldsToUuidFields','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20211215180000,'V350RemovePermissionsTypeIndex','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20211215180001,'V350AddPermissionsCombinedIndex','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20220103180000,'V350IncreaseResourcesNameUsernameColumnsSize','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20220103180001,'V350IncreaseResourcesNameUsernameLengthInResourceTypes','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20220308151400,'V360AddAccountRecoveryTables','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20220405232411,'V360RemoveAuthLoginLoginGetActionFromLogs','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20220405234003,'V360RemoveAuthCheckSessionCheckSessionGetFromLogs','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20220405234359,'V360RemoveAuthIsAuthenticatedIsAuthenticatedFromLogs','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20220802151020,'V371CleanUnsharedTagsWithNoUserId','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20220802151030,'V380AlterNameAndSlugOnResourceTypes','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20220802151740,'V380TrimSpacesOnResourceTypesNameAndSlug','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20220809190030,'V372ImproveFoldersRelationsIndexesAddItemsToUserTreePerformance','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20220824081645,'V380AlterNameLengthOnFolders','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20220913233909,'V380SaveSmtpSettingsInDb','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20220915150002,'V380AlterNameLengthOnFoldersHistory','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20220922082044,'V380SaveMfaOrganizationSettingsInDb','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20221012101400,'V380AddSsoTables','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20230202094451,'V3110SaveMfaOrganizationSettingsInDbInDuoV4Format','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20230206055150,'V3110RefactorSsoStates','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20230215095840,'V400ChangeLdapServersConfigKey','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20230308124720,'V3120DropActionLogsDuplicateIndexes','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20230414124720,'V3122DeleteDescriptionForResourceOfTypePasswordAndDescription','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20230418103007,'V400AddTotpResourceTypes','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20230512220600,'V410ImproveFoldersRelationsIndexesShareFoldersPerformance','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20230601101058,'V410RemoveTypeFromTotpResourceTypes','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20230607174200,'V410DeleteRootRole','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20230607174300,'V410AddRbacsTables','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20230607174301,'V410InsertUiActions','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20230607174302,'V410InsertDefaultRbacsUiActions','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20230718083939,'V420AddUserIdIndexToProfiles','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20230809131826,'V420FixDirectorySyncLegacyFieldsMapping','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20230825161859,'V430DropUnusedAllColumnsIndexOnResourcesTags','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20230825161900,'V430AddTagIdUserIdResourceIdResourcesTagsIndex','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20230825161901,'V430DropUnusedResourceIdUserIdIndexOnResourcesTags','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20230911100418,'V430AddUserDisabledField','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20231005121310,'V440MobileTransferInsertUiActions','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20231005123634,'V440MobileTransferDefaultRbacsUiActions','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20231108114414,'V441AlterUidOnGpgkeys','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20231115235026,'V441DropUserAgents','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20231211195437,'V450AddExpiredDateFieldToResources','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20240226143754,'V460ShareFolderUiActions','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20240226145601,'V460ShareFolderDefaultRbacsUiActions','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20240604053611,'V490AddUserIdIndexToGpgkeys','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20240820100802,'V4100AddDeletedToResourceTypes','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20240820102155,'V4100AddV5ResourceTypes','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20240820111234,'V4100CreateMetadataKeys','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20240821045327,'V4100CreateMetadataSessionKeys','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20240821045745,'V4100CreateMetadataPrivateKeys','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20240821051003,'V4100AddMetadataFieldsToFolders','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20240821052253,'V4100AddDataToComments','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20240821052447,'V4100AddMetadataFieldsToTags','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20240821052536,'V4100AddMetadataFieldsToResources','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20240829085449,'V4100AlterNameToNullableOnResources','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20240918070616,'V4100AlterFoldersChangeNameToNullable','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20240923135602,'V4100AlterTagsChangeSlugToNullable','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20241125081300,'V4101ReAddV5ResourceTypes','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20250224132758,'V4121DecouplePersonalTags','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20250704120736,'V530AddCustomFieldStandaloneResourceType','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20250718105206,'V540AddLastLoggedInToUsers','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20250721104543,'V540PopulateLastLoggedInDate','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20250801153254,'V550AddScimEntriesTable','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20250806111000,'V540UpdateV5ResourceTypesDefinitions','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20250813154341,'V541PopulateLastLoggedInDate','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20250902081600,'V550UpdateV5CustomFieldsResourceTypesDefinitions','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20250925101439,'V560AddStandaloneNoteResourceType','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20251027060835,'V570AddCreatedByAndModifiedByToSecrets','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20251027102352,'V570AddDeletedToSecrets','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20251028213926,'V570CreateSecretRevisions','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20251028223602,'V570AddSecretRevisionIdToSecrets','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20251029053757,'V570PopulateCreatedByAndModifiedByInSecretsTable','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20251105054212,'V570PopulateSecretRevisionsForExistingSecrets','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20251127112629,'V580AddDeletedToRoles','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20251127142638,'V580InsertRbacsControlledActions','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20251128071117,'V580AddByFieldsToRoles','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20251203112523,'V580InsertRbacsForActions','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20251215190450,'V580RemoveUniqueIndexOnRolesName','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20260326120000,'V5110MigrateScimSettingsExpiredField','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20260422054904,'V5120AddStandalonePinCodeResourceType','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20260504120000,'V5120AddPartialUniqueIndexOnScimEntries','2026-07-06 22:26:32','2026-07-06 22:26:32',0),
(20260528120318,'V5130PopulateEdition','2026-07-06 22:26:32','2026-07-06 22:26:32',0);
/*!40000 ALTER TABLE `phinxlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profiles`
--

DROP TABLE IF EXISTS `profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `profiles` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `user_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profiles`
--

LOCK TABLES `profiles` WRITE;
/*!40000 ALTER TABLE `profiles` DISABLE KEYS */;
INSERT INTO `profiles` VALUES
('03e1a81a-5dba-4a52-8eda-daecce03173a','f6af0e88-6246-4f02-9278-e664f61dd3ef','Patty Codex','Key Broker','2026-07-09 00:58:13','2026-07-09 00:58:13'),
('0b5c17d7-bdc1-432d-b3db-2d054e868644','51fc08f4-a945-4a70-b5a1-ee0549b66189','Jin','Kim','2026-07-09 00:42:35','2026-07-09 00:42:35'),
('0cf32583-5015-4ea5-9821-0ba820f589ff','c4c6fdac-fd5d-4980-8601-dfd7fab06f16','Ilia','Kim','2026-07-09 00:42:52','2026-07-09 00:42:52'),
('45b62c17-d953-4186-825d-30068887222d','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','Patrick','Rho','2026-07-08 18:52:16','2026-07-08 18:52:16'),
('7ba3c029-53b8-4719-8cb7-defa229cdf0b','b893fc0d-5ea6-4e4c-9511-fc550d8e7519','Patrick','Rho','2026-07-06 22:26:59','2026-07-06 22:26:59'),
('7d7f5bb9-c807-4b41-a811-3d6b8c11fa1e','bd3c4edd-805f-4c49-9c76-a53270539320','David','Shin','2026-07-09 00:42:53','2026-07-09 00:42:53'),
('fff2ab00-a86e-49e9-b719-4062caeca411','0741af5f-6ee4-49c0-ab95-a347f9ebe02a','Leo','Kwon','2026-07-09 00:42:52','2026-07-09 00:42:52');
/*!40000 ALTER TABLE `profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rbacs`
--

DROP TABLE IF EXISTS `rbacs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `rbacs` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `role_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `control_function` varchar(255) CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  `foreign_model` varchar(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `foreign_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `created_by` char(36) CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  `modified_by` char(36) CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_id` (`role_id`,`foreign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rbacs`
--

LOCK TABLES `rbacs` WRITE;
/*!40000 ALTER TABLE `rbacs` DISABLE KEYS */;
INSERT INTO `rbacs` VALUES
('0f97e2d2-5176-4c52-a68b-2a0f1b979ae2','4e7bbb1e-b5cf-450c-a489-c41de1e2908f','Deny','Action','6f880db8-aaaf-5736-8945-6686b3e1b3b9','2026-07-06 22:26:32','2026-07-06 22:26:32',NULL,NULL),
('16eacae6-0598-44a1-8f2b-eee665372025','4e7bbb1e-b5cf-450c-a489-c41de1e2908f','Allow','UiAction','ae3b9379-33ff-4dd7-97f2-2cffd7f86b1d','2026-07-06 22:26:32','2026-07-06 22:26:32',NULL,NULL),
('27cfbd50-703b-4695-939e-cfe2a2bf48a8','4e7bbb1e-b5cf-450c-a489-c41de1e2908f','Deny','Action','e504a917-b977-5cac-967d-d7f90946861b','2026-07-06 22:26:32','2026-07-06 22:26:32',NULL,NULL),
('2c05bf0a-f70b-48c6-a09f-2bbfd37d918f','4e7bbb1e-b5cf-450c-a489-c41de1e2908f','Allow','UiAction','0d617ff4-589d-49aa-b269-83e20ec44c7e','2026-07-06 22:26:32','2026-07-06 22:26:32',NULL,NULL),
('3b5f4674-84cf-4f3f-b62a-027808cc55a3','4e7bbb1e-b5cf-450c-a489-c41de1e2908f','Allow','UiAction','47207478-05ed-4163-9592-c3c58966e79a','2026-07-06 22:26:32','2026-07-06 22:26:32',NULL,NULL),
('42f62d0e-f3c2-45c4-9bf4-89c663c6c1a0','4e7bbb1e-b5cf-450c-a489-c41de1e2908f','Allow','UiAction','ff5bb432-b57c-4e9e-be94-18235c4e1556','2026-07-06 22:26:32','2026-07-06 22:26:32',NULL,NULL),
('4ce70c43-fcea-47d1-a1e9-b9f5d07a64d0','4e7bbb1e-b5cf-450c-a489-c41de1e2908f','Allow','UiAction','fca3f3ee-c504-4c6d-90fb-36554d75c1dd','2026-07-06 22:26:32','2026-07-06 22:26:32',NULL,NULL),
('53ec945c-c931-4b8e-a4d0-05da0bb4b376','4e7bbb1e-b5cf-450c-a489-c41de1e2908f','Allow','UiAction','a837b47d-25c7-4d2f-b17e-29bf6caf45f4','2026-07-06 22:26:32','2026-07-06 22:26:32',NULL,NULL),
('58fb6f66-e25d-4427-8321-7474c5fa4ad0','4e7bbb1e-b5cf-450c-a489-c41de1e2908f','Deny','Action','5bd4ecae-da08-577d-ac32-ce7b13bd7b0f','2026-07-06 22:26:32','2026-07-06 22:26:32',NULL,NULL),
('62578f3c-0f2c-447f-98fa-b963f594812c','4e7bbb1e-b5cf-450c-a489-c41de1e2908f','Allow','UiAction','51850f8d-0b45-44f9-b5cc-6a1e405e87e8','2026-07-06 22:26:32','2026-07-06 22:26:32',NULL,NULL),
('67f64bd1-ec99-427c-9bf3-3ebda6196a7f','4e7bbb1e-b5cf-450c-a489-c41de1e2908f','Allow','UiAction','28194ef8-7d87-4043-bb03-86312e20643c','2026-07-06 22:26:32','2026-07-06 22:26:32',NULL,NULL),
('71687647-d7b3-40ce-93e3-8be14e3bc19c','4e7bbb1e-b5cf-450c-a489-c41de1e2908f','Allow','UiAction','97b8e854-06d1-40ee-a59f-1b44139f95f8','2026-07-06 22:26:32','2026-07-06 22:26:32',NULL,NULL),
('7e2788d9-770d-4d23-a364-163c7fb8e732','4e7bbb1e-b5cf-450c-a489-c41de1e2908f','Allow','UiAction','c5ad0853-5e53-4965-b1e1-115577dba48c','2026-07-06 22:26:32','2026-07-06 22:26:32',NULL,NULL),
('83116928-bf0a-44fe-8ecd-91361e2d8630','4e7bbb1e-b5cf-450c-a489-c41de1e2908f','Allow','UiAction','7e77c8d9-6863-49f2-8b3e-1321e0093362','2026-07-06 22:26:32','2026-07-06 22:26:32',NULL,NULL),
('8626ced1-8638-472f-ae63-e7ed083aab26','4e7bbb1e-b5cf-450c-a489-c41de1e2908f','Allow','UiAction','4da4003b-ca9a-4b20-81b2-7d2cfb4a243c','2026-07-06 22:26:32','2026-07-06 22:26:32',NULL,NULL),
('87f6b888-3a48-476e-8473-cc259f0d89a0','4e7bbb1e-b5cf-450c-a489-c41de1e2908f','Allow','UiAction','2988c73b-049b-4a9a-9602-4d941bc1a1a4','2026-07-06 22:26:32','2026-07-06 22:26:32',NULL,NULL),
('a5532618-f7da-4d63-ba0a-3d43ef99d688','4e7bbb1e-b5cf-450c-a489-c41de1e2908f','Allow','UiAction','2ed74e11-61a0-45b3-af99-56e4f7ed642c','2026-07-06 22:26:32','2026-07-06 22:26:32',NULL,NULL),
('b135dcc0-b27a-461f-9266-5337ef03e11a','4e7bbb1e-b5cf-450c-a489-c41de1e2908f','Allow','UiAction','5d150a2e-b13b-413c-8166-59386e72b559','2026-07-06 22:26:32','2026-07-06 22:26:32',NULL,NULL),
('bd7b3170-d546-41f6-aad9-39ca1603a7c3','4e7bbb1e-b5cf-450c-a489-c41de1e2908f','Allow','UiAction','02043f2c-ca5d-4c98-aeed-5d1c819c8e36','2026-07-06 22:26:32','2026-07-06 22:26:32',NULL,NULL),
('c57aa468-ecac-4507-a4cf-f47111c6bd91','4e7bbb1e-b5cf-450c-a489-c41de1e2908f','Allow','UiAction','28cef07a-22eb-4c0e-ae2a-0e9c935b94d9','2026-07-06 22:26:32','2026-07-06 22:26:32',NULL,NULL),
('cbba5191-881b-441f-a672-b3bb886545ac','4e7bbb1e-b5cf-450c-a489-c41de1e2908f','Allow','UiAction','3cf75d4a-997b-4ccd-bb21-26cc38897e81','2026-07-06 22:26:32','2026-07-06 22:26:32',NULL,NULL),
('d7a76086-0688-4d5f-971d-71d039ae48f0','4e7bbb1e-b5cf-450c-a489-c41de1e2908f','Deny','Action','98b30a6b-2979-5d5c-a8f6-b8a843aa25da','2026-07-06 22:26:32','2026-07-06 22:26:32',NULL,NULL),
('e7b3c87c-04b4-4fb2-ad30-fbc01caca127','4e7bbb1e-b5cf-450c-a489-c41de1e2908f','Allow','UiAction','a94927fe-8cfb-493f-a038-d3059d88a4a7','2026-07-06 22:26:32','2026-07-06 22:26:32',NULL,NULL),
('eb98bb41-0f35-4363-b503-9545e02554d9','4e7bbb1e-b5cf-450c-a489-c41de1e2908f','Allow','UiAction','629a34ff-5add-46b3-becc-a9fd4eab8ea5','2026-07-06 22:26:32','2026-07-06 22:26:32',NULL,NULL);
/*!40000 ALTER TABLE `rbacs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resource_types`
--

DROP TABLE IF EXISTS `resource_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `resource_types` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `slug` varchar(64) DEFAULT NULL,
  `name` varchar(64) DEFAULT NULL,
  `description` char(255) DEFAULT NULL,
  `definition` text DEFAULT NULL,
  `deleted` datetime DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resource_types`
--

LOCK TABLES `resource_types` WRITE;
/*!40000 ALTER TABLE `resource_types` DISABLE KEYS */;
INSERT INTO `resource_types` VALUES
('0551544e-2ccd-5ce8-95cf-86f0aab0f827','v5-custom-fields','Standalone custom fields','A resource with standalone custom fields.','{\"resource\":{\"type\":\"object\",\"required\":[\"name\",\"custom_fields\"],\"properties\":{\"name\":{\"type\":\"string\",\"maxLength\":255},\"uris\":{\"type\":\"array\",\"items\":{\"anyOf\":[{\"type\":\"string\",\"maxLength\":1024},{\"type\":\"null\"}]},\"maxItems\":32},\"description\":{\"anyOf\":[{\"type\":\"string\",\"maxLength\":10000},{\"type\":\"null\"}]},\"icon\":{\"type\":\"object\",\"required\":[],\"properties\":{\"type\":{\"type\":\"string\",\"enum\":[\"keepass-icon-set\",\"passbolt-icon-set\"]},\"value\":{\"type\":\"integer\",\"minimum\":0},\"background_color\":{\"anyOf\":[{\"type\":\"string\",\"pattern\":\"^#(?:[0-9A-Fa-f]{6}|[0-9A-Fa-f]{8})$\"},{\"type\":\"null\"}]}}},\"custom_fields\":{\"type\":\"array\",\"maxItems\":128,\"items\":{\"type\":\"object\",\"required\":[\"id\",\"type\"],\"properties\":{\"id\":{\"type\":\"string\",\"format\":\"uuid\"},\"type\":{\"type\":\"string\",\"enum\":[\"text\",\"password\",\"boolean\",\"number\",\"uri\"]},\"metadata_key\":{\"anyOf\":[{\"type\":\"string\",\"maxLength\":255},{\"type\":\"null\"}]},\"metadata_value\":{\"anyOf\":[{\"type\":\"string\",\"maxLength\":20000},{\"type\":\"number\"},{\"type\":\"boolean\"},{\"type\":\"null\"}]}}}}}},\"secret\":{\"type\":\"object\",\"required\":[\"object_type\",\"custom_fields\"],\"properties\":{\"object_type\":{\"type\":\"string\",\"enum\":[\"PASSBOLT_SECRET_DATA\"]},\"custom_fields\":{\"type\":\"array\",\"maxItems\":128,\"items\":{\"type\":\"object\",\"required\":[\"id\",\"type\"],\"properties\":{\"id\":{\"type\":\"string\",\"format\":\"uuid\"},\"type\":{\"type\":\"string\",\"enum\":[\"text\",\"password\",\"boolean\",\"number\",\"uri\"]},\"secret_key\":{\"anyOf\":[{\"type\":\"string\",\"maxLength\":255},{\"type\":\"null\"}]},\"secret_value\":{\"anyOf\":[{\"type\":\"string\",\"maxLength\":20000},{\"type\":\"number\"},{\"type\":\"boolean\"},{\"type\":\"null\"}]}}}}}}}',NULL,'2026-07-06 22:26:32','2026-07-06 22:26:32'),
('05ba5c75-504d-5ad6-819a-83af68867d86','totp','Standalone TOTP','A resource with standalone TOTP fields.','{\"resource\":{\"type\":\"object\",\"required\":[\"name\"],\"properties\":{\"name\":{\"type\":\"string\",\"maxLength\":255},\"uri\":{\"anyOf\":[{\"type\":\"string\",\"maxLength\":1024},{\"type\":\"null\"}]}}},\"secret\":{\"type\":\"object\",\"required\":[\"totp\"],\"properties\":{\"totp\":{\"type\":\"object\",\"required\":[\"secret_key\",\"digits\",\"algorithm\"],\"properties\":{\"algorithm\":{\"type\":\"string\",\"minLength\":4,\"maxLength\":6},\"secret_key\":{\"type\":\"string\",\"maxLength\":1024},\"digits\":{\"type\":\"number\",\"minimum\":6,\"exclusiveMaximum\":9},\"period\":{\"type\":\"number\"}}}}}}',NULL,'2026-07-06 22:26:32','2026-07-06 22:26:32'),
('0a72c76b-b8e6-53f0-8bef-0a8ca6b5c764','v5-note','Standalone note','A resource with standalone notes.','{\"resource\":{\"type\":\"object\",\"required\":[\"name\"],\"properties\":{\"name\":{\"type\":\"string\",\"maxLength\":255},\"uris\":{\"type\":\"array\",\"items\":{\"anyOf\":[{\"type\":\"string\",\"maxLength\":1024},{\"type\":\"null\"}]},\"maxItems\":32},\"description\":{\"anyOf\":[{\"type\":\"string\",\"maxLength\":10000},{\"type\":\"null\"}]},\"icon\":{\"type\":\"object\",\"required\":[],\"properties\":{\"type\":{\"type\":\"string\",\"enum\":[\"keepass-icon-set\",\"passbolt-icon-set\"]},\"value\":{\"type\":\"integer\",\"minimum\":0},\"background_color\":{\"anyOf\":[{\"type\":\"string\",\"pattern\":\"^#(?:[0-9A-Fa-f]{6}|[0-9A-Fa-f]{8})$\"},{\"type\":\"null\"}]}}}}},\"secret\":{\"type\":\"object\",\"required\":[\"description\",\"object_type\"],\"properties\":{\"object_type\":{\"type\":\"string\",\"enum\":[\"PASSBOLT_SECRET_DATA\"]},\"description\":{\"anyOf\":[{\"type\":\"string\",\"maxLength\":50000},{\"type\":\"null\"}]}}}}',NULL,'2026-07-06 22:26:32','2026-07-06 22:26:32'),
('4357bbc7-ed4d-52ff-b59d-9f7f17881bb3','v5-pin-code','Standalone pin code','A resource with a standalone pin code.','{\"resource\":{\"type\":\"object\",\"required\":[\"name\"],\"properties\":{\"name\":{\"type\":\"string\",\"maxLength\":255},\"description\":{\"anyOf\":[{\"type\":\"string\",\"maxLength\":10000},{\"type\":\"null\"}]},\"icon\":{\"type\":\"object\",\"required\":[],\"properties\":{\"type\":{\"type\":\"string\",\"enum\":[\"keepass-icon-set\",\"passbolt-icon-set\"]},\"value\":{\"type\":\"integer\",\"minimum\":0},\"background_color\":{\"anyOf\":[{\"type\":\"string\",\"pattern\":\"^#(?:[0-9A-Fa-f]{6}|[0-9A-Fa-f]{8})$\"},{\"type\":\"null\"}]}}}}},\"secret\":{\"type\":\"object\",\"required\":[\"pin_code\",\"object_type\"],\"properties\":{\"object_type\":{\"type\":\"string\",\"enum\":[\"PASSBOLT_SECRET_DATA\"]},\"pin_code\":{\"type\":\"string\",\"minLength\":4,\"maxLength\":12,\"pattern\":\"^\\\\d+$\"},\"description\":{\"anyOf\":[{\"type\":\"string\",\"maxLength\":50000},{\"type\":\"null\"}]}}}}',NULL,'2026-07-06 22:26:32','2026-07-06 22:26:32'),
('669f8c64-242a-59fb-92fc-81f660975fd3','password-string','Simple password','The original passbolt resource type, where the secret is a non empty string.','{\"resource\":{\"type\":\"object\",\"required\":[\"name\"],\"properties\":{\"name\":{\"type\":\"string\",\"maxLength\":255},\"username\":{\"anyOf\":[{\"type\":\"string\",\"maxLength\":255},{\"type\":\"null\"}]},\"uri\":{\"anyOf\":[{\"type\":\"string\",\"maxLength\":1024},{\"type\":\"null\"}]},\"description\":{\"anyOf\":[{\"type\":\"string\",\"maxLength\":10000},{\"type\":\"null\"}]}}},\"secret\":{\"type\":\"string\",\"maxLength\":4096}}',NULL,'2026-07-06 22:26:31','2026-07-06 22:26:31'),
('7438294d-f71c-5164-ba95-d9e60e295564','v5-default-with-totp','Default resource type with TOTP','The new default resource type with a TOTP introduced with v5.','{\"resource\":{\"type\":\"object\",\"required\":[\"name\"],\"properties\":{\"name\":{\"type\":\"string\",\"maxLength\":255},\"username\":{\"anyOf\":[{\"type\":\"string\",\"maxLength\":255},{\"type\":\"null\"}]},\"uris\":{\"type\":\"array\",\"items\":{\"anyOf\":[{\"type\":\"string\",\"maxLength\":1024},{\"type\":\"null\"}]},\"maxItems\":32},\"description\":{\"anyOf\":[{\"type\":\"string\",\"maxLength\":10000},{\"type\":\"null\"}]},\"icon\":{\"type\":\"object\",\"required\":[],\"properties\":{\"type\":{\"type\":\"string\",\"enum\":[\"keepass-icon-set\",\"passbolt-icon-set\"]},\"value\":{\"type\":\"integer\",\"minimum\":0},\"background_color\":{\"anyOf\":[{\"type\":\"string\",\"pattern\":\"^#(?:[0-9A-Fa-f]{6}|[0-9A-Fa-f]{8})$\"},{\"type\":\"null\"}]}}},\"custom_fields\":{\"type\":\"array\",\"maxItems\":128,\"items\":{\"type\":\"object\",\"required\":[\"id\",\"type\"],\"properties\":{\"id\":{\"type\":\"string\",\"format\":\"uuid\"},\"type\":{\"type\":\"string\",\"enum\":[\"text\",\"password\",\"boolean\",\"number\",\"uri\"]},\"metadata_key\":{\"anyOf\":[{\"type\":\"string\",\"maxLength\":255},{\"type\":\"null\"}]},\"metadata_value\":{\"anyOf\":[{\"type\":\"string\",\"maxLength\":20000},{\"type\":\"number\"},{\"type\":\"boolean\"},{\"type\":\"null\"}]}}}}}},\"secret\":{\"type\":\"object\",\"required\":[\"password\",\"totp\"],\"properties\":{\"object_type\":{\"type\":\"string\",\"enum\":[\"PASSBOLT_SECRET_DATA\"]},\"password\":{\"type\":\"string\",\"maxLength\":4096},\"description\":{\"anyOf\":[{\"type\":\"string\",\"maxLength\":50000},{\"type\":\"null\"}]},\"totp\":{\"type\":\"object\",\"required\":[\"secret_key\",\"digits\",\"algorithm\"],\"properties\":{\"algorithm\":{\"type\":\"string\",\"minLength\":4,\"maxLength\":6},\"secret_key\":{\"type\":\"string\",\"maxLength\":1024},\"digits\":{\"type\":\"number\",\"minimum\":6,\"exclusiveMaximum\":9},\"period\":{\"type\":\"number\"}}},\"custom_fields\":{\"type\":\"array\",\"maxItems\":128,\"items\":{\"type\":\"object\",\"required\":[\"id\",\"type\"],\"properties\":{\"id\":{\"type\":\"string\",\"format\":\"uuid\"},\"type\":{\"type\":\"string\",\"enum\":[\"text\",\"password\",\"boolean\",\"number\",\"uri\"]},\"secret_key\":{\"anyOf\":[{\"type\":\"string\",\"maxLength\":255},{\"type\":\"null\"}]},\"secret_value\":{\"anyOf\":[{\"type\":\"string\",\"maxLength\":20000},{\"type\":\"number\"},{\"type\":\"boolean\"},{\"type\":\"null\"}]}}}}}}}',NULL,'2026-07-06 22:26:32','2026-07-06 22:26:32'),
('761e5863-e17e-5ded-b3c2-76ffd5d0a2dc','v5-password-string','Simple Password (Deprecated)','The original passbolt resource type, kept for backward compatibility reasons.','{\"resource\":{\"type\":\"object\",\"required\":[\"name\"],\"properties\":{\"name\":{\"type\":\"string\",\"maxLength\":255},\"username\":{\"anyOf\":[{\"type\":\"string\",\"maxLength\":255},{\"type\":\"null\"}]},\"uris\":{\"type\":\"array\",\"items\":{\"anyOf\":[{\"type\":\"string\",\"maxLength\":1024},{\"type\":\"null\"}]},\"maxItems\":32},\"description\":{\"anyOf\":[{\"type\":\"string\",\"maxLength\":10000},{\"type\":\"null\"}]},\"icon\":{\"type\":\"object\",\"required\":[],\"properties\":{\"type\":{\"type\":\"string\",\"enum\":[\"keepass-icon-set\",\"passbolt-icon-set\"]},\"value\":{\"type\":\"integer\",\"minimum\":0},\"background_color\":{\"anyOf\":[{\"type\":\"string\",\"pattern\":\"^#(?:[0-9A-Fa-f]{6}|[0-9A-Fa-f]{8})$\"},{\"type\":\"null\"}]}}}}},\"secret\":{\"type\":\"string\",\"maxLength\":4096}}',NULL,'2026-07-06 22:26:32','2026-07-06 22:26:32'),
('8cca88d9-a3f6-56df-b860-3ef08de5c5c4','password-description-totp','Password, Description and TOTP','A resource with encrypted password, description and TOTP fields.','{\"resource\":{\"type\":\"object\",\"required\":[\"name\"],\"properties\":{\"name\":{\"type\":\"string\",\"maxLength\":255},\"username\":{\"anyOf\":[{\"type\":\"string\",\"maxLength\":255},{\"type\":\"null\"}]},\"uri\":{\"anyOf\":[{\"type\":\"string\",\"maxLength\":1024},{\"type\":\"null\"}]}}},\"secret\":{\"type\":\"object\",\"required\":[\"password\",\"totp\"],\"properties\":{\"password\":{\"type\":\"string\",\"maxLength\":4096},\"description\":{\"anyOf\":[{\"type\":\"string\",\"maxLength\":10000},{\"type\":\"null\"}]},\"totp\":{\"type\":\"object\",\"required\":[\"secret_key\",\"digits\",\"algorithm\"],\"properties\":{\"algorithm\":{\"type\":\"string\",\"minLength\":4,\"maxLength\":6},\"secret_key\":{\"type\":\"string\",\"maxLength\":1024},\"digits\":{\"type\":\"number\",\"minimum\":6,\"exclusiveMaximum\":9},\"period\":{\"type\":\"number\"}}}}}}',NULL,'2026-07-06 22:26:32','2026-07-06 22:26:32'),
('a28a04cd-6f53-518a-967c-9963bf9cec51','password-and-description','Password with description','A resource with the password and the description encrypted.','{\"resource\":{\"type\":\"object\",\"required\":[\"name\"],\"properties\":{\"name\":{\"type\":\"string\",\"maxLength\":255},\"username\":{\"anyOf\":[{\"type\":\"string\",\"maxLength\":255},{\"type\":\"null\"}]},\"uri\":{\"anyOf\":[{\"type\":\"string\",\"maxLength\":1024},{\"type\":\"null\"}]}}},\"secret\":{\"type\":\"object\",\"required\":[\"password\"],\"properties\":{\"password\":{\"type\":\"string\",\"maxLength\":4096},\"description\":{\"anyOf\":[{\"type\":\"string\",\"maxLength\":10000},{\"type\":\"null\"}]}}}}',NULL,'2026-07-06 22:26:31','2026-07-06 22:26:31'),
('bb2280b5-c4d9-569c-9337-62b307f1139c','v5-totp-standalone','Standalone TOTP','The new standalone TOTP resource type introduced with v5.','{\"resource\":{\"type\":\"object\",\"required\":[\"name\"],\"properties\":{\"name\":{\"type\":\"string\",\"maxLength\":255},\"uris\":{\"type\":\"array\",\"items\":{\"anyOf\":[{\"type\":\"string\",\"maxLength\":1024},{\"type\":\"null\"}]},\"maxItems\":32},\"description\":{\"anyOf\":[{\"type\":\"string\",\"maxLength\":10000},{\"type\":\"null\"}]},\"icon\":{\"type\":\"object\",\"required\":[],\"properties\":{\"type\":{\"type\":\"string\",\"enum\":[\"keepass-icon-set\",\"passbolt-icon-set\"]},\"value\":{\"type\":\"integer\",\"minimum\":0},\"background_color\":{\"anyOf\":[{\"type\":\"string\",\"pattern\":\"^#(?:[0-9A-Fa-f]{6}|[0-9A-Fa-f]{8})$\"},{\"type\":\"null\"}]}}}}},\"secret\":{\"type\":\"object\",\"required\":[\"totp\"],\"properties\":{\"object_type\":{\"type\":\"string\",\"enum\":[\"PASSBOLT_SECRET_DATA\"]},\"totp\":{\"type\":\"object\",\"required\":[\"secret_key\",\"digits\",\"algorithm\"],\"properties\":{\"algorithm\":{\"type\":\"string\",\"minLength\":4,\"maxLength\":6},\"secret_key\":{\"type\":\"string\",\"maxLength\":1024},\"digits\":{\"type\":\"number\",\"minimum\":6,\"exclusiveMaximum\":9},\"period\":{\"type\":\"number\"}}}}}}',NULL,'2026-07-06 22:26:32','2026-07-06 22:26:32'),
('dd1f723d-0d1e-513f-8218-4055dc0530d0','v5-default','Default resource type','The new default resource type introduced with v5.','{\"resource\":{\"type\":\"object\",\"required\":[\"name\"],\"properties\":{\"name\":{\"type\":\"string\",\"maxLength\":255},\"username\":{\"anyOf\":[{\"type\":\"string\",\"maxLength\":255},{\"type\":\"null\"}]},\"uris\":{\"type\":\"array\",\"items\":{\"anyOf\":[{\"type\":\"string\",\"maxLength\":1024},{\"type\":\"null\"}]},\"maxItems\":32},\"description\":{\"anyOf\":[{\"type\":\"string\",\"maxLength\":10000},{\"type\":\"null\"}]},\"icon\":{\"type\":\"object\",\"required\":[],\"properties\":{\"type\":{\"type\":\"string\",\"enum\":[\"keepass-icon-set\",\"passbolt-icon-set\"]},\"value\":{\"type\":\"integer\",\"minimum\":0},\"background_color\":{\"anyOf\":[{\"type\":\"string\",\"pattern\":\"^#(?:[0-9A-Fa-f]{6}|[0-9A-Fa-f]{8})$\"},{\"type\":\"null\"}]}}},\"custom_fields\":{\"type\":\"array\",\"maxItems\":128,\"items\":{\"type\":\"object\",\"required\":[\"id\",\"type\"],\"properties\":{\"id\":{\"type\":\"string\",\"format\":\"uuid\"},\"type\":{\"type\":\"string\",\"enum\":[\"text\",\"password\",\"boolean\",\"number\",\"uri\"]},\"metadata_key\":{\"anyOf\":[{\"type\":\"string\",\"maxLength\":255},{\"type\":\"null\"}]},\"metadata_value\":{\"anyOf\":[{\"type\":\"string\",\"maxLength\":20000},{\"type\":\"number\"},{\"type\":\"boolean\"},{\"type\":\"null\"}]}}}}}},\"secret\":{\"type\":\"object\",\"required\":[\"password\"],\"properties\":{\"object_type\":{\"type\":\"string\",\"enum\":[\"PASSBOLT_SECRET_DATA\"]},\"password\":{\"type\":\"string\",\"maxLength\":4096},\"description\":{\"anyOf\":[{\"type\":\"string\",\"maxLength\":50000},{\"type\":\"null\"}]},\"custom_fields\":{\"type\":\"array\",\"maxItems\":128,\"items\":{\"type\":\"object\",\"required\":[\"id\",\"type\"],\"properties\":{\"id\":{\"type\":\"string\",\"format\":\"uuid\"},\"type\":{\"type\":\"string\",\"enum\":[\"text\",\"password\",\"boolean\",\"number\",\"uri\"]},\"secret_key\":{\"anyOf\":[{\"type\":\"string\",\"maxLength\":255},{\"type\":\"null\"}]},\"secret_value\":{\"anyOf\":[{\"type\":\"string\",\"maxLength\":20000},{\"type\":\"number\"},{\"type\":\"boolean\"},{\"type\":\"null\"}]}}}}}}}',NULL,'2026-07-06 22:26:32','2026-07-06 22:26:32');
/*!40000 ALTER TABLE `resource_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resources`
--

DROP TABLE IF EXISTS `resources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `resources` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `uri` varchar(1024) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `metadata` mediumtext DEFAULT NULL,
  `metadata_key_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  `metadata_key_type` varchar(100) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `expired` datetime DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `created_by` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `modified_by` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `resource_type_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`,`modified_by`),
  KEY `deleted` (`deleted`),
  KEY `resource_type_id` (`resource_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resources`
--

LOCK TABLES `resources` WRITE;
/*!40000 ALTER TABLE `resources` DISABLE KEYS */;
INSERT INTO `resources` VALUES
('7672b60a-f739-48fe-9265-1ac6f710557f','nexus/secrets.yaml','','',NULL,NULL,NULL,NULL,0,NULL,'2026-07-09 08:50:59','2026-07-09 08:50:59','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','a28a04cd-6f53-518a-967c-9963bf9cec51'),
('b3f7b360-be12-4011-af21-756bae51f93b','lkit_dotenv','','',NULL,NULL,NULL,NULL,0,NULL,'2026-07-21 01:26:12','2026-07-21 16:31:37','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','a28a04cd-6f53-518a-967c-9963bf9cec51'),
('b619e31a-f69a-48c4-b248-9fd03aea8005','Patty Employees OmniRoute API Key','patty-employees','http://agent.patty.io/v1','Shared OmniRoute API key for Patty employee Codex installs. Stored encrypted for the Patty broker service account.',NULL,NULL,NULL,0,NULL,'2026-07-09 00:58:13','2026-07-09 00:58:13','f6af0e88-6246-4f02-9278-e664f61dd3ef','f6af0e88-6246-4f02-9278-e664f61dd3ef','669f8c64-242a-59fb-92fc-81f660975fd3'),
('edaec922-7cdf-40ec-8fa9-273015d3c125','PIE updater signing key','patty-updater','https://pie.patty.io','Tauri updater signing key for PIE (private half). Public half is committed in desktop/src-tauri/tauri.conf.json. If this key is lost, no installed PIE app can ever self-update — every employee needs a manual reinstall. Restore to resources/certs/updater/patty-updater.key before running scripts/release.sh, together with the password in this item.\n\ndW50cnVzdGVkIGNvbW1lbnQ6IHJzaWduIGVuY3J5cHRlZCBzZWNyZXQga2V5ClJXUlRZMEl5U3R4dE1haGNWdW96NGtmY0xVRk00Z1V1UE9RWDQ2bVdNM00xOEJIZmxzY0FBQkFBQUFBQUFBQUFBQUlBQUFBQTJPazZXd3g5QkZQOW0zQXF4RUYxT21rSkhGcXFuOEFTVXFMdnF2L1diamx1aWY0dXBwYkxKRTFnbHlIQ2Y2bVJCejBXNmR1Q3VYcmMzVmhibE5wWXE1eUEwdDFkQi8wbEJZUlp1NDhpTk9NUmFOM3Rya1NmbWltakhkSVVCaHNacXVkN1BuTmtFdUU9Cg==',NULL,NULL,NULL,0,NULL,'2026-07-26 13:44:01','2026-07-26 13:44:01','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','669f8c64-242a-59fb-92fc-81f660975fd3');
/*!40000 ALTER TABLE `resources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resources_tags`
--

DROP TABLE IF EXISTS `resources_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `resources_tags` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `resource_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `tag_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `user_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tag_id` (`tag_id`,`user_id`,`resource_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resources_tags`
--

LOCK TABLES `resources_tags` WRITE;
/*!40000 ALTER TABLE `resources_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `resources_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `deleted` datetime DEFAULT NULL,
  `created_by` char(36) CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  `modified_by` char(36) CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  `deleted_by` char(36) CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES
('4e7bbb1e-b5cf-450c-a489-c41de1e2908f','user','Logged in user',NULL,NULL,NULL,NULL,'2012-07-04 13:39:25','2012-07-04 13:39:25'),
('790acb63-1d8c-416a-831f-c1ca60af6b75','guest','Non logged in user',NULL,NULL,NULL,NULL,'2012-07-04 13:39:25','2012-07-04 13:39:25'),
('e66c3a09-1dda-4143-8fd0-4824233698d9','admin','Organization administrator',NULL,NULL,NULL,NULL,'2012-07-04 13:39:25','2012-07-04 13:39:25');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scim_entries`
--

DROP TABLE IF EXISTS `scim_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scim_entries` (
  `id` char(36) NOT NULL,
  `foreign_key` char(36) DEFAULT NULL,
  `foreign_model` varchar(36) NOT NULL,
  `external_identifier` varchar(256) DEFAULT NULL,
  `scim_name` varchar(256) DEFAULT NULL,
  `deleted` datetime DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `foreign_model` (`foreign_model`),
  KEY `foreign_key` (`foreign_key`),
  KEY `external_identifier` (`external_identifier`),
  KEY `created` (`created`)
) ENGINE=InnoDB DEFAULT CHARSET=ascii COLLATE=ascii_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scim_entries`
--

LOCK TABLES `scim_entries` WRITE;
/*!40000 ALTER TABLE `scim_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `scim_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `secret_accesses`
--

DROP TABLE IF EXISTS `secret_accesses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `secret_accesses` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `user_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `resource_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `secret_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `secret_id` (`secret_id`),
  KEY `user_id` (`user_id`,`resource_id`),
  KEY `resource_id` (`resource_id`),
  KEY `user_id_2` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `secret_accesses`
--

LOCK TABLES `secret_accesses` WRITE;
/*!40000 ALTER TABLE `secret_accesses` DISABLE KEYS */;
INSERT INTO `secret_accesses` VALUES
('197e21c5-5179-4bcc-95be-a79ce081db0a','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','b3f7b360-be12-4011-af21-756bae51f93b','468afc4a-df1d-45e7-a876-b7f60b57ff62','2026-07-21 16:32:24'),
('1f8a0898-bdb5-424d-b735-88588acdb31f','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','b3f7b360-be12-4011-af21-756bae51f93b','e18ad78c-782d-458c-b965-14b270e6ea2b','2026-07-21 16:29:51'),
('2312e70f-649d-497b-a88c-c0302d883876','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','7672b60a-f739-48fe-9265-1ac6f710557f','bdd24fd7-a058-416a-9cfb-36621db1ae6e','2026-07-21 16:50:47'),
('3e30ffc6-8478-4d00-806a-e9764c8a0eda','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','7672b60a-f739-48fe-9265-1ac6f710557f','bdd24fd7-a058-416a-9cfb-36621db1ae6e','2026-07-21 16:53:49'),
('56852481-6356-4996-81a3-7531ba1fe902','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','7672b60a-f739-48fe-9265-1ac6f710557f','bdd24fd7-a058-416a-9cfb-36621db1ae6e','2026-07-21 01:56:31'),
('5debf391-9f7d-40ba-b9d6-413744687770','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','7672b60a-f739-48fe-9265-1ac6f710557f','bdd24fd7-a058-416a-9cfb-36621db1ae6e','2026-07-21 01:42:10'),
('79850e23-a951-433d-9c68-75bee383928c','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','b3f7b360-be12-4011-af21-756bae51f93b','a802a116-3ac0-49fe-8513-9086b9cbda82','2026-07-21 01:41:40'),
('822ecb1d-9ef9-47fb-bf07-976f11008c4b','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','b3f7b360-be12-4011-af21-756bae51f93b','a802a116-3ac0-49fe-8513-9086b9cbda82','2026-07-21 01:41:05'),
('9853fdfe-fb60-4496-85ea-912f3a70de5e','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','b3f7b360-be12-4011-af21-756bae51f93b','e18ad78c-782d-458c-b965-14b270e6ea2b','2026-07-21 01:47:28'),
('cddd5357-bc8c-452b-a5bc-1ad2a8d37715','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','b3f7b360-be12-4011-af21-756bae51f93b','a802a116-3ac0-49fe-8513-9086b9cbda82','2026-07-21 01:41:23'),
('e791200f-3fea-449a-9b67-2f4e41265771','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','b3f7b360-be12-4011-af21-756bae51f93b','a802a116-3ac0-49fe-8513-9086b9cbda82','2026-07-21 01:43:53'),
('eaafa92d-369c-4bb3-a207-58ddcbc62c05','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','7672b60a-f739-48fe-9265-1ac6f710557f','bdd24fd7-a058-416a-9cfb-36621db1ae6e','2026-07-21 01:21:33'),
('ef811f29-34f5-462c-97df-25ba6adbbc53','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','b3f7b360-be12-4011-af21-756bae51f93b','e18ad78c-782d-458c-b965-14b270e6ea2b','2026-07-21 16:27:09');
/*!40000 ALTER TABLE `secret_accesses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `secret_revisions`
--

DROP TABLE IF EXISTS `secret_revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `secret_revisions` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `resource_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `resource_type_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `deleted` datetime DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `created_by` char(36) CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  `modified_by` char(36) CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `resource_id` (`resource_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `secret_revisions`
--

LOCK TABLES `secret_revisions` WRITE;
/*!40000 ALTER TABLE `secret_revisions` DISABLE KEYS */;
INSERT INTO `secret_revisions` VALUES
('0fbd759e-e8bf-401b-a43d-f4cc96ce599f','edaec922-7cdf-40ec-8fa9-273015d3c125','669f8c64-242a-59fb-92fc-81f660975fd3',NULL,'2026-07-26 13:44:01','2026-07-26 13:44:01','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','2c22e1ca-66dc-4107-b375-f2d0d13dab9b'),
('3d060cde-ed6c-488a-ad26-d7e9b7bd1eaa','b3f7b360-be12-4011-af21-756bae51f93b','a28a04cd-6f53-518a-967c-9963bf9cec51','2026-07-21 01:44:28','2026-07-21 01:26:12','2026-07-21 01:26:12','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','2c22e1ca-66dc-4107-b375-f2d0d13dab9b'),
('50352ea7-259a-47b1-ba8e-9852bffe81ab','b3f7b360-be12-4011-af21-756bae51f93b','a28a04cd-6f53-518a-967c-9963bf9cec51','2026-07-21 16:31:37','2026-07-21 01:44:28','2026-07-21 01:44:28','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','2c22e1ca-66dc-4107-b375-f2d0d13dab9b'),
('57bc5e37-b80f-4244-9dee-5b6e13a4464f','b3f7b360-be12-4011-af21-756bae51f93b','a28a04cd-6f53-518a-967c-9963bf9cec51',NULL,'2026-07-21 16:31:37','2026-07-21 16:31:37','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','2c22e1ca-66dc-4107-b375-f2d0d13dab9b'),
('d027e3cb-afac-4d17-b51f-85e02ef814d7','7672b60a-f739-48fe-9265-1ac6f710557f','a28a04cd-6f53-518a-967c-9963bf9cec51',NULL,'2026-07-09 08:50:59','2026-07-09 08:50:59','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','2c22e1ca-66dc-4107-b375-f2d0d13dab9b');
/*!40000 ALTER TABLE `secret_revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `secrets`
--

DROP TABLE IF EXISTS `secrets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `secrets` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `user_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `resource_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `secret_revision_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  `deleted` datetime DEFAULT NULL,
  `created_by` char(36) CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  `modified_by` char(36) CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  `data` mediumtext NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`,`resource_id`),
  KEY `resource_id` (`resource_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `secrets`
--

LOCK TABLES `secrets` WRITE;
/*!40000 ALTER TABLE `secrets` DISABLE KEYS */;
INSERT INTO `secrets` VALUES
('468afc4a-df1d-45e7-a876-b7f60b57ff62','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','b3f7b360-be12-4011-af21-756bae51f93b','57bc5e37-b80f-4244-9dee-5b6e13a4464f',NULL,'2c22e1ca-66dc-4107-b375-f2d0d13dab9b','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','-----BEGIN PGP MESSAGE-----\n\nwV4Do6VaHHleMHkSAQdAK7nLhoKlgNXWP6n/a6yMqxrC/2dLqwnZw/8WgsZE\nG1Iw7o1xeb4vJnkLmkVd3j9x8nUNSsux9nQk2VtjHLTNtQaY/6Ap9/iQyJjQ\nGeJ5BudF0tqXAQWri2ugBpBCQvVRjiQbfrcUHrbcp3T716tdMxXoD4m3Xbm6\n3CtYyzlLvNlCRkwbonUSb7MrfI/lgrZOr0iAdFH0nQYUNmUqS0FVmKNtZHY2\n6M/nAkOsWVNc8Vtrw/rKJQUl1wPx4ee2pqMB5p3qZJ/Z3sh+g8tEwXpDUWk5\njggDBLY42aGN9E1MGf3yo/FtINFQvGW+ItBeUOwycue35evmqZAKBDbaWEEU\nadwhphjs/WR8cEVQw0AMSFTmsWlKy5XljcUSVrrpZWOrs4QQk0vhycsNfDJe\n51X+VvBaoYiudydLycZSuossSly9iFH9Y6JhfyPrqwyk/rhQ2wwyseBvkVxg\nN57jdHvGvI9gSQI2EVIw5rWgKeDfBU7Kk7jxEWHFAy34h+mK5EntLB6grnQW\nKoRJ5lkMV6BTDMd0wKcINkjq7MP7mDFKPaE6EJXFxBjVbV+G2qiJSdHsf0bN\nOGOWMxbYSOw89YaIVcXs3oovFa22Ha4n+TCY3V8jhnC6vUWbM+6J26y5jFvC\nFYI6VJBhOAvY03i4uyNOBwR3BgB5e8VZRcqtCLHnc1xjJFWcR9cYLFtbEPGc\nCIEdJu3lA8XfGcOMtGI5T4Lp7zdUTsTBdUZi+NF3yANRo03QVN+zZu2TEoN0\n+aYQm1druy9zDCC7PFFCKbvZrWUZ0FU3HkXS1Ti9yTrQzI8ykAYTZSuueMN9\n8rBtUnlYQOuwoKbSb/hpPj3En57gj4yOehhDlsS3R3VTRav8w6HCgECcaMKe\nLDShDI0IDQyR1ZNyFUK6aqJrlh8bO1Nx+A4aq3PW+LSd0l/hCikFd9Ky3ePU\n9qNjeaomTy9LTQgpWNXdPBxjgSZXdcZiS/HOxJvpfYshKKPxAWLwzDYsEKkU\nYJoZvm7ULmTxYdkuzb073B/D4V5EGbOnwx6cYnHKOAHwS6SOqmJ+yKsH7Mhy\nfypM4mh34L0z/4LWdet8XAMKv6Tq4UfjP/nCKH5Mhjc9tmYRu1Vf+gJoCKgq\n8JdE1Dhg36jc1U3vErwsXZ7U49njhVw51gI4ca6Dhg4sWrVQ8vpCi3Cem2x3\npyP46lg+LvEH1ecODdHUMlT+ovNIzMWkageNeicp4fYDcL9s2jtlIKOWMer9\naLoIY6nBOer5wZt2WtS0OL/LxDOZ19tr5f50feLAcl0APsf06Jlz2UraCe1I\ngtyw54rx0KN4aGPrQmX+Pu663sxWqiI0Ssr1R+kZR3E5SZyDIl9uTR4iZlO0\nsvD1OGHNdnq8luiLa1SPXNfw3st6HF9BPz4y8enNhaBmMUXZcPqxQ1apKGTH\nJoFxO7fkbGCY0SxUa8br9YiH7u1g0gR7iYXtq6hojI9aNU0xKk2jjNhPSx9A\nL+8Z9bfRXEmeSixwz0nnV6UpLX9WN8sxymWP43dZTy9vIOoELWH6SL5JmZzE\nxnG4cEz+Ut7GhJoBY4lG0on4BhUyCps+Mm6G92igbW+4l42atlpWILPcQqfY\nz7Du0K3QPSKhOEkVULG28BBUzgXQEt/pfkFdJBWy0lt/EAi8lMeZ+4K3drpE\nrsv9kCgkzKt8e5Z3Il4IVuckbgt3cLrRdPv+cS68bZ75BOzcwy8UcUx+jeRC\nkM+K6hAoRwj/IgNs+UhuUVfcHXRZW+U2WeXs7ZlPjLcNoFUe9S2M88X7xGGL\nXRyiSVQSA+XrLCV/QZROFa0r182Yk4Eas64RjRp4Xnij21vyemc4rn3ofIhk\nwo85G7vgka0WQVcP3IClvM+i0RyQKkyF0a9o/orHtzIpGzldfEygnt5eYIWE\nNxLz3k1b/Gm7STO+gyQ/FGKj0TEGxTnJod/52ZBoLntgegmLiTAvYHPRITFf\nY29cmk3WGCgAzGe4TMS1rMcN1vGhdFHfDRBoRkIFewDws3NO6ynHTo8AaLbU\nkCJ8HsC5wdmHIUuTI0iE2tDYBcVcKcgS32totcdw4ikih7Drg1mCv1MXmuKG\nco5s16P1UEvT13SmvLPKKoM+jmmyw9I4kQXjG8e0oUtLhDD0Dla9krlobtbP\nXIXmv0aMu/OtRYOXdZgdRR3/nEO6xZuHR6ZlERfpo/6C303H+tLqbH4w32oY\niPPn7vlod7cdAy4ud/znLvIYpRhpYY+cFQqBIyNBm+sV0XltdSFDdMGVzMxU\nILnEGk3uzj5Y4+NhXJSkCNgsda2IabYbahrduWn7NbeTMOEzsAhZwTLvEEnQ\nWBF62+BIYaLOD5iF2Ktoek9JoFosjIxvpQt4XaU5z/ts5M+sODVJTfNN7s0K\n3QMvg5Gq3BVIFe1IVvnPj06n8OzSU4OBK79zuhjTM/NmyK45X4tYwq6hJTc8\nwRUDS8way9N9RMmXLtKh2xCI15XRIYD42DhlTXzXb0RYSw0b2ebGzcoyurlv\n7niJCd0wM88MLucy2AMm3dj7fOEThaez5uJ0UPKZCn03KUQrXkQbNs59apO8\nVYen6LIi6r89QRQdTS8fIjAfvuv9y46wbR6MCMdOMpL9Z51S7RJDu/S+8VhW\nXXLWhV365DmnLgCP/lrrg1TcYu0lFt0TU0j8TuAWtG6SK/fkMj6PuRIPi+Is\n2Nvl4NEe8aD6oQd19BHYhS//GjexLRWNOShU8N9eU5Czsfpgh32vV3igoMyb\nmeUaF3NfFZA4vy1BS/0ozZ59VkJDd0XAbzGyjo1Y6hebfh5qtgPgoXymEZ6p\noGkX4cyGRKzWrLS5UaC40ypQ4/2ems83HOROHcbogiR9bTiVn5BTDfvfXjLa\nRqFoIleWPO4Ey/0C0O0qHiv4alMwrgswe5AaUJn2AsmJkyV4F24kro+YA87P\nJ1Lw11LpJdTmcymGCEdFNFqoIBav2xO63aicBNnrbCVav796K4r2HNwKdmOw\nugZ5rUIPP17/LijKTEPpBF10B3UxZUeLYhTkyimfdAWRbybYV3YNslNRh7mR\nvUhXI2Dpuntm1oFjnw2STi3+DNB44eFA4vSg2GZ3oc/1f9m/xLyAy8XfjS8v\nQuIf5nI8DI6cibBrwDKlyqQqMdSwxLs8XgPTvecUmfSHHj5sBEgnmlnVy47L\n9yDlmH3SFjrurSKHCvD7hEzxrwrcM4s1+yrsCJD0ObX9tpGoMIa3W/YbOvUe\nFoVRIrpDd/Vc+iO5kJS7NrNwv19Gavgk3bprg7yygCvg0SkxI95tZfCHVz5r\nCVgKBPKqrxD/BML3ACGnHBR4VA4rIO72zmMlU5WMdgtExt2e6C2QF8jLmzWb\n0Y5zG+LgCPZYgoi6bzGf0c8pxG9hhTh9Y4Scld8YuGk9UapgtRacPavDsc3w\nrgrpg7EDepRTqUoWLHAgcdrcip78N7iBkMatFx4wclkor4ngO2RHGQZiGlT5\nS+gxKdDrpi/tuWTEXBvY96ban9jvhfqZv9L6rLWCBsTCZSbomTgYUPzAszox\nh+pXUDJNQB1t/UCHf6uuxOFFMqSEe5gCnzAp0MnrH+9e1dL4YcWl+lK9E7hr\nTFxu2SZ32hrlUComKo+0tXXwqpZ7rvVCfoRYE615nqciZWi6q5v3Hl/iuV8y\n88XJVivrB6uHZ9qaXexr01GpCzBFhFDrQyf0GRPdJq1Ca+lJJfvo9FwSfd37\nMG3LJK4GNCJMWPZNi3qqTkZlBqJqy8D7jOQ/m6qQryW0y7FDxTDabA+92Qq0\nZqehdvGsZfZv/9KqFl7SNwXCbv48+1EWDc8mOMa5hOdKRjm4cAtcYYIH6FFC\nqV2qYwyVp0M/MMjr0rRkNaIaOJxZ2rMgvOn17Z0y03nPc2IPkJOjcYl6A7kz\nCpvXT9JkmKHSU8eyOZmID/DTt39ZgHp0WgiyCXBPhiwqxEzbOVXI0M41WW01\n85L4re4Jsh7xqAE69l8woHGHZwsRDZxemEyXjz/1MpISzgxfcrgwstt8mjFL\n1Q5Grcmpf9TPMECnNWjQSkOp9zu4pdyot3Rcrea0ad2/HOwFiN5nPj4wHJSm\n8r3vlyYwP/NBAXpA/a5oLkdfMrSaaNwhfEImUOb+vy2Ub5iRwCBfQUzieU75\njPtRmHDzoCQlYVYtOShYgfyxZNSvDL2fGV8W8bUyfoqpEvnSFQ+moLsgubDO\nTTzrDwsW1tw/VHZYxMLXlX1qFmF4I+a07eiZW8CaoAR2ZOpTf4u9AJ7NH62t\nMsUwqMbQfNg/SAgY8o8YLX7G8FVHTUUW+0iKnWkhRLocBdu/Qpoo3nkxBrgI\n6vUU20E4oMf4zlwN0N0a0EZ1LSeFciYiK/X9olrS9AgyCj5HsKN7hQ1FvRUr\nEs1mHTGdwVi+AvNVag8ypwVLqk1wYGhco5q+3CETIaCqrUEhqsqaHpnjgkNK\nPjlu415ppCcuDv2KS6vc12UUQVYeqtnfemb8qEa8CiI8xa/O+kw85sztr7EG\niKKl0AqEZvHgi9c287fjaDe7dmUohByNILF/uxwcZvBDTfnb7vHylw2fCyQr\nDegtLFh/25ntCq/rTHZ3RAXJwlZmx5J76YTW60MDxnK4xQD7R7+oileNwBFP\nJicr6muQbXXcoJs+PCe3q5d9bKgztmB1SSJtgtPnvVzPS9iW9rztk15DMyEt\npMO00kihYRxM0Xm3e/ncTO19/rgDT8l5nlwQWoiFAloxR035M54mBlJvO6zQ\nOAk+ucgVQ+P8rYCJ4T1+WdZ/bal0Kce4cDv7mAJ3z/opKPVMqIB8eJXeImIF\n0dKmIOk/aqGcqA1tA/C6bvPaZ2L2PVeemPfc2NDX991gdsnz+ARWZhFGrqO7\n2DK1+21sUvSZ1vqqJdUkkQy8oq+d0ghG7cn7SADPR83IxCvSAp9hjz4BTd9V\nxGcE2soySSw3KONs6N95psVeG0iCiMYz4tbJOmB3/ZQnzLdyH96qFr21eor7\n4OfhBsZFvPXIw+r/cPgX+sLQQ2uYXZmEbgbjdzB0uWJnIepjNTD9lrFvEKvl\nSwtXuyiSPCSYXaJloOgKm/hpapAMBI8EJOWurrA+27k7MGuUDbotlTjchcuK\niW+dB93F9J3kjTCja1Jn4Ilkt0L2GvloHIRXE1uLOopsIGcPU5SFniTCGRlc\nS5sBwovNhLnuK4VkKzpjUGKYQV1FZ35qzSBreYwwCjgHFwv1+dpJvMLo30YQ\nmxOyH1/73T0o/QM7juT3K4h1SZtnyKT2/CGyyjTjQrRyyM7MD1v1wZUCWvcY\nh31X+9KDPMCUVwv2uMVx4zRsln8OA6nN/iOJUaqgkgcPnfd7ej+N9cKvLMvP\nXLt3tJEQhka9bpTgwJVe1RBqoV1PoTaBSDENzlLgMgeMAOeJTuLd7w9nyN65\nliQdHI3+iT7j1XDFfxq3EUozaggTmpYfVka3zjKFxLFNvKzqy5JsSVAi2V0U\nHg3v9316kotc4Zhs1cHe/gy8T8U+j4W0kgdAdX89D6jGsAIQA8Pr9k/XJiGA\n8/1cb8Wj7WQxynM8o7Aqops/6rLvEutphKPVyre/81u9Xt4XFb9Nn15xDYVD\ny9NQrEg6J53CECrCYwE4oAtYGkCcUKXqwe9aIU1YwpCRSvEnkAZ+7Lmx4rtk\njUECA474cIeFehRheOPYFxmYkz6SgS8wXBkZrfm64N0C5vcPHzMbYZrE40P2\npQv4Lv4JvpbOOe0cwxVGXzDz0ikFhYKuFg5iPqEY0vDGuYU3CK67mM3JnLXz\nvpcHrEVDXNwwU3baZt2OP3cR8ejVRfJTiKXIePCHpuwY/bcAW4DRebzcS4/d\ngdscp48f0duqM1TmwLIwKv+2cse6UZIdEWnuCFBNSAqySRghiZ5rEFRsGG72\ngp7sCwwSgYFeHIW9SxNI6q6MRh+AlcU2q8A4YLvUgZIaJ/Qx8BvT8oOm/c/j\n0J5xXFVm0k4obVP5fT1UsvkiTJ/YVQTHL/0dRGxHz9QHCjSQgzrNIvcbkmGX\nVDwIyjk4Mg1ADbz44S/DHGs2pnBS8/cF0LzM9gUFZiBVYCgA+nb/GHOjszDU\nGQbLeZzlrOfvhOy6E6U92hzrDG+MsCkPKe2GKHuwShvnK/lmZRWReiFAmMA3\nOas+kKED77VwYVUq+TD8/M89btmZ+nj9sfwsW+yOztqIBJk0IwcRXIFTMh/k\nE9VeDAtVkgtW9DFiziYMJebrmup5iOHwUPajGsFqsQZ/BTmvfsdvXiAMTUCi\ntV+IdOU806qS2bXQ/Zb6fD8xTquwwu6j+RCatOTWnxPgyPhoIO1KgOM43+bK\nV2TDVSB1Cdr07h3IOffsRbiUn8wzqyQu9/zYB07Jb6iajUH2MQe32wE8J34w\n4XT0+s29q9ttSvK9qlw3oyykc57hDbiMAuSIEpUVb17qJq3VFw3XpJrIeVz7\nsXI2CSiYOJGdI58b0ZDW1cHxTq2BjTEVlH/K7YObxtMHqA7fkRqIASPjM6gb\n2ezRZTP4JGIf20V4deVHwWcLquxIHcJqHY8B3jMkktboxu/qdDJaYmDpn0M/\npDyejWy1+h2LpgMuooxmHd0/Xmlm+zaNKa9axN2myYUcygl0jXw4kT/Lboav\nKGJcVTHX3fWt6+TICYYp7VrO7VYnJlWsrdut3w4VEaXZ84oUmLQQOLsqSzJI\nqefix3xpIg1EfycVh24Oj598FgGTfoLHMvYtgliQRRZWLgZoemGiivrHbtva\nfCpn9SZy1KtVIvookQCH2/6hdGiAo8MVl2bWhJWvAEM2yA6a6FnSi2dWM/nn\n7IQAUcbETxolfBJAUB2xPZ698IITgwPmDmEU28SOAIlfSdfM7NFqR+p22E5M\n8XEq+PyTHJrQCtO9QpkOJMcO1mOuiJfY/CU7ohvfy5gbBBAFmNqZMwoeCMQD\nf2eSyrocx8fqkJuYj5EeT4EhpreL4HnmwI/hAvtRQkxVKNxM7/SRL3etHsi9\nJ7+PRTgr6a/BI0a9cmF+jM6r3VU5qQ0k4UwgQ0hisRxgsy4ahrLq47FetPrU\nSOg2x5Do1zO8pV/rcZueRB92Hhto6f1tLX6molS2yc2+xwkYanoNmvA2y5Bj\n4DsMvAKLAc3oxPk3WzqT4sdeJBuwCUEyoDR+lhVDrwaFL0ZvIxlBMugzc7Fp\nXncb+8wfJoNErGBbUht+XaK/h9QdYj/V0YxF0JYUVJ6Kx9lj4+nfaKt+jADq\newhmuHV8nqQ/sgloA8lRsJRIzVHDXDx1IW2agqeeafqCP0QhWMHGx3mH0iWR\nEJJ+SWr8Pg6HnuTJ1cuFKCoQ6ZnZCVA/r3e/ecqTIRJcIM2KqDIs+7DIBkUW\nO4SF5NdKa12b7ww6qDbvHB5JcelNIm8vourOeXMMgPqBIrGcmisNTSRsj4i2\nNQ1JpvacMiZtFO1RqafR9xEv6Mz1AXrDVI7XkrBi3M1dgLuqZ4Q4CLPJVfO6\n5xDTneq0EYQ1QjKd3YP452Fqtf9zrOJeOf4gqz0dG2AcjqdF6CN1Fg7PvmZo\nn6lh80kqLi1xZcb3KSYHn7zCPV2WCNum2JHD2fVbGayNpGkSx877BH4Ec0S+\nxzJ1Egn2ipzuLdQtMSgsHmIXXIO0vAEZPgJybS78a0ngfXYJMqUI+Vk18TyW\nMiVJu18xPYsNbcFt1Nqsu6K/UlcDlzSKZd6eZDnZ0ngLzgnvJShEwMzyohWc\nZ7d/cYDVaq/+eV87a62NmjYzkW9riPAVHR3vNjQsrl81hAD6qxRq46t1s3Zt\ntsJe9QbTb1IoRttjy17iaJC+CeNITvR+YNgBvZYLDNlv0iBDIr8vkQ9Bq488\nh8d2zX3VLZgjo0Bw0Kct4opuTcJphi8od+kDIsh1FcGzHOg94Gb0tLHYpmA1\nrcLZMmXT1wiJWlOgJB1kmOD7GM7hE/Hq88Kfjve62L1iJebcdwWKgnZyQ7jd\nnfkbSgampteS4GVzCV5vDWTCDBmXT70D34o8x5IX6V6GlJlaXJkMrihsVUqu\nZlRmzWXinFv9nleayWTi/hr4ZhWOxcCJPCh3CyYDtQf4/iPKRfE10m/0hTRA\nKpnn6/OUwjfbPcR1i5eUHvKM3NkjUYQoToe88q9Sn/FoJQyb1CGo4pIoSpYP\nw7F6hZsPG6FIQIK1LWqWwadwP2AlkVMFYNtjNjf7kP0CnwuhDn/cwRAcidWX\nWtczqK4bjLsVU99e2LUVlbQv0Nb2kiDcwp+cXhK0OWSPqzNEyplizDfXM3c+\nXfqbKNl5qa4PN7zrt9zMd62UMpDHFaUh4/tirzSpKvprGAi3mkEKgMsTxg0h\nUqUAdgQzb8F9WRz3LdKQtys8qaL8dZrsvj0XUKRxshi0JcosRS2Xxi+9S3Q2\nCwFiFvGiIJSrk+WFoMVQs8CSk/UI6VHllSuZQ1sOIDksJ8O17rK5nqKtDUbz\nwYfwWmOwbAKfm5DFY/K+dmnI9x4X2FwL2fnZ5GHZVwny+6wn1TpogUbn4odL\n/VCJ2dG5hoNXTDVltbrW25lUkinZfNBwJ59a/wz3lPgGBN8M5lB3Jce07NxH\n4P/zIG+aEHMOVojHOwa64t43xPSOTqZKy74iivdE++JNs8WWFSU45abfAK7C\nmh6wjWx028LztNEqjuz5UH8n4LObDAGxiFGkVZYsed/w8RYcM+U9rr0xPJ7i\nKh5LMpTlQLaedaN8UNcuWVE1+a07HbTSVZR8LEf4Rg3oWUAPsGJR0rigvA3O\nwkYi2Xmk6LtNuL1VsMNOwg2rdexoCdS6o9m66rLVCJOYkw5SIl3jSrtcBOHl\nNw3P83+xs9SIyC+xYasnHD4yatZs496iJ7C1JywqUY9SQNGTuo+ANJt0eUZq\nqXama/N7At8Qnoo/xcqDa2lV3dooG+e63mbP9fKBzrzNrpr5ZX/16U8Qz9LW\nIDEmKHRSyVnjiFz2vQOHlMp9bueQm7tT8HulCwYqnjizryQOhOz/7u/zMN69\nZHGSiQat9BFy03OeoW6hjZpVn6VPL6LlxjkkzuLzJoFF/UGaWwoeRzES+cgl\n1kqx1/3oHT6A87uUXBozu4huUXTLnsCNKZMz3ShlavnsSarIEALRmRoi2Nzr\nb3czubSOzTRIHzVs8nBtlGduhZbqmqOuk1YY2Heq0XdG8QBylxnUi0tws6jL\nW++oeLhxYIe1w1zjcgSWsVFcEL1YHDKcdWoW3DDKSrE/xQJ2I8Lh5hH/1FOj\neUkapFanFpYAMQ/5ybtwpNDtta2GtR4ZrJNGXI3qMemfkkb5+ehCg2xCGork\naDKE7sELHFoq5SWwMEN4uTKWUrFciFIIsC+pQTk6x4mNJ13A/N+Rdk+Z0u3S\nBajVO+ypyiv/5Io+EZClTNifX+oHJSXfFJHoJhkkluunm6yk9OTtPs1ks9n1\nOYcD8OhH/oaGx/ks/f3YUS6KtYT314hXPbstDOFXPczT1xS2Wjeo+8PGguUa\nMBvGAMUAdUKdh0s8zaKouP4WpckKRSfNX6Ax0WK7bUTX\n=WN+J\n-----END PGP MESSAGE-----\n','2026-07-21 16:31:37','2026-07-21 16:31:37'),
('5a62e304-406f-4bcb-ac68-184b7e437d71','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','edaec922-7cdf-40ec-8fa9-273015d3c125','0fbd759e-e8bf-401b-a43d-f4cc96ce599f',NULL,'2c22e1ca-66dc-4107-b375-f2d0d13dab9b','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','-----BEGIN PGP MESSAGE-----\n\nwV4Do6VaHHleMHkSAQdATjOQ2xJkAl9IOlCuUP0kHhxqHpV6fGjQ6YgY6B4w\nBBcwCo2yyVinsuCw4sQAzzk7dfzATJ7gRjpYbr4+jR4P5z9wuhmUNWWdaqco\nTsWyylBG0sBlARxCA4lnR6gcbYGsIf9gkyVXv4oa5hUPpNCSxl1+IRHlZ2sD\ncQGNESous2h1/UfNeGTchi57pGUa7EtjrfbQ+QuPUOZML3kpJESKqO6TUcwU\naHtfpSxCa0NfeTDQhMDtrPhaEd287mP2gp3vTogjNEFkv5GdBmnb+ygCIKQZ\nOW+2pg1VzgJKZuuYU2OeRkhf5hSdPehewVxCPGhUDsgAQ/Bj/B/KtL+/uw20\nXbb0kxOjoAzwLIMVSiuRxGCTp0VcGsaxAJSosYzDfNcwnWU/X7uwAJ4EVDNe\n6cVUa0V++ifunvHqo27zhSX0QGVIc4nJ0BzKqC8vsS0gaQy+M8yN+E6ObYN5\n3GIFlNIT40dCE8elJ4QyQaYP3EP1/9g1B1tNdjNFU28=\n=ltrt\n-----END PGP MESSAGE-----\n','2026-07-26 13:44:01','2026-07-26 13:44:01'),
('bdd24fd7-a058-416a-9cfb-36621db1ae6e','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','7672b60a-f739-48fe-9265-1ac6f710557f','d027e3cb-afac-4d17-b51f-85e02ef814d7',NULL,'2c22e1ca-66dc-4107-b375-f2d0d13dab9b','2c22e1ca-66dc-4107-b375-f2d0d13dab9b','-----BEGIN PGP MESSAGE-----\n\nwV4Do6VaHHleMHkSAQdAo5wrn6BQ1C30Z5w8eAP7bZMaPYTfc+KwGtPAI4gR\nmSgwftm+9EShsXLN2wUkwV/4sQhJJU1d65yBCROL0F+kr7nvY6aMDk/jum0k\nyk4BkxzY0sqYAWivYhpvRf2KlUnI/aNgLbMca8yOES9eRqKsKqL6xpPba91+\nE8FJHJeFjb4oVJSOX4hkQLqHnQmNR6rCFIKS0qCo2s+AmTkq7HD9mN7eKbig\niVkg9bNIZKMP3uObtvDMenPf+JmpJPcxn8Uf//YSJ6SYu2vCyYMqO3vYbhSs\nvyOEoy94jsp8Jn6s7nPD4aIbdO94DrVdnmnUJlMfi2VZ3ghODnVOQnmYZijY\nMAJBwmsJunJZSY/KA3IQq/DcB/NKnGkTMfp1a/g3OJF7jqL1i8jbtt6TzxiA\nArivVUZGrTIlQwTSb0TPDrr4aBe5h0sc8cc+WdoRTE1BMkAt8tMZEAdkd9cv\nwpM3YGLjl8jNk62GeMTJ6OnkMbCoC3U8iXOpe4COxjRCf/vnv2w5eE68IyN/\nGXJeOt3cWnFp8LVFw20D1UN47rzCdxtH7p2pN5yH7z7ISw+LjA3zfaJKWREi\nPA93BKlRS8B9B723Dp4wgi4PMZTIDq7P3D/4H5p3HM/onqq4s+4KgfvS9li6\nSn3alvoWfvpyi+cljoAzf+Qpz+qKDpFPvN2ZWt/N5YBfUgK2Bf0ctAMwSjZf\n+MfYQ4eXzDVpabADZRVu/T0K9EhLRcAkVuyzMUYZrMhPvWVNA7aScJM4wEMy\nMSBTq1rraEYRMy6607sJL3M0dorPyTdahfyes4T9JbOY47hf/PAuIHVkD55a\nimh+XzAQFwpnztNx3jiUz83OdHearBD+EaiO24n4sNVweV2WcnJ/vpbN5gjz\n4CaRF7wenIo1vs0tC20REiJpX8ND+J/bZwU4oHIbzLNHFYQ5dgQDHnVP68wb\nVzdHT0tlqvVs6LFjkfYQzk0pAd0wv/QKzMgrr+//eCj5bsrMMI5l1QAVMuGX\nF60X4vUIdEd1p+O2xXQ5WSVQ77ETfyK0sa83V1viRA+CrOnO7vx5Xx0G+JC/\nyHZF3AbzxASggNK1iDrkSPokFdKeN2g/O4R5T1Wk4HAU/KQJwFIpk5uqJlb/\nc10R3P/xaJtkCx3JCazP0iQPKENVmf++trgsx9xX24bRV0fbOI9JVwyVfyIs\nS/OcVEkcCnKBIMlEmdoWWqc6tvHDuiuMYzAZGo6C1k1rCzZwjamJZY7a9j6K\n1cny7T1kmHaTBsg4WSGA3j3d2JdL0kui/vjyMTmz59omFDTHrZuBBU40ueom\nLVLyjxah4YtZPcbw7FTiX52FySqlylux9AoGE+gYv4C67Ba26Mjhk0h9bE44\naR42f9o9x87nR3KcRME9zcsApUO4PzRXDAiM9VPLYDvvsmb0Vaq9fHYKSEvA\ngJDXs/Q0QinQXAGivx5ANlK4nSyDTEC9rMbLFXyNHY8hVhBnQxjrHRoccodg\n5ipwhuJHJCi8ocht9sSGLpdRb2cU/xFaqLd4kJq31lnXGJVShrUG61bil/nF\nTxQ4z6MsqgKDTDHsXIUI5C7g1h5koAwK+95WdlDTjve2FlBuqHQ0POMf0Nbs\npC7VnnqYJQVzRJe8cSW7dodIZEdeB0L38NB2MJsXMzvIp+c2QYQzPvd9HaR7\nwaiit4kiBF9DQcQZT2taM9ayHMBvWonM+QgTG0I3XiuaVmOmKKiEyu/3hS/9\nyr2seleL9gDtaoBywy56/beTPNb1TfDPg0NzMarGNHqpwNWeIsAEY2CC21K9\n2QaEJJu6lqszsdfXnvjvXpROmjFmP1s79oHobkYeUa19NKi/40dcU4ikOr6N\nDcfgwE5NSMRRUKUZwr4mQMhsHm0kKRuD/EvbCwo5NCRKxRyVh3SYamUcU3xN\n4rrT5DwLL85YC19nkOAHQfhujIs9xtcZYNUXPO68uVRjFHMErxCACd5aJjnW\nZpaIAT8z8V56QMsQmUgQ8ar1UmhQ9E37+auirZEQ8pma6+mSMXvjOE7kT5aZ\nWNqK4nbxu466pe3OI4SzzxUpR1oUnQjHmyhbAimryzGoP9bwlz2WU8QwIkN3\nNbTR41cfyYay/TOEdBZ29LLjCzhsc88T8OKZ06DglXlz8cqUkUdtHjjIZRFM\nMPpQwTQlgusrjxEyaiCasuiX+to4d7X6ChG3Ec+LVXoUSCc0TjFieTIb+R+L\nDWEB+y62NwVSO5h28mO13TwwyliqcfC48qOTZpqyk3O2XwRE8GAWKnwBdpm7\nDAUhXYqIGI7F5rl+YYlTLdAe4/BgwscGp3hMiREBad0zznXqlGrazVADXb4z\nvP8Mx7bsaJ2IOeHLdYHKKoh+MdJQoI477SoylrgW2qvJNlrHQMLtXc/k19vh\nLNnl/CljyVIfCwsVdvEqRGkvTHh3+lNoMgZEcuFXgd+PetDKdkBFRO7Mxgir\nbRH21zaGK8qtVicfHGHKaAEdrbfVGOp8XgbpeAdawdq760Yqhegfz6spylIy\n9FW+l6ExBrBAaLunaA67lKLGdn1OwAChPu0lcWepPqkldK+PksN9HnM0nRrL\nx+baQQ2n3EjpCZN9oB3eKRAbKEckSFhHqDNPfam8xklPbQlz0g3niDoMq8Jz\nDYeqMjCoK1sfS2h0vJ5GsY5zMEaMKDoMnwyiYjH1o7jX5BwQCmd9uAjWudWc\nDvZg+hqR7Ax5a+Zxj3z26FEwvyyDct6bcYPuJKvn6JxRv+HBovcmbmcocuaA\nWye35bxrYKJ8MJtWHFCBrKovkPFWAkUpQd2J6nkNN3NHI6t0m+doId/LJflp\nCkp1SGu3IfkJPGI0p1x2R+gL6BdDH2uircyomYykUXxuYBB2cKgRYTBFvY9G\nOpRJmYOuWipXbfgqGa5/Ltne2qZ+SZEPVsjHKWowtHTGPytxZTGDRIR074Mz\nDMEwyvQmPAa7V/B9HDzx43FiumJ5u9a5JEdUHDPCnMd3cyrB1EjbMjlC7rTD\n+LSchGwMXIMQ57BZPUORuZM940iyzMi3+IiOzPWgOuWf2oA5s5rL5DOVEhoU\nyjVZECpmhB1JpZfyzboD830eZdXEDM9w3delg4xbQCb31gSa38mKoJBDR+it\n254pl4HloqguCuX2vNTWSJIhSADchZi/WxvGgXBXjUdVp0PTUFpMcqeeJDTa\nosrpCjcEFPBUgnlMY4rZk2tnMgMXXu4zG3XES5peXJDXbi67xkkBcE5bEql/\n8hKtGcnMikSCNhcMi7VrhIsDkrjsRYefGjTTsriEpS4tnTbeal71+ahD1G+9\nwmks8JLq5R1nhYxLzYVgdMIgKQsbaKj9NKtpVM0UaBUPn2Lz5p5QbmDvaJ8Q\nT4zsgp1ayLepAYWDBkR6tZZA54APr0P2HAU0eKQuZuGOVwqc7V/sNZdDm03d\nVESQGQ6Uq1HSEOg+fLJf5MKHD43d50ejWIV1vi6zgHHJcrMJq0TjuJ+t+6ab\nwYro0SsUTEn0ufK68otaXTuAi3DcESUBIvhhVdeiInrYz6ebSGEGB6Ka4LpD\nolflwvUWmbxvMKVt6Cw8/sMxDpp3KkupYfBP4W7jJ0DIiGpl2Ag5wX5UlowM\nE32oP/n3OXScOumdacX+1yO7i+NofwuR5+Bwqe2qVdWsWBYQAMEmS7lNu/ET\nP7Q2z5+3kGZWuNv+ELvSpRce6fIgUflQ8aFVzqaEDq8RkfCNgKiLiHL9uT81\ndroqY90ZZbPA/OOW7SGq9ZaEvEFFAv/1UlNhVuqkOhUk94tuiSK4bMhL2/oC\nN7QMYzw+Oes+BVKJXBETbgeeWMiQ7V9GW6lW0G+nwQWjEMiuY5JmWHNpRp9N\nS3N707NHcY8Aqkc/SUjs4LsSfUdHpSrnMtkfG+B+F8xQeHkTmL2OHs1kMsRI\n4eps1RShSrUjbCWxSlQoCXZmGLBVYyg6fBqDBqIeeFBLgOUmmykN7NS4uVKt\nLdewceIi09DCv0EeQa32osfNb/G1Ldn8CPtxmZHiuIwB\n=PeZO\n-----END PGP MESSAGE-----\n','2026-07-09 08:50:59','2026-07-09 08:50:59'),
('e3497918-4461-432f-a635-4fdf8a88d825','f6af0e88-6246-4f02-9278-e664f61dd3ef','b619e31a-f69a-48c4-b248-9fd03aea8005',NULL,NULL,'f6af0e88-6246-4f02-9278-e664f61dd3ef','f6af0e88-6246-4f02-9278-e664f61dd3ef','-----BEGIN PGP MESSAGE-----\n\nhQGMA+S/rjlK3hjmAQv+PCRUHGnbRF/F30W8av+k5uRo0KrReAQxdYp6vUnxy9ps\nmgkXIv9A9KCzNI/9m3sTaS1YehsMIBf1hN/BCCzp5lIskJZCk2IOVpLmJjBezeIs\n2n7ZP0OMVg72V2n0mMHjayonO+tc18PqF4cadfVw1VTq7psE25I1y7xDwcniDaai\nsIywaQKn3t9hOAOYFy+Lf6/4/h7A60edfdHJqGZYeSP0ND2C+I5nBKfLzrM2T8b5\nFD/pr0dWndjgqxsIcTzvozETGMhSXlTQ41UCRjGo3jeRw0LvUCsO8lX+8QSuDoKE\n3JODHzZ47ehJDNwk3KT43USx52lyLhvQUG7uk/vqVBlvbpX/Jj7fvH6nrYytOLqP\nLkNpEyhcwMwzdzNEHePj+QVcemv25Ol/e9bvUJc1EwWQ7b/gdB/u0hWh5jqwflNn\nBTmTQTnS4rgRAr8V4nbMkGt0uZ2EfRtWPlrBzfme8bWhPVrDX7GRvlAWWxQ54dfp\nq43UavWb+4QSqJWiFTMJ1GgBCQIQxZ5mHyRZqBJrsCdZZjyCYCBe2zPCVqyWZrb2\nnqWYExXSuPs3+s+ql1QyFsSDb0gMF3SxI69POlFRiOfm5ynwlVbiidvO1AWhJ6+S\nMiq3CYE7UmyBsfVKAZRxZe/p4+UOWIYAHg==\n=vMuF\n-----END PGP MESSAGE-----','2026-07-09 00:58:13','2026-07-09 00:58:13');
/*!40000 ALTER TABLE `secrets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `secrets_history`
--

DROP TABLE IF EXISTS `secrets_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `secrets_history` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `user_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `resource_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `user_id` (`user_id`,`resource_id`),
  KEY `resource_id` (`resource_id`),
  KEY `user_id_2` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `secrets_history`
--

LOCK TABLES `secrets_history` WRITE;
/*!40000 ALTER TABLE `secrets_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `secrets_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sso_keys`
--

DROP TABLE IF EXISTS `sso_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sso_keys` (
  `id` char(36) NOT NULL,
  `user_id` char(36) NOT NULL,
  `data` tinytext DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `created_by` char(36) NOT NULL,
  `modified_by` char(36) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=ascii COLLATE=ascii_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sso_keys`
--

LOCK TABLES `sso_keys` WRITE;
/*!40000 ALTER TABLE `sso_keys` DISABLE KEYS */;
/*!40000 ALTER TABLE `sso_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sso_settings`
--

DROP TABLE IF EXISTS `sso_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sso_settings` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `provider` varchar(64) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `data` mediumtext CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  `status` varchar(8) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `created_by` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `modified_by` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sso_settings`
--

LOCK TABLES `sso_settings` WRITE;
/*!40000 ALTER TABLE `sso_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `sso_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sso_states`
--

DROP TABLE IF EXISTS `sso_states`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sso_states` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `nonce` varchar(64) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `type` varchar(16) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `state` varchar(64) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `sso_settings_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `user_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  `user_agent` varchar(255) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `ip` varchar(45) NOT NULL,
  `created` datetime NOT NULL,
  `deleted` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nonce` (`nonce`),
  UNIQUE KEY `state` (`state`),
  KEY `sso_settings_id` (`sso_settings_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sso_states`
--

LOCK TABLES `sso_states` WRITE;
/*!40000 ALTER TABLE `sso_states` DISABLE KEYS */;
/*!40000 ALTER TABLE `sso_states` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `slug` varchar(128) DEFAULT NULL,
  `is_shared` tinyint(1) NOT NULL DEFAULT 0,
  `metadata` mediumtext DEFAULT NULL,
  `metadata_key_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  `metadata_key_type` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`,`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transfers`
--

DROP TABLE IF EXISTS `transfers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `transfers` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `user_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `authentication_token_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `current_page` smallint(6) NOT NULL,
  `total_pages` smallint(6) NOT NULL,
  `status` varchar(16) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `hash` char(128) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transfers`
--

LOCK TABLES `transfers` WRITE;
/*!40000 ALTER TABLE `transfers` DISABLE KEYS */;
/*!40000 ALTER TABLE `transfers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ui_actions`
--

DROP TABLE IF EXISTS `ui_actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ui_actions` (
  `id` char(36) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=ascii COLLATE=ascii_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ui_actions`
--

LOCK TABLES `ui_actions` WRITE;
/*!40000 ALTER TABLE `ui_actions` DISABLE KEYS */;
INSERT INTO `ui_actions` VALUES
('02043f2c-ca5d-4c98-aeed-5d1c819c8e36','Share.viewUsersInAutocomplete'),
('0d617ff4-589d-49aa-b269-83e20ec44c7e','Share.viewGroupsInAutocomplete'),
('28194ef8-7d87-4043-bb03-86312e20643c','Secrets.preview'),
('28cef07a-22eb-4c0e-ae2a-0e9c935b94d9','Resources.filterByGroups'),
('2988c73b-049b-4a9a-9602-4d941bc1a1a4','Resources.seeComments'),
('2ed74e11-61a0-45b3-af99-56e4f7ed642c','Secrets.copy'),
('3cf75d4a-997b-4ccd-bb21-26cc38897e81','Resources.editPasswordGeneratorSettings'),
('47207478-05ed-4163-9592-c3c58966e79a','Folders.use'),
('4da4003b-ca9a-4b20-81b2-7d2cfb4a243c','InFormMenu.use'),
('51850f8d-0b45-44f9-b5cc-6a1e405e87e8','Users.viewWorkspace'),
('5d150a2e-b13b-413c-8166-59386e72b559','Resources.export'),
('629a34ff-5add-46b3-becc-a9fd4eab8ea5','Tags.use'),
('7e77c8d9-6863-49f2-8b3e-1321e0093362','Resources.import'),
('97b8e854-06d1-40ee-a59f-1b44139f95f8','Users.viewGroups'),
('a837b47d-25c7-4d2f-b17e-29bf6caf45f4','Mobile.transfer'),
('a94927fe-8cfb-493f-a038-d3059d88a4a7','Resources.seeActivities'),
('ae3b9379-33ff-4dd7-97f2-2cffd7f86b1d','Desktop.transfer'),
('c5ad0853-5e53-4965-b1e1-115577dba48c','Share.viewList'),
('fca3f3ee-c504-4c6d-90fb-36554d75c1dd','Folders.share'),
('ff5bb432-b57c-4e9e-be94-18235c4e1556','Resources.toggleDescription');
/*!40000 ALTER TABLE `ui_actions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `role_id` char(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `username` varchar(255) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `disabled` datetime DEFAULT NULL,
  `last_logged_in` datetime DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `role_id` (`role_id`,`username`),
  KEY `deleted` (`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
('0741af5f-6ee4-49c0-ab95-a347f9ebe02a','4e7bbb1e-b5cf-450c-a489-c41de1e2908f','leo@patty.io',0,0,NULL,NULL,'2026-07-09 00:42:52','2026-07-09 00:42:52'),
('2c22e1ca-66dc-4107-b375-f2d0d13dab9b','e66c3a09-1dda-4143-8fd0-4824233698d9','patrick@patty.io',1,0,NULL,'2026-07-26 16:25:59','2026-07-08 18:52:16','2026-07-09 08:46:05'),
('51fc08f4-a945-4a70-b5a1-ee0549b66189','4e7bbb1e-b5cf-450c-a489-c41de1e2908f','jin@patty.io',0,0,NULL,NULL,'2026-07-09 00:42:35','2026-07-09 00:42:35'),
('bd3c4edd-805f-4c49-9c76-a53270539320','4e7bbb1e-b5cf-450c-a489-c41de1e2908f','david@patty.io',0,0,NULL,NULL,'2026-07-09 00:42:53','2026-07-09 00:42:53'),
('c4c6fdac-fd5d-4980-8601-dfd7fab06f16','4e7bbb1e-b5cf-450c-a489-c41de1e2908f','ilia@patty.io',0,0,NULL,NULL,'2026-07-09 00:42:52','2026-07-09 00:42:52'),
('f6af0e88-6246-4f02-9278-e664f61dd3ef','4e7bbb1e-b5cf-450c-a489-c41de1e2908f','patty-codex@patty.io',1,0,NULL,NULL,'2026-07-09 00:58:13','2026-07-09 00:58:13');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-26 16:31:57
